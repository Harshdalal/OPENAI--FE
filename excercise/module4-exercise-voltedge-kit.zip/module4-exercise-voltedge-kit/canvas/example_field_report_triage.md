# AI Use-Case Canvas: worked example (VoltEdge morning field-report triage)

Team: VoltEdge support   Facilitator: practice example

| # | Box | Example answer |
|---|-----|----------------|
| 1 | Task and who does it today | Each morning a support engineer reads overnight field reports and logs from units that stopped charging, and sorts them |
| 2 | Pain today | About 6 hours a week; categories are inconsistent between engineers |
| 3 | AI workload | Text analysis (classification, entity extraction: serials, codes, temperatures) |
| 4 | Input | Field reports and the charger log excerpts attached to them, from the support system |
| 5 | Data rules | Reports contain customer names and sites: remove them before sending; company Foundry project only |
| 6 | Tool | A Foundry deployment called from a small script with structured output (Module 2) |
| 7 | Prompt or template | log_triage template plus a fixed category list; JSON with category, serial, codes, evidence line |
| 8 | Output and its next step | A sorted table for the engineer, who confirms and files bugs |
| 9 | How we check it | Engineer confirms every row's evidence line; weekly sample of 20 checked against a second engineer |
| 10 | Risks and guardrails | Wrong category hides a safety issue: anything mentioning heat, smoke or swelling goes straight to a person, never only to AI |
| 11 | How we measure success | Hours per week; agreement with the engineer on the weekly sample, target 90% |
| 12 | First small step | Run the template by hand on last week's 30 reports and compare with what the engineer filed |

| Value | Feasibility | Risk (5 = low risk) | Total |
|-------|-------------|---------------------|-------|
| 4 | 4 | 3 | 11 |
