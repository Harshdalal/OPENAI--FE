# Module 4 exercise prompts: VoltEdge (copy and paste)

Use the chat playground (or Copilot Chat in Ask mode) at temperature 0. Start a new chat for
each station. The templates folder holds the Module 3 templates these prompts are based on.

## Station 1: explain legacy RTOS code (station1_legacy_rtos/charge_task.c)

    You are a senior embedded engineer who knows FreeRTOS. Explain what the interrupt
    handler and the two tasks in the code below do, and how they share data and the SMBus.
    Then list every concurrency, timing and memory concern, most severe first, as a table:
    line, concern, what can happen on the charger, suggested fix. Use only the code. Say
    "unsure" if you are not sure.

    <paste charge_task.c>

## Station 2: build error and log analysis (station2_build_log/build_log.txt)

    You are a firmware build engineer. The build log below failed twice. For each failure,
    give the first real error, its likely cause and the fix, citing the log line. Then list
    the warnings that hide real defects. Separate what the log shows from what you infer.
    Do not invent file contents you cannot see.

    <paste build_log.txt>

## Station 3: specifications from a datasheet (station3_datasheet/)

In the playground, use templates/datasheet_extract.md with {{part}} = VC-21 and
{{page_text}} = VC21_registers.md, or attach VC21_datasheet_p4.pdf if the model accepts
files. Then run:

    python scripts/extract_registers.py --mock
    python scripts/extract_registers.py

## Station 4: unit tests and mocks with GoogleTest (station4_unit_tests/)

    You are a firmware test engineer. Write GoogleTest tests for charge_current_for_c10()
    and charge_control_step() in the C code below. Take expected values only from
    charge_spec.md: one test per agreed example, plus boundary tests between every rule.
    The hardware calls ve_battery_read_c10() and ve_set_current_ma() are already faked in
    tests/test_charge_curve.cpp: use those fakes. Do not change charge_curve.c. Output the
    complete test file.

    <paste charge_spec.md, src/charge_curve.h, src/charge_curve.c and tests/test_charge_curve.cpp>

Then build and run (needs CMake, a C and C++ compiler and network access to fetch GoogleTest):

    cmake -S station4_unit_tests -B build
    cmake --build build
    ctest --test-dir build --output-on-failure

Documentation follow-up, same chat:

    Write Doxygen comments for charge_curve.h. Take units, ranges and rules from
    charge_spec.md, not from charge_curve.c.

## Station 5: a knowledge assistant (RAG) over the VoltEdge docs

    python scripts/rag_ask.py --mock
    python scripts/rag_ask.py
    python scripts/rag_ask.py --question "How do I clear a locked charger fault?"
    python scripts/rag_ask.py --question "What is the maximum charge voltage?"
