# The VoltEdge support team's top three time-consuming tasks

From the team's pre-work. Pick one for the canvas in Exercise 8, then repeat the canvas for
one task from your own team.

1. Every morning, read the overnight field reports and charger logs from units that stopped
   charging, and sort them into thermistor faults, SMBus problems, power problems and
   "other". About 6 hours a week.
2. Answer the same 20 support questions about charging rules, LED colours and fault codes,
   by searching the release notes, FAQ and requirements. About 4 hours a week.
3. Update the charge-curve test table by hand each time the product owner changes
   charge_spec.md. About 2 hours a month, with frequent copy mistakes.
