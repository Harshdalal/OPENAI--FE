# Exercise 7: design the guardrails for a VoltEdge agent

The charger team wants an agent called ve-build-triage. When the nightly build fails, it
should find the first real error, check the release notes and requirements for related
known issues, and post a short summary to the team channel.

The team proposes these tools:

| Tool | What it does |
|------|--------------|
| read_build_log | Reads the latest CI build log |
| search_docs | Searches release notes, FAQ and requirements (Station 5) |
| rebuild_target | Rebuilds one CMake target on the CI runner |
| post_message | Posts a message to the team channel |
| edit_source | Edits any file in the repository |
| push_branch | Pushes a branch and opens a pull request |
| flash_device | Flashes the built firmware to the bench charger |

For each tool, decide: allow now, allow with a person approving each call, or not for this
agent. Then write three rules for the agent's instructions and one thing you would log.
