# Exercise 1: VoltEdge tasks to map and score

For each task: which Module 4 use case is it (legacy code, builds and logs, datasheets,
tests and docs, RAG and agents)? Then score value, feasibility and risk from 1 to 5
(risk: 5 = low risk) and say whether to start now, start with checks, or wait.

| # | VoltEdge task |
|---|---------------|
| 1 | Explain the legacy charge_task.c to a new team member |
| 2 | Find the first real error when the nightly charger build fails |
| 3 | Turn the VC-21 register page into a C header |
| 4 | Write GoogleTest tests for the charge curve from charge_spec.md |
| 5 | Answer support questions from the release notes, FAQ and requirements |
| 6 | Let an agent change the charge current limits in the code and push the change |
| 7 | Draft release notes for v1.7.2 from the commit list |
| 8 | Decide from AI output alone whether a field unit is safe to keep charging |
