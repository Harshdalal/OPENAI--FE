/*
 * charge_curve.c - VoltEdge charge current from battery temperature.
 * Training file for the Module 4 practice exercises: it contains deliberate defects.
 * VoltEdge is fictional. Do not use this code in a product.
 */
#include "charge_curve.h"

uint16_t charge_current_for_c10(int16_t t_c10)
{
    if (t_c10 < 0) {
        return 0u;                       /* C1 */
    }
    if (t_c10 < 100) {
        return 500u;                     /* C2 */
    }
    if (t_c10 < 450) {
        return 2000u;                    /* C3 */
    }
    if (t_c10 > 600) {
        return 0u;                       /* C5 */
    }
    /* C4: 2000 - (t - 45.0) x 50 mA, then C6: nearest 10 mA */
    uint16_t ma = (uint16_t)(2000 - (t_c10 - 450) * 5);
    return (uint16_t)(ma / 10u * 10u);
}

void charge_control_step(void)
{
    ve_set_current_ma(charge_current_for_c10(ve_battery_read_c10()));
}
