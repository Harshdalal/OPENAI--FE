// test_charge_curve.cpp - GoogleTest tests for charge_curve.c
// Module 4 practice, Station 4: ask the model to add tests here from charge_spec.md.
#include <gtest/gtest.h>
#include <cstdint>
#include "charge_curve.h"

// ---- Fakes for the hardware boundary (link seam: the tests provide these functions) ----
static int16_t  fake_temp_c10 = 0;
static int      fake_set_calls = 0;
static uint16_t fake_last_ma = 65535;

extern "C" int16_t ve_battery_read_c10(void) { return fake_temp_c10; }
extern "C" void ve_set_current_ma(uint16_t current_ma) { fake_set_calls++; fake_last_ma = current_ma; }

// One example test, written by a person. Add the rest from charge_spec.md.
TEST(ChargeCurve, TwentyFiveDegreesGivesFullCurrent) {
    EXPECT_EQ(charge_current_for_c10(250), 2000);
}
