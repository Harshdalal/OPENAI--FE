# Module 4 exercise worksheet: VoltEdge

Name: ____________________   Model or tool used: ____________________

Try every exercise before you open the solutions.

## Exercise 1: map and score the use cases

| # | Use case | Value | Feasibility | Risk (5 = low) | Start now, with checks, or wait? |
|---|----------|-------|-------------|----------------|----------------------------------|
| 1 | | | | | |
| 2 | | | | | |
| 3 | | | | | |
| 4 | | | | | |
| 5 | | | | | |
| 6 | | | | | |
| 7 | | | | | |
| 8 | | | | | |

## Exercise 2 (Station 1): RTOS review

| Line | Concern | Real? (Y/N) |
|------|---------|-------------|
| | | |
| | | |
| | | |
| | | |
| | | |
| | | |

## Exercise 3 (Station 2): build log

| Failure | First real error (log line) | Cause | Fix |
|---------|-----------------------------|-------|-----|
| First build | | | |
| Second build | | | |
| Second build | | | |

Warnings that hide real defects: ______________________________________________

Anything the model invented: __________________________________________________

## Exercise 4 (Station 3): datasheet

Code checks reported: ______________________________________________________________

Value you checked by hand against the PDF: __________   Matches? ______

## Exercise 5 (Station 4): tests and docs

Expected values you wrote from charge_spec.md before asking the model:

| Temperature | -0.1 | 0.0 | 9.9 | 10.0 | 25.0 | 45.0 | 47.3 | 59.9 | 60.0 |
|-------------|------|-----|-----|------|------|------|------|------|------|
| Current (mA) | | | | | | | | | |

Tests that failed: ______________________   Any test that copied a value from the code? ______

Doxygen check: units and ranges from the spec? ______

## Exercise 6 (Station 5): RAG

| Question | Answer | Source cited | Correct? |
|----------|--------|--------------|----------|
| 59.9 °C | | | |
| CHG_CTRL reset | | | |
| Duplicate C-118 | | | |
| SMBus message for a locked fault | | | |
| Maximum charge voltage | | | |

## Exercise 7: agent guardrails

| Tool | Allow now / with approval / not for this agent |
|------|------------------------------------------------|
| read_build_log | |
| search_docs | |
| rebuild_target | |
| post_message | |
| edit_source | |
| push_branch | |
| flash_device | |

Three rules: 1. ________________ 2. ________________ 3. ________________

What you would log: ____________________________________________________________

## Exercise 8: canvas

VoltEdge task chosen: ______   Score: value ___ feasibility ___ risk ___ total ___

Your own team's task: ______   Score: value ___ feasibility ___ risk ___ total ___

## Self-check quiz

| Question | 1 | 2 | 3 | 4 | 5 | 6 | 7 | 8 |
|----------|---|---|---|---|---|---|---|---|
| Your answer | | | | | | | | |
