# Module 4 practice exercises: VoltEdge charger

A second case study for practice after the Module 4 lab. In class each team ran one NovaBoard
station; here you run all five on VoltEdge material you have not seen, then plan use cases
and an agent, on your own (about 90 to 100 minutes).

Only Module 4 content is used: legacy C, C++ and RTOS code; build error and log analysis;
specifications from datasheets; GoogleTest unit tests, mocks and documentation; RAG and
agents; choosing a use case by value, feasibility and risk; the AI Use-Case Canvas.

- station1_legacy_rtos/     charge_task.c: legacy RTOS code (deliberate defects)
- station2_build_log/       a build that failed twice
- station3_datasheet/       the VC-21 datasheet page; extract registers into a header
- station4_unit_tests/      charge_curve.c (deliberate defects), charge_spec.md, GoogleTest skeleton
- station5_rag/docs/        five VoltEdge documents for a small knowledge assistant
- data/                     task lists and the agent brief for Exercises 1, 7 and 8
- canvas/                   AI_Use_Case_Canvas.md and a VoltEdge worked example
- templates/                the Module 3 templates
- prompts.md                one prompt per station
- exercise_worksheet.md     record your answers here
- scripts/                  extract_registers.py (Station 3), rag_ask.py (Station 5)
- solutions/                answer key, reference tests and a Word solution document: open
                            them only after you have tried each exercise

Scripts (Python 3.10 or later), same .env as Module 2:

    cd scripts
    python -m pip install -r requirements.txt
    python extract_registers.py --mock
    python rag_ask.py --mock

Station 4 needs CMake 3.16 or later, a C and C++ compiler, and network access to download
GoogleTest at configure time (or a local GoogleTest; see the comment in CMakeLists.txt).

Never commit .env. VoltEdge, VoltChip and every code in this kit are fictional.
