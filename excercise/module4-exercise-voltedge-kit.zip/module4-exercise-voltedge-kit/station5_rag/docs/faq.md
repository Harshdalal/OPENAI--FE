# VoltEdge support FAQ

Fictional product, for training.

## How do I read the firmware version?

Type "version" on the UART console at 115200 baud, 8N1. The reply is a line such as
"app: firmware v1.7.1".

## Why did the charger stop and show a solid red LED?

The charger could not trust the battery temperature and entered fault stop (REQ-207, AC3).
It resumes after 20 valid readings in a row (AC5), unless the fault is locked (AC6).

## How do I clear a locked charger fault?

Remove the battery pack and insert it again. There is no console command for it in v1.7.1.

## Which charger IC does VoltEdge use?

The VoltChip VC-21 on SMBus. See VC21_registers.md.
