# VoltEdge charger firmware release notes

Fictional product, for training.

## v1.7.1 (2 Nov 2026)

- Thermistor fault handling follows REQ-207 (fault stop after 4 invalid readings in a row).
- Fault lock: more than 3 fault stops in 10 minutes keeps the charger stopped until the pack
  is reinserted.
- Known issue: the line "chg: fault code=C-118" can be logged twice for one fault
  (VE-BUG-804). Fix planned for v1.7.2.
- Known issue: firmware update over Bluetooth can stop at 60% (VE-BUG-803). Use the USB cable.

## v1.7.0 (20 Oct 2026)

- New charge rules: reduced current from 0.0 °C to 9.9 °C and derating from 45.0 °C
  (charge_spec.md, rules C2 and C4).
- Status over Bluetooth once a second.
