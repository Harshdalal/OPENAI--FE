/*
 * charge_task.c - VoltEdge charge and status tasks (legacy RTOS code, v0.9)
 * RTOS API in the FreeRTOS style. Training file for the Module 4 practice exercises:
 * it contains deliberate defects. VoltEdge is fictional. Do not use in a product.
 */
#include "FreeRTOS.h"
#include "task.h"
#include "queue.h"
#include "semphr.h"
#include <stdio.h>
#include "ve_hal.h"

typedef struct {
    int16_t  t_c10;
    uint16_t current_ma;
} charge_status_t;

static QueueHandle_t     adc_queue;
static SemaphoreHandle_t smb_lock;
static charge_status_t   status;

/* ADC conversion complete interrupt: pass the raw thermistor value to the charge task. */
void ADC1_IRQHandler(void)
{
    uint16_t raw = adc1_result();
    xQueueSend(adc_queue, &raw, portMAX_DELAY);
}

/* High priority: set the charge current from each new reading. */
static void charge_task(void *arg)
{
    uint16_t raw;
    (void)arg;
    for (;;) {
        xQueueReceive(adc_queue, &raw, portMAX_DELAY);
        status.t_c10 = ntc_raw_to_c10(raw);
        status.current_ma = charge_current_for_c10(status.t_c10);
        xSemaphoreTake(smb_lock, portMAX_DELAY);
        if (smb_write_word(VC21_ADDR, VC21_ICHG, status.current_ma / 20u) != 0) {
            continue;
        }
        xSemaphoreGive(smb_lock);
    }
}

/* Low priority: report the status over Bluetooth once a second, and kick the watchdog. */
static void status_task(void *arg)
{
    char line[64];
    (void)arg;
    for (;;) {
        snprintf(line, sizeof line, "t=%.1f C i=%u mA", status.t_c10 / 10.0, status.current_ma);
        ble_notify(line);
        wdt_kick();
        vTaskDelay(1000);
    }
}

void app_start(void)
{
    adc_queue = xQueueCreate(4, sizeof(uint16_t));
    smb_lock  = xSemaphoreCreateMutex();
    xTaskCreate(charge_task, "chg", 96, NULL, 3, NULL);
    xTaskCreate(status_task, "stat", 96, NULL, 1, NULL);
    vTaskStartScheduler();
}
