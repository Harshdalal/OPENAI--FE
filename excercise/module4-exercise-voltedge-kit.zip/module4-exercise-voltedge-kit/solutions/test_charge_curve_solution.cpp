// test_charge_curve_solution.cpp - reference tests for Station 4 (solutions only).
// Expected values come from charge_spec.md, never from running charge_curve.c.
// With the shipped charge_curve.c, three tests fail: 47.3, 59.9 and 60.0 C.
#include <gtest/gtest.h>
#include <cstdint>
#include "charge_curve.h"

static int16_t  fake_temp_c10 = 0;
static int      fake_set_calls = 0;
static uint16_t fake_last_ma = 65535;

extern "C" int16_t ve_battery_read_c10(void) { return fake_temp_c10; }
extern "C" void ve_set_current_ma(uint16_t current_ma) { fake_set_calls++; fake_last_ma = current_ma; }

// The six agreed examples (charge_spec.md)
TEST(ChargeCurve, Example1_MinusPointOneIsOff)        { EXPECT_EQ(charge_current_for_c10(-1), 0); }
TEST(ChargeCurve, Example2_ZeroIsReduced)             { EXPECT_EQ(charge_current_for_c10(0), 500); }
TEST(ChargeCurve, Example3_47Point3RoundsUp)          { EXPECT_EQ(charge_current_for_c10(473), 1890); }
TEST(ChargeCurve, Example4_25IsFull)                  { EXPECT_EQ(charge_current_for_c10(250), 2000); }
TEST(ChargeCurve, Example5_59Point9RoundsUp)          { EXPECT_EQ(charge_current_for_c10(599), 1260); }
TEST(ChargeCurve, Example6_SixtyIsOff)                { EXPECT_EQ(charge_current_for_c10(600), 0); }

// Boundaries between rules
TEST(ChargeCurve, NinePointNineIsReduced)             { EXPECT_EQ(charge_current_for_c10(99), 500); }
TEST(ChargeCurve, TenIsFull)                          { EXPECT_EQ(charge_current_for_c10(100), 2000); }
TEST(ChargeCurve, FortyFourPointNineIsFull)           { EXPECT_EQ(charge_current_for_c10(449), 2000); }
TEST(ChargeCurve, FortyFiveStartsDerating)            { EXPECT_EQ(charge_current_for_c10(450), 2000); }
TEST(ChargeCurve, FortySevenPointFourRoundsToNearest) { EXPECT_EQ(charge_current_for_c10(474), 1880); }

// The control step uses the fakes: no hardware needed
TEST(ChargeControl, StepSetsCurrentFromReading) {
    fake_set_calls = 0;
    fake_temp_c10 = 520;   // 52.0 C: 2000 - 7.0 x 50 = 1650 mA
    charge_control_step();
    EXPECT_EQ(fake_set_calls, 1);
    EXPECT_EQ(fake_last_ma, 1650);
}
