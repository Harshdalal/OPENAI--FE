"""Shared helpers for the Module 4 scripts: settings and the client. Same .env as Module 2."""
import os
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
KIT = HERE.parent
MOCK = "--mock" in sys.argv


def load_env():
    path = HERE / ".env"
    if path.exists():
        for line in path.read_text(encoding="utf-8").splitlines():
            line = line.strip()
            if line and not line.startswith("#") and "=" in line:
                key, value = line.split("=", 1)
                os.environ.setdefault(key.strip(), value.strip().strip('"').strip("'"))


def setting(name):
    value = os.getenv(name, "")
    if not value and not MOCK:
        sys.exit(f"Missing {name} in scripts/.env. Copy .env.example to .env (or reuse Module 2's), or add --mock.")
    return value


def get_client():
    load_env()
    if MOCK:
        print("MOCK MODE: answers are invented by the script, not by a model.\n")
        return None
    try:
        from openai import OpenAI
    except ImportError:
        sys.exit("The openai package is missing. Run: python -m pip install -r requirements.txt")
    base = setting("OPENAI_BASE_URL")
    if os.getenv("AUTH", "key").lower() == "entra":
        from azure.identity import DefaultAzureCredential, get_bearer_token_provider
        return OpenAI(base_url=base, api_key=get_bearer_token_provider(DefaultAzureCredential(), "https://ai.azure.com/.default"))
    return OpenAI(base_url=base, api_key=setting("OPENAI_API_KEY"))


def read(rel):
    return (KIT / rel).read_text(encoding="utf-8")
