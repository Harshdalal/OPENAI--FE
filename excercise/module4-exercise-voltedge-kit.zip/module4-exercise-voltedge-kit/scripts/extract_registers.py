"""Station 3: extract the VC-21 register map as structured output, check it in code, write a C header.

    python extract_registers.py --mock      practice run, no Azure needed
    python extract_registers.py             real run, reads .env (same as Module 2)

Reads station3_datasheet/VC21_registers.md (the text of the datasheet page), asks the model for
JSON that matches a strict schema, runs checks a script can do, and writes output/vc21_regs.h.
The checks catch some errors, not all: a person still compares every value with the PDF.
"""
import json
import os
import re

from common import KIT, MOCK, get_client, read

SCHEMA = {
    "type": "object", "additionalProperties": False, "required": ["part", "registers", "ctrl_fields"],
    "properties": {
        "part": {"type": "string"},
        "registers": {"type": "array", "items": {
            "type": "object", "additionalProperties": False,
            "required": ["address", "name", "access", "reset_value", "description"],
            "properties": {"address": {"type": "string"}, "name": {"type": "string"}, "access": {"type": "string", "enum": ["R", "W", "R/W"]},
                           "reset_value": {"type": "string"}, "description": {"type": "string"}}}},
        "ctrl_fields": {"type": "array", "items": {
            "type": "object", "additionalProperties": False, "required": ["bits", "field", "reset"],
            "properties": {"bits": {"type": "string"}, "field": {"type": "string"}, "reset": {"type": "string"}}}},
    },
}
INSTRUCTIONS = ("You extract register data from datasheets for firmware engineers. Copy values exactly as printed. "
                "Use hex strings such as 0x0003 for addresses and reset values, and binary strings such as 01 for field resets. "
                "ctrl_fields are the fields of the CHG_CTRL register. "
                "Do not add registers or fields that are not on the page.")

MOCK_DATA = {"part": "VC-21", "registers": [
    {"address": "0x00", "name": "STATUS", "access": "R", "reset_value": "0x0000", "description": "Charge state, fault flags"},
    {"address": "0x01", "name": "CHG_CTRL", "access": "R/W", "reset_value": "0x000D", "description": "Charge enable, termination, safety timer"},
    {"address": "0x02", "name": "ICHG", "access": "R/W", "reset_value": "0x00C8", "description": "Charge current, 20 mA per LSB"},
    {"address": "0x03", "name": "NTC_CFG", "access": "R/W", "reset_value": "0x0A3C", "description": "Thermistor cold and hot limits"},
    {"address": "0x0F", "name": "DEVICE_ID", "access": "R", "reset_value": "0x0021", "description": "Device identifier"}],
    "ctrl_fields": [{"bits": "15:4", "field": "-", "reset": "0"}, {"bits": "3:2", "field": "TMR", "reset": "00"},
                    {"bits": "1", "field": "TERM", "reset": "1"}, {"bits": "0", "field": "EN", "reset": "1"}]}


def checks(data):
    """Checks code can do. Each returns a message; an empty list means all passed."""
    problems = []
    regs = data["registers"]
    addrs = [r["address"].lower() for r in regs]
    if len(set(addrs)) != len(addrs):
        problems.append("Two registers share an address.")
    for r in regs:
        for key in ("address", "reset_value"):
            if not re.fullmatch(r"0x[0-9a-fA-F]{1,4}", r[key]):
                problems.append(f"{r['name']}: {key} '{r[key]}' is not a hex value.")
    # Compose CHG_CTRL's reset value from its field resets and compare
    cfg = next((r for r in regs if r["name"].upper() == "CHG_CTRL"), None)
    if cfg:
        value = 0
        for f in data["ctrl_fields"]:
            hi, _, lo = f["bits"].partition(":")
            lo = lo or hi
            width = int(hi) - int(lo) + 1
            bits = f["reset"] if set(f["reset"]) <= {"0", "1"} else "0"
            value |= (int(bits, 2) & ((1 << width) - 1)) << int(lo)
        if int(cfg["reset_value"], 16) != value:
            problems.append(f"CHG_CTRL reset value {cfg['reset_value']} does not match its field resets (0x{value:04X}).")
    # ICHG reset value in mA must sit inside the datasheet's charge current setting range
    ichg = next((r for r in regs if r["name"].upper() == "ICHG"), None)
    if ichg and re.fullmatch(r"0x[0-9a-fA-F]{1,4}", ichg["reset_value"]):
        ma = int(ichg["reset_value"], 16) * 20
        if not 100 <= ma <= 3000:
            problems.append(f"ICHG reset value {ichg['reset_value']} is {ma} mA at 20 mA per LSB, outside 100 to 3000 mA.")
    return problems


def header(data):
    lines = [f"/* {data['part'].lower().replace('-', '')}_regs.h - generated from the datasheet page by extract_registers.py.",
             " * Review every value against the PDF before use. */", "#ifndef VC21_REGS_H", "#define VC21_REGS_H", ""]
    for r in data["registers"]:
        n = re.sub(r"[^A-Z0-9_]", "_", r["name"].upper())
        lines.append(f"#define VC21_REG_{n:<10} {r['address']}u   /* {r['access']}, reset {r['reset_value']} */")
    lines += ["", "#endif", ""]
    return "\n".join(lines)


def main():
    page = read("station3_datasheet/VC21_registers.md")
    client = get_client()
    if MOCK:
        data = MOCK_DATA
    else:
        r = client.responses.create(model=os.environ["MODEL_DEPLOYMENT"], instructions=INSTRUCTIONS, input=page,
                                    text={"format": {"type": "json_schema", "name": "register_map", "schema": SCHEMA, "strict": True}})
        data = json.loads(r.output_text)
    print(f"{len(data['registers'])} registers extracted for {data['part']}:")
    for r in data["registers"]:
        print(f"  {r['address']:<6} {r['name']:<10} {r['access']:<4} reset {r['reset_value']}")
    problems = checks(data)
    print("\nCode checks: " + ("all passed." if not problems else "PROBLEMS FOUND"))
    for p in problems:
        print("  - " + p)
    out = KIT / "output"
    out.mkdir(exist_ok=True)
    (out / "vc21_regs.json").write_text(json.dumps(data, indent=2), encoding="utf-8")
    (out / "vc21_regs.h").write_text(header(data), encoding="utf-8")
    print("\nSaved output/vc21_regs.json and output/vc21_regs.h")
    print("Code checks catch some errors, not all. Compare every value with station3_datasheet/VC21_datasheet_p4.pdf.")


if __name__ == "__main__":
    main()
