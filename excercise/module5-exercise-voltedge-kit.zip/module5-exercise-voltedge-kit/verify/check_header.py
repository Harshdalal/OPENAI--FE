"""check_header.py - compare an AI-generated VC-21 header with the datasheet page.

Usage (from the kit folder):
    python verify/check_header.py ai_outputs/B1_vc21_regs.h docs/VC21_registers.md

Checks register addresses, reset values, CHG_CTRL field bit positions, overlapping masks, the
ICHG step size and the valid thermistor range. It cannot check everything: a person still
reads the datasheet.
"""
import re
import sys


def parse_datasheet(path):
    text = open(path, encoding="utf-8").read()
    regs = {}
    for m in re.finditer(r"^\|\s*(0x[0-9A-Fa-f]+)\s*\|\s*(\w+)\s*\|\s*([RW/]+)\s*\|\s*(0x[0-9A-Fa-f]+)\s*\|", text, re.M):
        regs[m.group(2)] = {"addr": int(m.group(1), 16), "reset": int(m.group(4), 16)}
    fields = {}
    for m in re.finditer(r"^\|\s*(\d+)(?::(\d+))?\s*\|\s*([A-Z]+)\s*\|", text, re.M):
        hi = int(m.group(1)); lo = int(m.group(2)) if m.group(2) else hi
        fields[m.group(3)] = (hi, lo)
    lsb = re.search(r"(\d+)\s*mA per LSB", text)
    rng = re.search(r"Thermistor input valid range\s*\|\s*(-?\d+)\s*\|[^|]*\|\s*(-?\d+)", text)
    return regs, fields, int(lsb.group(1)) if lsb else None, (int(rng.group(1)), int(rng.group(2))) if rng else None


def parse_header(path):
    text = open(path, encoding="utf-8").read()
    return {m.group(1): m.group(2).strip() for m in re.finditer(r"^#define\s+(\w+)\s+(.+?)\s*(?:/\*.*)?$", text, re.M)}


def value(expr):
    m = re.fullmatch(r"\(?\s*(-?(?:0x[0-9A-Fa-f]+|\d+))u?\s*(?:<<\s*(\d+))?\s*\)?", expr)
    if not m:
        return None
    v = int(m.group(1), 0)
    return v << int(m.group(2)) if m.group(2) else v


def main():
    if len(sys.argv) != 3:
        print(__doc__)
        return 2
    regs, fields, lsb, rng = parse_datasheet(sys.argv[2])
    defs = parse_header(sys.argv[1])
    problems, ok = [], 0

    for name, d in regs.items():
        for kind, key, want in (("address", f"VC21_REG_{name}", d["addr"]), ("reset value", f"VC21_RESET_{name}", d["reset"])):
            got = value(defs.get(key, ""))
            if got is None:
                problems.append(f"{key}: missing or not a plain number")
            elif got != want:
                problems.append(f"{key}: header says 0x{got:04X}, datasheet says 0x{want:04X} ({name} {kind})")
            else:
                ok += 1

    masks = {}
    for f, (hi, lo) in fields.items():
        key = next((k for k in defs if k.startswith(f"VC21_CHG_CTRL_{f}")), None)
        want = ((1 << (hi - lo + 1)) - 1) << lo
        got = value(defs[key]) if key else None
        if got is None:
            problems.append(f"CHG_CTRL.{f}: no mask in the header")
            continue
        masks[f] = got
        if got != want:
            problems.append(f"{key}: mask 0x{got:04X}, datasheet bits {hi}:{lo} give 0x{want:04X}")
        else:
            ok += 1
    names = list(masks)
    for i, a in enumerate(names):
        for b in names[i + 1:]:
            if masks[a] & masks[b]:
                problems.append(f"CHG_CTRL masks {a} and {b} overlap (0x{masks[a] & masks[b]:04X})")

    if lsb is not None:
        got = value(defs.get("VC21_ICHG_MA_PER_LSB", ""))
        if got != lsb:
            problems.append(f"VC21_ICHG_MA_PER_LSB = {got} mA, datasheet says {lsb} mA per LSB")
        else:
            ok += 1
    if rng is not None:
        lo, hi = value(defs.get("VC21_NTC_MIN_C", "")), value(defs.get("VC21_NTC_MAX_C", ""))
        if (lo, hi) != rng:
            problems.append(f"Thermistor range in the header is {lo} to {hi} C, datasheet says {rng[0]} to {rng[1]} C")
        else:
            ok += 1

    print(f"{ok} value(s) match the datasheet.")
    for p in problems:
        print("  MISMATCH:", p)
    print("The mA-to-register macro is checked separately: verify/b1_header_test.c (run_checks.py builds it).")
    return 1 if problems else 0


if __name__ == "__main__":
    sys.exit(main())
