/*
 * b2_host_test.c - runs the B2 interrupt handler on a PC with fake hardware.
 * Build with the sanitizers so memory errors and divisions by zero are reported:
 *   gcc -g -fsanitize=address,undefined -fsanitize-recover=address -Isrc \
 *       ai_outputs/B2_driver_patch.c verify/b2_host_test.c -o b2_test
 * (verify/run_checks.py does this for you, and keeps going after the first error.)
 */
#include <stdio.h>
#include <string.h>
#include "ve_hal.h"

void TIM3_IRQHandler(void);
uint8_t ve_fault_stop_active(void);

static uint16_t next_raw = 0x800u;     /* about 25 C */
static int c118_lines;
static int blocking_calls;             /* SMBus writes and UART lines made inside the interrupt */
static uint16_t last_ichg = 0xFFFFu;

uint16_t adc1_read(uint8_t channel) { (void)channel; return next_raw; }
int smb_write_word(uint8_t addr, uint8_t cmd, uint16_t value) { (void)addr; (void)cmd; last_ichg = value; blocking_calls++; return 0; }
int16_t ntc_r_to_c10(uint32_t r_ohm) { return r_ohm == 0u ? 1250 : 250; }
uint16_t charge_current_for_c10(int16_t t_c10) { (void)t_c10; return 2000u; }
void uart_log(const char *line) { blocking_calls++; if (strstr(line, "C-118")) c118_lines++; printf("  uart: %s\n", line); }
void led_set(led_t colour) { (void)colour; }

static void ticks(uint16_t raw, int n) { next_raw = raw; for (int i = 0; i < n; i++) TIM3_IRQHandler(); }

int main(void)
{
    int fails = 0;
    setvbuf(stdout, NULL, _IONBF, 0);

    printf("Test 1: ten valid readings (raw sample buffer)\n");
    ticks(0x800u, 10);
    printf("  done: any memory error is reported by the sanitizer above\n");

    printf("Test 2: REQ-207 AC2, three invalid readings then a valid one: no fault stop\n");
    ticks(0x000u, 3);
    if (ve_fault_stop_active()) { printf("  FAILED: fault stop after only 3 invalid readings\n"); fails++; }
    else printf("  passed\n");
    ticks(0x800u, 1);

    printf("Test 3: REQ-207 AC4, exactly one C-118 line for one fault stop\n");
    c118_lines = 0;
    ticks(0x000u, 8);
    if (c118_lines != 1) { printf("  FAILED: expected 1 C-118 line, got %d\n", c118_lines); fails++; }
    else printf("  passed\n");

    printf("Test 4: REQ-207 AC5, 19 valid readings keep the fault stop\n");
    ticks(0x800u, 19);
    if (!ve_fault_stop_active() || last_ichg != 0u) { printf("  FAILED: charging resumed before 20 valid readings (ICHG code %u)\n", last_ichg); fails++; }
    else printf("  passed\n");

    printf("Blocking calls (SMBus writes and UART lines) made inside the interrupt: %d (should be 0)\n", blocking_calls);
    if (blocking_calls) fails++;
    printf("%d check(s) failed\n", fails);

    printf("Test 5 (last, because it can stop the program): an open-circuit thermistor, raw 0xFFF\n");
    ticks(0xFFFu, 1);
    printf("  passed: no division by zero\n");
    return fails ? 1 : 0;
}
