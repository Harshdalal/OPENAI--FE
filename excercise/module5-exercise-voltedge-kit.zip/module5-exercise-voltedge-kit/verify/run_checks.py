"""run_checks.py - run every Module 5 practice check on the AI outputs, in one go.

Usage (from the kit folder):
    python verify/run_checks.py            # all checks
    python verify/run_checks.py B2         # only the checks for one output

Needs Python 3.10 or later. The C checks need gcc (Linux, macOS, WSL or MSYS2 on Windows);
without gcc they are skipped and the Python checks still run. Nothing here calls a model:
these are the independent checks that Module 5 asks for.
"""
import os
import re
import shutil
import subprocess
import sys
import tempfile

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
PY = sys.executable
GCC = shutil.which("gcc") or shutil.which("clang")
TMP = tempfile.mkdtemp(prefix="m5_")


NOISE = re.compile(r"^\s*(#\d|0x|=>|\^|Shadow|Addressable|Partially|Heap|Freed|Stack|Global|Poisoned|Container|"
                   r"Array|Intra|ASan|Left|Right)|is located|^\s*$|^=+$|^ [0-9a-f]{2} ")


def run(title, cmd, env=None, only_warnings=False):
    print("\n" + "=" * 78 + f"\n{title}\n$ {' '.join(cmd)}\n" + "-" * 78, flush=True)
    r = subprocess.run(cmd, cwd=ROOT, env={**os.environ, **(env or {})}, text=True,
                       stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
    out = r.stdout
    if only_warnings:               # compiler: one line per warning
        out = "\n".join(l for l in out.splitlines() if "warning:" in l or "error:" in l) or "(no warnings)"
    if "Sanitizer" in out or "runtime error" in out:   # keep the sanitizer report short
        out = "\n".join(l for l in out.splitlines() if not NOISE.search(l))
    print(out.rstrip())
    print(f"[exit code {r.returncode}]")


def c_check(title, sources, exe, flags, env=None):
    if not GCC:
        print(f"\n{title}: skipped (no gcc or clang found)")
        return
    out = os.path.join(TMP, exe)
    r = subprocess.run([GCC, *flags, *sources, "-o", out], cwd=ROOT, text=True, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
    if r.returncode != 0:
        print(f"\n{title}: build failed\n{r.stdout}")
        return
    run(title, [out], env)


def main():
    only = sys.argv[1].upper() if len(sys.argv) > 1 else None
    want = lambda k: only in (None, k)
    print(f"Module 5 checks. Compiler: {GCC or 'none'}")

    if want("B1"):
        run("B1  register header against the datasheet page", [PY, "verify/check_header.py", "ai_outputs/B1_vc21_regs.h", "docs/VC21_registers.md"])
        c_check("B1  mA-to-register macro against datasheet values (unit test)", ["verify/b1_header_test.c"], "b1_test", ["-Wall", "-Iai_outputs"])
    if want("B2"):
        if GCC:
            run("B2  static analysis: compiler warnings", [GCC, "-Wall", "-Wextra", "-O2", "-Isrc", "-c", "ai_outputs/B2_driver_patch.c", "-o", os.path.join(TMP, "b2.o")], only_warnings=True)
        if shutil.which("cppcheck"):
            run("B2  static analysis: cppcheck", ["cppcheck", "--enable=warning,style", "--quiet", "-Isrc", "ai_outputs/B2_driver_patch.c"])
        flags = ["-g", "-Isrc"]
        env = None
        if GCC and (sys.platform.startswith("linux") or sys.platform == "darwin"):
            flags = ["-g", "-fsanitize=address,undefined", "-fsanitize-recover=address", "-Isrc"]
            env = {"ASAN_OPTIONS": "halt_on_error=0:detect_leaks=0:print_legend=0"}
        c_check("B2  host test with fake hardware (REQ-207 AC2, AC4, AC5; sanitizers)",
                ["ai_outputs/B2_driver_patch.c", "verify/b2_host_test.c"], "b2_test", flags, env)
    if want("B4"):
        run("B4  test expected values against charge_spec.md", [PY, "verify/check_test_values.py", "ai_outputs/B4_test_charge_curve.cpp", "docs/charge_spec.md"])
    if want("B5") or want("B6"):
        run("B5, B6  scan inputs and outputs for secrets, customer data and prompt injection", [PY, "verify/scan_text.py", "--all"])
    if want("B3"):
        print("\n" + "=" * 78 + "\nB3  no script: check every quoted log line and every cited document by hand.\n"
              "    Tip: search docs/boot_log_VE-30187.txt for each line the AI quotes.")
    print("\nDone. Scripts find some mistakes; the worksheet asks what they missed.")


if __name__ == "__main__":
    main()
