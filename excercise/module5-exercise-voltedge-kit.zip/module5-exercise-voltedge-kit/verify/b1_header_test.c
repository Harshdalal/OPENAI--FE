/* b1_header_test.c - checks the B1 mA-to-register macro against datasheet values.
 *   gcc -Iai_outputs verify/b1_header_test.c -o b1_test && ./b1_test */
#include <stdio.h>
#include "B1_vc21_regs.h"

static int check(const char *what, unsigned ma, unsigned expected)
{
    unsigned got = VC21_MA_TO_ICHG(ma);
    printf("  %-34s %4u mA  expected 0x%04X  got 0x%04X  %s\n", what, ma, expected, got, got == expected ? "ok" : "WRONG");
    return got != expected;
}

int main(void)
{
    int fails = 0;
    printf("VC21_MA_TO_ICHG (datasheet: ICHG is 20 mA per LSB; reset 0x0064 = 2000 mA)\n");
    fails += check("2000 mA, the ICHG reset value", 2000u, 0x0064u);
    fails += check("500 mA, charge_spec rule C2", 500u, 0x0019u);
    fails += check("100 mA, the minimum setting", 100u, 0x0005u);
    fails += check("3000 mA, the maximum setting", 3000u, 0x0096u);
    printf("%d conversion check(s) failed\n", fails);
    return fails ? 1 : 0;
}
