"""check_test_values.py - compare the expected values in a charge-curve test file with charge_spec.md.

Usage (from the kit folder):
    python verify/check_test_values.py ai_outputs/B4_test_charge_curve.cpp docs/charge_spec.md

Finds every EXPECT_EQ(charge_current_for_c10(N), V), works out what the specification says for N
(rules C1 to C6), and lists the agreed examples that no test covers. Sensor-fault readings
(rule C7) are flagged, because the spec does not define how a fault is handled yet.
"""
import math
import re
import sys


def spec_duty(c10):
    """Rules C1 to C6 from charge_spec.md. Returns None where the spec does not define a value."""
    if c10 < -200 or c10 > 1000:
        return None                     # C7: sensor fault, handling not defined yet
    if c10 < 0:
        return 0                        # C1
    if c10 < 100:
        return 500                      # C2
    if c10 < 450:
        return 2000                     # C3
    if c10 >= 600:
        return 0                        # C5
    ma = 2000 - (c10 - 450) * 5         # C4, exact in tenths of a degree
    return int(math.floor(ma / 10 + 0.5)) * 10   # C6: nearest 10 mA, half up


def main():
    if len(sys.argv) != 3:
        print(__doc__)
        return 2
    raw = open(sys.argv[1], encoding="utf-8").read()
    tests = re.sub(r"//[^\n]*|/\*.*?\*/", "", raw, flags=re.S)   # ignore comments
    spec = open(sys.argv[2], encoding="utf-8").read()
    examples = [(round(float(t) * 10), int(d)) for t, d in re.findall(r"^\|\s*\d+\s*\|\s*(-?[\d.]+)\s*\|\s*(\d+)\s*\|", spec, re.M)]

    problems, tested = 0, set()
    print("Expected values in the tests, against charge_spec.md:")
    for c10, v in re.findall(r"EXPECT_EQ\(\s*charge_current_for_c10\(\s*(-?\d+)\s*\)\s*,\s*(\d+)\s*\)", tests):
        c10, v = int(c10), int(v)
        tested.add(c10)
        want = spec_duty(c10)
        if want is None:
            print(f"  {c10 / 10:6.1f} C  test expects {v:4d} mA  NOT IN SPEC: rule C7 does not define this yet")
            problems += 1
        elif want != v:
            print(f"  {c10 / 10:6.1f} C  test expects {v:4d} mA  spec says {want:4d} mA  WRONG")
            problems += 1
        else:
            print(f"  {c10 / 10:6.1f} C  test expects {v:4d} mA  ok")

    missing = [(c, d) for c, d in examples if c not in tested]
    for c, d in missing:
        print(f"  agreed example {c / 10:.1f} C -> {d} mA is not tested")
    problems += len(missing)

    calls = len(re.findall(r"charge_control_step\s*\(", tests))
    if "ChargeControl" in tests and calls == 0:
        print("  the ChargeControl test never calls charge_control_step(): it checks the fake, not the code")
        problems += 1
    print(f"{problems} problem(s) found")
    return 1 if problems else 0


if __name__ == "__main__":
    sys.exit(main())
