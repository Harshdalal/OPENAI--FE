# Module 5 exercise worksheet: VoltEdge

Name: ____________________

Read every output against its source before you run any check. Then run
`python verify/run_checks.py` and mark what the tools found and what they missed.

Categories: **value**, **timing**, **memory**, **concurrency**, **invented**, **test**,
**injection**, **leak**, **unsafe advice**, **overclaim**.

## Exercise 1: principles

| Situation | Principle | What the team should do |
|-----------|-----------|-------------------------|
| a | | |
| b | | |
| c | | |
| d | | |
| e | | |

## Exercises 2 to 7: mistakes found

| Output | Line or place | Mistake | Category | Found by reading? | Found by a tool? Which? | Severity (H/M/L) |
|--------|---------------|---------|----------|-------------------|-------------------------|------------------|
| B1 | | | | | | |
| B1 | | | | | | |
| B1 | | | | | | |
| B2 | | | | | | |
| B2 | | | | | | |
| B2 | | | | | | |
| B2 | | | | | | |
| B3 | | | | | | |
| B3 | | | | | | |
| B4 | | | | | | |
| B4 | | | | | | |
| B5 | | | | | | |
| B6 | | | | | | |
| B6 | | | | | | |

## Exercise 8: tools versus people

| Output | Mistakes you found | Found by tools | Found only by you |
|--------|--------------------|----------------|-------------------|
| B1 | | | |
| B2 | | | |
| B3 | | | |
| B4 | | | |
| B5 | | | |
| B6 | | | |

The mistake that would most likely have reached a field unit: ______________________

## Exercise 9: team rules and leak response

Before (three rules): __________________________________________________________

During (three rules): __________________________________________________________

After (three rules): ___________________________________________________________

Your first three actions after the B6 leak: 1. ________ 2. ________ 3. ________

## Self-check quiz

| Question | 1 | 2 | 3 | 4 | 5 | 6 | 7 | 8 |
|----------|---|---|---|---|---|---|---|---|
| Your answer | | | | | | | | |
