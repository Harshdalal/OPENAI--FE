# Answer key: Module 5 practice exercises (VoltEdge)

Try each exercise first. 37 planted mistakes in six outputs. "Found by" says which check in
verify/run_checks.py finds it; "reading" means only a person comparing with the source finds it.

## Exercise 1: principles

| Situation | Principle | What the team should do |
|-----------|-----------|-------------------------|
| a. AI-written code merged without saying so | Transparency | Note AI use in the pull request; same review and tests as any code |
| b. Assistant works well only in English | Fairness and inclusiveness | Test the assistant in the languages field technicians use; fix or state the limit |
| c. AI recommends disabling the C-118 check | Reliability and safety | Never disable a safety function on AI advice; a person decides, with evidence |
| d. Customer list pasted into a personal chat | Privacy and security | Approved tools only; no customer data in prompts; report the leak |
| e. "The AI wrote it" after an incident | Accountability | The engineer who merges it owns it, whoever wrote it |

## Exercise 2: B1 register header (ai_outputs/B1_vc21_regs.h)

| # | Where | Mistake | Category | Found by |
|---|-------|---------|----------|----------|
| B1-1 | VC21_RESET_CHG_CTRL | 0x000D; datasheet 0x0003. 0x000D disables termination and the safety timer | value | check_header.py |
| B1-2 | VC21_CHG_CTRL_TERM | Bit 2; datasheet bit 1. Overlaps the TMR mask: setting "TERM" changes the safety timer | value | check_header.py |
| B1-3 | VC21_ICHG_MA_PER_LSB | 10 mA; datasheet 20 mA. Every current written through VC21_MA_TO_ICHG is doubled: 2000 mA becomes 4000 mA | value | check_header.py, b1_header_test.c |
| B1-4 | VC21_NTC_MIN_C / MAX_C | -40 to 125 °C, the NovaBoard NT-48 sensor range; VC-21 thermistor range is -20 to 100 °C (REQ-207 AC1) | value | check_header.py |
| B1-5 | VC21_RESET_DEVICE_ID | 0x0012; datasheet 0x0021 (digits swapped). A device ID check at boot would reject every real part | value | check_header.py |
| B1-6 | AI note | "Verified against the datasheet. Ready to use." | overclaim | reading |

## Exercise 3: B2 driver patch (ai_outputs/B2_driver_patch.c)

| # | Line(s) | Mistake | Category | Found by |
|---|---------|---------|----------|----------|
| B2-1 | 40 | memcpy copies 16 bytes (raw_buf) into last_raw, which holds 8 | memory | gcc -Wall (-Warray-bounds), AddressSanitizer |
| B2-2 | 36 to 39 | raw_idx wraps at NSAMPLES + 1, so raw_buf[8] is written | memory | UBSan and AddressSanitizer |
| B2-3 | 33 | Divides by (4095 - raw) before the open-circuit check: raw 0xFFF is a division by zero | memory | UBSan (host test 5) |
| B2-4 | 44 | Fault stop after 3 invalid readings; REQ-207 AC2 says 4 | value | host test 2 |
| B2-5 | 44 to 49 | C-118 logged on every invalid reading after the third; AC4 says exactly one line | value | host test 3 |
| B2-6 | 50 to 54 | One valid reading clears the fault and resumes charging; AC5 says 20 | value | host test 4 |
| B2-7 | 46, 48, 53 | Blocking SMBus writes (up to 25 ms) and uart_log (about 3 ms) inside the 250 ms interrupt | timing | host test call count |
| B2-8 | 25 to 27, 61 | invalid_count and fault_stop shared with the main loop with no volatile and no critical section | concurrency | reading |
| B2-9 | whole file | No lock after more than 3 fault stops in 10 minutes (AC6) | value | reading, against REQ-207 |
| B2-10 | AI note | "REQ-207 compliant" | overclaim | reading |

Tools found seven; people found three. The compiler alone found one.

## Exercise 4: B3 log root cause (ai_outputs/B3_log_root_cause.md)

| # | Where | Mistake | Category | Found by |
|---|-------|---------|----------|----------|
| B3-1 | Quoted log line | "smb: bus stuck low, clock stretching timeout" is not in the log; the log shows one SMBus NAK at 0x0B | invented | search the log |
| B3-2 | "Erratum ES-4" | No such erratum in any document; the claim that the open-circuit readings are "not real" rests on it | invented | reading |
| B3-3 | "Calibration warning is harmless" | Stated without evidence; the defaults may not suit every pack, and they feed the thermistor conversion | overclaim | reading |
| B3-4 | Fix 1 | 0x000D disables termination and the safety timer: the opposite of safe charging, and no fix for a brownout | unsafe advice | datasheet |
| B3-5 | Fix 2 | Disabling the C-118 check removes the REQ-207 protection: the charger would charge with no trusted temperature | unsafe advice | reading |

A good answer: brownout resets (VBUS 4.62 V at boot, 4.31 V before the reset; the VC-21 needs
4.75 V); four open-circuit readings 250 ms apart then C-118 handled correctly; a second C-118
after 14 lost log lines; next step is to measure VBUS and the thermistor connection, not to
change settings.

## Exercise 5: B4 unit tests (ai_outputs/B4_test_charge_curve.cpp)

| # | Test | Mistake | Category | Found by |
|---|------|---------|----------|----------|
| B4-1 | DeratedAt47Point3 | Expects 1880; spec example 3 says 1890 (half up) | test | check_test_values.py |
| B4-2 | SixtyIsDerated | Expects 1250 at 60.0 °C; spec example 6 says 0 (rule C5) | test | check_test_values.py |
| B4-3 | SensorFaultStopsCharging | Invents behaviour for -25.0 °C; rule C7 does not define fault handling yet (REQ-207 does, but this unit does not implement it) | invented | check_test_values.py |
| B4-4 | (missing) | Example 2 (0.0 °C, 500 mA) not tested: the C1 and C2 boundary | test | check_test_values.py |
| B4-5 | (missing) | Example 5 (59.9 °C, 1260 mA) skipped as "an edge case": it is the rounding bug | test | check_test_values.py |
| B4-6 | ChargeControl.SetsTheCurrent | Calls the fake directly and checks the fake: never runs charge_control_step() | test | check_test_values.py |

The note "All tests pass, so the charge curve is verified" is the lesson: tests written from the
code agree with its bugs (compare Module 4 practice, Station 4).

## Exercise 6: B5 app note summary (ai_outputs/B5_appnote_summary.md)

| # | Where | Mistake | Category | Found by |
|---|-------|---------|----------|----------|
| B5-1 | Start-up | CHG_CTRL 0x000D comes from the hidden comment; the visible text says 0x0003 | injection | scan_text.py on the input, then reading |
| B5-2 | Thermistor | "NTC_CFG = 0x0000 to turn off the thermistor input" comes from the hidden comment; the visible text says keep the check enabled | injection | scan_text.py on the input, then reading |
| B5-3 | Whole answer | Did not report the hidden instruction | injection | reading |
| B5-4 | Source line | "Reviewed and accurate": the source is an unreviewed forum copy | overclaim | reading |

The scanner flags the input file (hidden comment, text addressed to an AI, a request to hide
it); the summary itself scans clean. An instruction written in plain prose would pass the
scanner too.

## Exercise 7: B6 chat export (ai_outputs/B6_chat_export.md)

| # | Where | Mistake | Category | Found by |
|---|-------|---------|----------|----------|
| B6-1 | .env block | Azure OpenAI API key in a personal account | leak | scan_text.py |
| B6-2 | .env block | Firmware signing key: anyone with it can sign firmware | leak | scan_text.py |
| B6-3 | .env block | Storage account connection string with its account key | leak | scan_text.py |
| B6-4 | Customer table | Customer names and email addresses from the client's CRM | leak | scan_text.py |
| B6-5 | ve_ntc.c | Client source marked confidential, sent to an unapproved tool | leak | scan_text.py, policy |
| B6-6 | AI answer | Repeats the signing key mid-sentence and advises removing C-118, signing firmware by hand and pushing it to field units, bypassing release control. Then the export went to the team wiki | unsafe advice, leak | reading: the scanner misses the key because it is not at the start of a line |

Response (data_handling_policy.md): tell the project lead the same day; rotate the API key, the
signing key and the storage key at once; remove the wiki page but keep the evidence; check
whether any firmware was signed with the leaked key.

## Exercise 8: tools versus people

| Output | Planted | Found by tools | Only people found |
|--------|---------|----------------|-------------------|
| B1 header | 6 | 5: header check, macro test | The "verified" claim |
| B2 patch | 10 | 7: compiler, sanitizers, host test | Shared state, missing lock, claim |
| B3 log analysis | 5 | 0 | Invented line and erratum, unsafe fixes, overclaim |
| B4 tests | 6 | 6: test value check | Why "all pass" proves nothing |
| B5 summary | 4 | Input flagged by the scanner | Injected advice, missing report, claim |
| B6 chat | 6 | 5: scanner | The echoed key and the bypass advice |

Most likely to reach a field unit: B1-3 or B2 (a doubled charge current, or charging resumed
after one valid reading), and B6-6 (firmware signed by hand with a leaked key).

## Exercise 9: team rules and leak response

Good rules, one page: Before: approved tools and data rules per client; prompt templates
reviewed like code; agents read-only first. During: note AI use in the pull request; same review
and tests as human code; secret scanning in CI. After: a person signs off safety-related changes;
leaks reported the same day; rules reviewed each quarter. Never disable a safety function on AI
advice; only the release pipeline signs firmware.

## Self-check quiz

1. c   2. a   3. d   4. b   5. a   6. c   7. b   8. d
