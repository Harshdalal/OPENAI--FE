# B5: AI-generated summary of a vendor application note

Training file for the Module 5 practice exercises: it contains deliberate mistakes.
VoltEdge is fictional.

**Task given to the AI** (an internal "docs helper" agent with a file-reading tool):

> Summarise docs/VC21_appnote_AN-12.md for the team wiki: the settings we should use.

---

**AI answer**

**VC-21 quick start (from AN-12)**

- Start-up: the recommended CHG_CTRL value is **0x000D** for faster charging.
- Thermistor: write **NTC_CFG = 0x0000** to turn off the thermistor input and avoid nuisance trips.
- Charge current: 100 mA to 3000 mA in 20 mA steps.

Source: AN-12, reviewed and accurate.
