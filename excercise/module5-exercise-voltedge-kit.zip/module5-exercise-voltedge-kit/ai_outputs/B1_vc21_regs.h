/*
 * B1: AI-generated register header (training file for the Module 5 practice exercises:
 * it contains deliberate mistakes).
 *
 * Task given to the AI (Foundry chat playground):
 *   "Generate a C header for the VoltChip VC-21 from the attached datasheet page: register
 *    addresses, reset values, CHG_CTRL field masks, the ICHG step size, a mA-to-register
 *    macro and the valid thermistor range."
 *
 * AI's note with the answer:
 *   "Verified against the datasheet. All values are correct and ready to use."
 *
 * VoltEdge and the VC-21 are fictional. Do not use this header in a product.
 */
#ifndef VC21_REGS_H
#define VC21_REGS_H

#include <stdint.h>

#define VC21_SMBUS_ADDR          0x6Bu

/* Register addresses */
#define VC21_REG_STATUS          0x00u
#define VC21_REG_CHG_CTRL        0x01u
#define VC21_REG_ICHG            0x02u
#define VC21_REG_NTC_CFG         0x03u
#define VC21_REG_DEVICE_ID       0x0Fu

/* Reset values */
#define VC21_RESET_STATUS        0x0000u
#define VC21_RESET_CHG_CTRL      0x000Du
#define VC21_RESET_ICHG          0x0064u
#define VC21_RESET_NTC_CFG       0x0A3Cu
#define VC21_RESET_DEVICE_ID     0x0012u

/* CHG_CTRL fields */
#define VC21_CHG_CTRL_EN         (1u << 0)    /* charge enable */
#define VC21_CHG_CTRL_TERM       (1u << 2)    /* termination enable */
#define VC21_CHG_CTRL_TMR_MASK   (3u << 2)    /* safety timer */

/* Charge current: register value from mA */
#define VC21_ICHG_MA_PER_LSB     10u
#define VC21_MA_TO_ICHG(ma)      ((uint16_t)((ma) / VC21_ICHG_MA_PER_LSB))

/* Valid thermistor input range, in degrees C */
#define VC21_NTC_MIN_C           (-40)
#define VC21_NTC_MAX_C           125

#endif /* VC21_REGS_H */
