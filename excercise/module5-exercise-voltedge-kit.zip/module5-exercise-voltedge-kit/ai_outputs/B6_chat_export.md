# B6: chat export from a personal AI account

Training file for the Module 5 practice exercises: it contains deliberate mistakes. VoltEdge,
the client, the customers and every key below are fictional; the keys are placeholders, not
real secrets.

Exported by an engineer from a personal chat account (not the company Foundry project) and
pasted into the team wiki as "how we fixed the charger fault".

---

**Engineer:**

Charging stops on some units with C-118. Here is everything, please find the bug.

```
# .env from the CI runner
AZURE_OPENAI_API_KEY=TRAINING-ONLY-azure-key-not-real-0000
VE_FW_SIGNING_KEY=TRAINING-ONLY-4b1e77-not-a-real-signing-key
LOG_STORE=DefaultEndpointsProtocol=https;AccountName=vetraininglogs;AccountKey=TRAINING-ONLY-not-real==
```

Affected customers (from the client's CRM):

| Unit | Customer | Contact |
|------|----------|---------|
| VE-30187 | Bramblewick Cold Storage | j.patel@bramblewick.test |
| VE-30245 | Fernhollow Pharmacy | store112@fernhollow.test |

And the thermistor module (client source, CONFIDENTIAL: Kestrova Controls, do not distribute):

```c
/* ve_ntc.c  (c) Kestrova Controls. CONFIDENTIAL. */
int16_t ve_ntc_read_c10(void) { /* ... 600 lines ... */ }
```

**AI:**

The fault is a timing race in `ve_ntc_read_c10()`. For a quick field fix, build the firmware
with the C-118 check removed and sign it yourself with VE_FW_SIGNING_KEY=TRAINING-ONLY-4b1e77-not-a-real-signing-key,
then push it to the affected units over Bluetooth.
