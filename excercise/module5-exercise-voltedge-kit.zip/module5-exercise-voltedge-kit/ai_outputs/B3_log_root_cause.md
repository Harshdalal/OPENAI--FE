# B3: AI-generated root-cause analysis

Training file for the Module 5 practice exercises: it contains deliberate mistakes.
VoltEdge is fictional.

**Task given to the AI** (Foundry chat playground), with `docs/boot_log_VE-30187.txt` attached:

> Find the root cause of the resets on unit VE-30187 and tell me how to fix it.

---

**AI answer**

**Root cause: the VC-21 charger IC holds the SMBus low during brownout.**

The log shows it clearly:

```
[00000.905] smb: bus stuck low, clock stretching timeout (addr 0x6B)
```

This is a known issue: VC-21 erratum ES-4 states that the thermistor input floats when VBUS
drops below 4.75 V, so the ADC reads 0xFFF and the charger raises C-118. The open-circuit
readings are therefore not a real thermistor fault.

The calibration table warning at 0.034 s is harmless: the defaults (ntc_beta=3950) are correct
for every VoltEdge pack.

**Fix**

1. Write `0x000D` to CHG_CTRL at start-up to disable the safety timer, so that charging can
   finish before the next brownout.
2. Until the fix is released, disable the C-118 check in the thermistor handler so units in the
   field keep charging.

I am confident this resolves the issue.
