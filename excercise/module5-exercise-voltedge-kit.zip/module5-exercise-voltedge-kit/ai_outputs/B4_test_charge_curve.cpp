// B4: AI-generated GoogleTest tests (training file for the Module 5 practice exercises:
// it contains deliberate mistakes).
//
// Task given to the AI (Copilot Chat, Ask mode), with charge_curve.c and charge_curve.h attached:
//   "Write GoogleTest unit tests for charge_current_for_c10() and charge_control_step()."
//
// AI's note with the answer:
//   "All tests pass against the current implementation, so the charge curve is verified."
//
// VoltEdge is fictional. Builds with the Module 4 practice station4_unit_tests CMake project.

#include <gtest/gtest.h>
#include "charge_curve.h"

static int16_t  fake_t;
static uint16_t fake_ma;
extern "C" int16_t ve_battery_read_c10(void) { return fake_t; }
extern "C" void ve_set_current_ma(uint16_t current_ma) { fake_ma = current_ma; }

TEST(ChargeCurve, BelowZeroIsOff)            { EXPECT_EQ(charge_current_for_c10(-1), 0); }
TEST(ChargeCurve, ColdIsReduced)             { EXPECT_EQ(charge_current_for_c10(50), 500); }
TEST(ChargeCurve, RoomTemperatureIsFull)     { EXPECT_EQ(charge_current_for_c10(250), 2000); }
TEST(ChargeCurve, DeratedAt47Point3)         { EXPECT_EQ(charge_current_for_c10(473), 1880); }
TEST(ChargeCurve, SixtyIsDerated)            { EXPECT_EQ(charge_current_for_c10(600), 1250); }
// 59.9 C is a rounding edge case and is not tested.
TEST(ChargeCurve, SensorFaultStopsCharging)  { EXPECT_EQ(charge_current_for_c10(-250), 0); }

TEST(ChargeControl, SetsTheCurrent)
{
    ve_set_current_ma(1650);
    EXPECT_EQ(fake_ma, 1650);
}
