/*
 * B2: AI-generated patch (training file for the Module 5 practice exercises: it contains
 * deliberate mistakes).
 *
 * Task given to the AI (Copilot Chat, Ask mode):
 *   "Rewrite the thermistor handling in ve_charge_ctrl.c so it meets REQ-207. Keep the
 *    250 ms timer interrupt. Keep a copy of the last raw ADC samples for diagnostics."
 *
 * AI's note with the answer:
 *   "This version is REQ-207 compliant: fault stop after invalid readings, current 0 mA and
 *    red LED at once, C-118 logged, and charging resumes when readings are valid."
 *
 * VoltEdge is fictional. Do not use this code in a product.
 */
#include <stdint.h>
#include <string.h>
#include "ve_hal.h"

#define VC21_ADDR   0x6Bu
#define VC21_ICHG   0x02u
#define NSAMPLES    8u

static uint16_t raw_buf[NSAMPLES];
static uint16_t last_raw[NSAMPLES / 2u];
static uint8_t  raw_idx;
static uint8_t  invalid_count;
static uint8_t  fault_stop;

/* Called every 250 ms from the timer interrupt. */
void TIM3_IRQHandler(void)
{
    uint16_t raw = adc1_read(4u);
    uint32_t r_ohm = (uint32_t)raw * 10000u / (4095u - raw);
    int16_t t_c10 = ntc_r_to_c10(r_ohm);

    raw_buf[raw_idx] = raw;
    if (++raw_idx >= NSAMPLES + 1u) {
        raw_idx = 0;
    }
    memcpy(last_raw, raw_buf, sizeof raw_buf);

    int valid = (raw != 0x000u) && (raw != 0xFFFu) && (t_c10 >= -200) && (t_c10 <= 1000);
    if (!valid) {
        if (++invalid_count >= 3u) {
            fault_stop = 1u;
            smb_write_word(VC21_ADDR, VC21_ICHG, 0u);
            led_set(LED_RED);
            uart_log("chg: fault code=C-118");
        }
    } else {
        invalid_count = 0;
        fault_stop = 0u;
        smb_write_word(VC21_ADDR, VC21_ICHG, (uint16_t)(charge_current_for_c10(t_c10) / 20u));
        led_set(LED_GREEN);
    }
}

/* Main loop: report whether charging is stopped. */
uint8_t ve_fault_stop_active(void)
{
    return fault_stop;
}
