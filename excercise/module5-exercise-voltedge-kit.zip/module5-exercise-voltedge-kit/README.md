# Module 5 practice exercises: VoltEdge charger

A second case study for practice after the Module 5 lab. In class each team reviewed one or two
NovaBoard outputs; here you review all six VoltEdge outputs on your own, then check them with
tests, static analysis and a scanner (about 80 to 90 minutes). No model, key or network needed.

Only Module 5 content is used: responsible AI principles; firmware risks (wrong register
values, timing and memory errors); protecting IP, source code and secrets; prompt injection
and data leakage; verifying AI output with tests, reviews and static analysis; governance.

- ai_outputs/   B1 to B6: the AI outputs to review (37 planted mistakes)
- docs/         the sources of truth: VC-21 datasheet page, charge spec, REQ-207, boot log,
                a vendor app note (untrusted), the project's data handling rules
- data/         situations for Exercise 1
- src/          ve_hal.h and charge_curve.h, needed to compile the checks
- verify/       the checks: run_checks.py runs them all
- exercise_worksheet.md  record what you found, and how
- solutions/    answer key and a Word solution document: open them only after you have
                tried each exercise

Run the checks (Python 3.10 or later; gcc or clang for the C checks):

    python verify/run_checks.py          # everything
    python verify/run_checks.py B2       # one output

On Windows, run the C checks in WSL or MSYS2; without a compiler they are skipped and the
Python checks still run.

VoltEdge, the VC-21, the client, the customers and every key in this kit are fictional; the
keys are placeholders.
