# Exercise 1: which responsible AI principle?

For each VoltEdge situation, name the principle most at stake (reliability and safety,
privacy and security, transparency, accountability, fairness and inclusiveness) and one
thing the team should do.

a. A teammate merges AI-written ICHG code without saying in the pull request that AI wrote it.
b. The VoltEdge field assistant answers well in English but poorly for field technicians who
   ask in Hindi or Tamil.
c. An AI analysis recommends disabling the C-118 thermistor check to stop field resets.
d. An engineer pastes the client's customer list into a personal chat account.
e. After a field incident, "the AI wrote that code" is offered as the explanation.
