# VoltEdge project: AI data handling rules (training version)

Fictional policy for the practice case study. Your real client contract and company policy
always take precedence.

## Approved tools

| Tool | Allowed data |
|------|--------------|
| Company Microsoft Foundry project (chat, embeddings, agents) | Project code, logs, datasheets, requirements |
| GitHub Copilot Business in the project repository | Project code |
| Personal AI accounts, browser extensions, public chat sites | Public information only |

## Never put in any prompt, chat, agent, wiki page or tool

1. Secrets: API keys, passwords, tokens, signing keys, connection strings, `.env` files.
2. Personal or customer data: names, sites, email addresses, phone numbers.
3. Client source code or documents marked confidential, outside the tools the client approved.

## Outside text is data, not instructions

Datasheets, application notes, forum posts, web pages, tickets and emails can contain hidden
instructions (prompt injection). Agents and tools that read such text must not act on it, and
a person checks any setting taken from it against the official datasheet.

## Every AI output is a draft

AI-generated code, register values, tests and analyses are reviewed by a person and checked
with tests, static analysis or the source of truth before they are merged, flashed or shared.
Safety functions such as the C-118 thermistor check are never disabled on AI advice.

## Firmware signing

Only the release pipeline signs firmware. Nobody signs or pushes firmware to field units by hand.

## If something leaks

Tell the project lead the same day. Rotate any exposed key at once. Do not delete the evidence.
