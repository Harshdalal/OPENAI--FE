# REQ-207: Stop charging on a thermistor fault

Product: VoltEdge VE-200 charger firmware
Owner: Charger firmware team
Status: Ready for test

VoltEdge is a fictional product used for training. It is not a real product.

## Story

As a VoltEdge owner, I want the charger to stop charging when it cannot trust the battery
temperature, so that a faulty thermistor never lets the battery charge while it is too hot
or too cold.

## Acceptance criteria

- AC1. A battery temperature below -20.0 °C or above 100.0 °C is invalid. A raw ADC value of
  0x000 (thermistor short) or 0xFFF (thermistor open circuit) is also invalid.
- AC2. The charger enters fault stop after 4 invalid readings in a row, taken 250 ms apart.
  One, two or three invalid readings followed by a valid one do not cause a fault stop.
- AC3. Within 200 ms of entering fault stop, the charge current is 0 mA and the status LED
  is solid red.
- AC4. On entering fault stop the firmware logs exactly one line: "chg: fault code=C-118".
- AC5. The charger leaves fault stop after 20 valid readings in a row, then sets the charge
  current from charge_spec.md (Module 1 practice exercises).
- AC6. If the charger enters fault stop more than 3 times within 10 minutes, it stays in fault
  stop until the battery pack is removed and inserted again, and logs
  "chg: fault locked code=C-119".

## Out of scope

SMBus message formats, register names and addresses, Bluetooth updates and the mobile app.
