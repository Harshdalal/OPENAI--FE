/* ve_hal.h - VoltEdge hardware abstraction (training stub, fictional product). */
#ifndef VE_HAL_H
#define VE_HAL_H

#include <stdint.h>

/* 12-bit ADC read, 0 to 0xFFF. Takes about 20 us. */
uint16_t adc1_read(uint8_t channel);

/* Blocking SMBus word write. Returns 0 on success, negative on NAK or timeout.
 * Takes about 0.5 ms; up to 25 ms when the device stretches the clock or NAKs. */
int smb_write_word(uint8_t addr, uint8_t cmd, uint16_t value);

/* Thermistor resistance in ohms to battery temperature in tenths of a degree C. */
int16_t ntc_r_to_c10(uint32_t r_ohm);

/* Charge current in mA for a battery temperature (charge_spec.md rules C1 to C6). */
uint16_t charge_current_for_c10(int16_t t_c10);

/* Blocking UART log line. Takes about 3 ms for a 30-character line at 115200 baud. */
void uart_log(const char *line);

/* Status LED. */
typedef enum { LED_OFF, LED_GREEN, LED_RED } led_t;
void led_set(led_t colour);

#endif
