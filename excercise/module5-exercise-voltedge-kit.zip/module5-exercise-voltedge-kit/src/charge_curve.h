/* charge_curve.h - VoltEdge charge current from battery temperature (rules C1 to C7 in charge_spec.md). */
#ifndef CHARGE_CURVE_H
#define CHARGE_CURVE_H

#include <stdint.h>

#ifdef __cplusplus
extern "C" {
#endif

/* Battery temperature in tenths of a degree C (473 means 47.3 C). Returns current in mA. */
uint16_t charge_current_for_c10(int16_t t_c10);

/* One control step: read the battery temperature, set the charge current. */
void charge_control_step(void);

/* Hardware boundary (implemented by the board support package, faked in tests). */
int16_t ve_battery_read_c10(void);
void    ve_set_current_ma(uint16_t current_ma);

#ifdef __cplusplus
}
#endif

#endif
