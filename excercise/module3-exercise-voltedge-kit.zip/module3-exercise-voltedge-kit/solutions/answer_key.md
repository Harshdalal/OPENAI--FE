# Answer key: Module 3 practice exercises (VoltEdge)

Try each exercise first. Model answers vary; use this key to judge your results, not to match
wording. Line numbers refer to src/ve_charge_ctrl.c as shipped.

## Exercise 1: diagnose weak prompts

| # | Missing parts | Anti-pattern |
|---|---------------|--------------|
| 1 | Role, context, constraints, format; the task is vague ("better") | Vague task: no definition of done |
| 2 | Constraints, format; context is the datasheet it never gives | Several tasks in one prompt, one of them impossible (judge a PCB from code) |
| 3 | Role, context (no code, no requirement), constraints, format | Asking about code the model has not been given: an invitation to invent |
| 4 | Role, context (REQ-207 not pasted), constraints | Contradictory instructions ("thorough but short", "table or list, whatever") |
| 5 | Role, task scope, constraints, format | Context dump: far more than the question needs, which costs tokens and buries the relevant part |

A good rewrite of prompt 3:

    You are a senior embedded C reviewer for a battery charger team.
    Task: review how src/ve_charge_ctrl.c handles invalid thermistor readings.
    Context: the code and REQ-207 are below.
    Constraints: use only the code and REQ-207. Cite line numbers. Say "unsure" if unsure.
    Format: a table: line, concern, acceptance criterion affected, suggested fix.

## Exercise 2: system message or user message?

- **System message** (rules for every turn): you are a firmware test assistant for the VoltEdge
  charger team; always answer in a table with the columns ID, title, type, acceptance criterion,
  expected result; never invent register names or log lines; put anything missing under
  "Questions for the firmware lead"; one sentence per expected result.
- **User message** (this request): here is REQ-207; write the scenarios for AC2 and AC3 only;
  add one fault-injection scenario for a thermistor that flickers between open circuit and valid.

Rule of thumb: who the model is and how it always answers goes in the system message; what
you want now, and the material for it, goes in the user message.

## Exercises 3 to 6: the ten planted defects

| ID | Line(s) | Category | Defect | Needs |
|----|---------|----------|--------|-------|
| F1 | 44 | memory | sample_idx wraps at NSAMPLES + 1 = 9, so samples[8] is written: one past the end | Code |
| F2 | 60 | memory | sprintf writes "chg: fault code=C-118 t=1250", 28 characters plus the terminator, into msg[20] | Code |
| F3 | 32 | correctness | ICHG is 20 mA per LSB, but the code divides by 10: every current is doubled, 2000 mA becomes 4000 mA, above the 3000 mA maximum | Datasheet |
| F4 | 26 | correctness | CHG_CTRL written as 0x000D: EN = 1, TERM = 0 (termination disabled), TMR = 11 (safety timer disabled). Reset value is 0x0003 | Datasheet |
| F5 | 26, 33 | correctness | smb_write_word return values ignored; on a NAK the current is not changed and nobody knows (the boot log shows SMBus NAKs) | ve_hal.h helps |
| F6 | 61, 65 | timing | The 250 ms interrupt does a blocking SMBus write (0.5 ms, up to 25 ms) and a blocking uart_log (about 3 ms) | ve_hal.h |
| F7 | 18, 19, 57 to 59, 72 to 75 | concurrency | invalid_count and fault_stop are shared by the ISR and the main loop with no volatile and no critical section | Code |
| F8 | 40 | correctness | Divides by (4095 - raw) before the open-circuit check: raw 0xFFF is a division by zero | Code |
| F9 | 58 | correctness | invalid_count > 4 needs five invalid readings in a row; REQ-207 AC2 says four | REQ-207 |
| F10 | 69 to 75 | timing | The fault stop (0 mA, red LED) is applied only in the main loop, every 500 ms; REQ-207 AC3 needs it within 200 ms | REQ-207 |

Also accept, against REQ-207: C-118 is logged on every invalid reading after the fifth, not
exactly once (AC4, lines 58 to 61); a single valid reading resumes charging, not 20 (AC5,
lines 63 to 65); there is no lock after more than 3 fault stops (AC6).

Typical pattern:

| Version | Typical result |
|---------|----------------|
| P0 | A friendly summary; no defects, or one mention of sprintf |
| P1 | 5 or 6 from the code alone: F1, F2, F5, F6, F7, F8 |
| P2 | Adds F3 and F4 (datasheet) and F9, sometimes F10 (REQ-207) |
| P3 | Same defects, more consistent rows and fixes |
| P4 | Most complete; the checklist's "deadline" and "division" items pull in F10 and F8 reliably |

Watch for: invented defects, such as "wrong SMBus address" (0x6B is not checked anywhere in
the kit, so the model cannot know) or "missing PEC byte"; wrong fixes such as "divide by 5"
for F3 or "write 0xFFFF" for F4; line numbers that do not match.

## Exercise 7: JSON instead of a table

Every object should have line, category, concern, needs and fix, with category from the four
allowed values. The "needs" key makes the context lesson visible: F3 and F4 should say
datasheet, F9 and F10 requirement. If the model adds prose around the JSON, or a fifth
category, tighten the format line ("JSON only, no other text") or use structured outputs
(Module 2).

## Exercise 8: refine in the same chat

- Follow-up 1 usually removes one or two rows whose quoted line does not support them, and
  fixes line numbers. If it removes a real defect, push back with the line.
- Follow-up 2 should name AC2 (five readings, not four), AC3 (500 ms, not 200 ms), AC4 (C-118
  logged repeatedly), AC5 (one valid reading resumes) and AC6 (no lock), each with lines.

## Exercise 9: templates

- Boot log: templates/log_triage.md with {{board}} = VoltEdge charger and {{log}} = the boot log.
  The answer should match the Module 2 practice findings: brownout resets, VBUS low, four
  open-circuit readings then C-118, a second C-118 after lost log lines.
- REQ-207: templates/test_ideas.md with {{requirement}}. Good answers have a boundary for every
  number and questions for the firmware lead; nothing invented about SMBus or registers.
- Your own template: any repeated task, with the file-specific parts as {{placeholders}} and the
  five parts kept.

## Self-check quiz

1. b   2. c   3. a   4. d   5. b   6. c   7. a   8. d
