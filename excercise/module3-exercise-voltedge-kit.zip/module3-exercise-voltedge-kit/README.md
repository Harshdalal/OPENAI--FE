# Module 3 practice exercises: VoltEdge charger

A second case study for practice after the Module 3 lab. In class you reviewed the NovaBoard
sensor driver; here you practise the same prompt engineering skills on a legacy VoltEdge
charge controller you have not seen, on your own (about 70 to 80 minutes).

Only Module 3 content is used: system and user messages, the five parts of a prompt (role,
task, context, constraints, format), weak and strong prompts, context and constraints,
zero-shot and few-shot, step-by-step instructions, output formats, refining in a
conversation, templates and anti-patterns.

- src/ve_charge_ctrl.c          the legacy charge controller (deliberate defects; fictional)
- src/ve_hal.h                  the hardware abstraction it calls
- docs/VC21_registers.md        the charger IC datasheet page, as text
- docs/REQ-207_charge_fault.md  the thermistor fault requirement (Module 2 practice)
- docs/charge_spec.md           the charging rules (Module 1 practice)
- data/weak_prompts.md          five weak prompts for Exercise 1
- data/mixed_prompt.md          a prompt to split for Exercise 2
- data/boot_log_VE-30187.txt    a boot log for the template exercise
- prompts.md                    prompt versions P0 to P4 and the follow-ups, in order
- exercise_worksheet.md         record your answers here
- templates/                    reusable prompt templates with {{placeholders}}
- scripts/review_prompts.py     optional: runs P0 to P4 and scores each answer
- solutions/                    answer key and a Word solution document: open them only
                                after you have tried each exercise

Main exercises: the chat playground in Microsoft Foundry (or Copilot Chat in Ask mode).

Optional script (Python 3.10 or later), same .env as Module 2:

    cd scripts
    python -m pip install -r requirements.txt
    python review_prompts.py --mock
    python review_prompts.py

Never commit .env. VoltEdge, the VC-21 and every code in this kit are fictional.
