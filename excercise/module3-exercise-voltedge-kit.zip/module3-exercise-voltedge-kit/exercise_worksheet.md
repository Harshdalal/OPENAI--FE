# Module 3 exercise worksheet: VoltEdge

Name: ____________________   Model or tool used: ____________________

Try every exercise before you open the solutions.

## Exercise 1: diagnose weak prompts

| # | Missing parts (role, task, context, constraints, format) | Anti-pattern |
|---|-----------------------------------------------------------|--------------|
| 1 | | |
| 2 | | |
| 3 | | |
| 4 | | |
| 5 | | |

Your rewrite of prompt 3:

______________________________________________________________________________

## Exercise 2: system message or user message?

System message: ______________________________________________________________

User message: ________________________________________________________________

## Exercises 3 to 6: what each prompt version found

Count the concerns that are real (check the line in the code). Count separately anything
that is not a real defect, or cites a line that does not match.

| Version | What I changed | Real concerns found | Not real or wrong line | Lines cited? (Y/N) | Format usable as-is? (Y/N) |
|---------|----------------|---------------------|------------------------|--------------------|----------------------------|
| P0 | Vague prompt | | | | |
| P1 | Role, task, constraints, format | | | | |
| P2 | + datasheet and REQ-207 | | | | |
| P3 | + one example row | | | | |
| P4 | + step-by-step checklist | | | | |

Concerns that appeared only after you added the datasheet and REQ-207:

______________________________________________________________________________

## Exercise 7: JSON instead of a table

Did every object have all five keys? ____   Did any value use a category outside the list? ____

## Exercise 8: refine in the same chat

| Follow-up | What changed in the answer |
|-----------|----------------------------|
| 1. Quote the line | |
| 2. Which ACs does it break? | |

## Exercise 9: templates

Template used for the boot log: ______________   Placeholders you filled: ______________

Template used for REQ-207: ______________   Did it invent anything? ______________

Your own template's name and placeholders: ________________________________________

## Self-check quiz

| Question | 1 | 2 | 3 | 4 | 5 | 6 | 7 | 8 |
|----------|---|---|---|---|---|---|---|---|
| Your answer | | | | | | | | |
