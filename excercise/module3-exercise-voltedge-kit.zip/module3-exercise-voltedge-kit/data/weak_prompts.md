# Exercise 1: five weak prompts from the VoltEdge team

For each prompt: which of the five parts (role, task, context, constraints, format) is
missing, and which anti-pattern does it show? Then rewrite prompt 3 in full.

1. Make the charger code better.

2. You are an expert. Review this driver and also write unit tests and also update the
   README and also check the datasheet and tell me if the PCB is OK.

3. What's wrong with the thermistor handling?

4. Write test cases for REQ-207. Be thorough but keep it short. Use a table, or a list,
   whatever is best.

5. Here is our full 4,000-line charger firmware, the full VC-21 datasheet (60 pages), all
   12 bug reports and last week's meeting notes. Is the C-118 code correct?
