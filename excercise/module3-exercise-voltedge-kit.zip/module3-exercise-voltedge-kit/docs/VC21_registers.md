# VoltChip VC-21 charger controller: register map (datasheet rev B, page 4)

Text copy of data/VC21_datasheet_p4.pdf from the Module 2 practice exercises.
VoltChip and the VC-21 are fictional; not a real product.

## 4.1 Register map

| Address | Register  | Access | Reset value | Description |
|---------|-----------|--------|-------------|-------------|
| 0x00    | STATUS    | R      | 0x0000      | Charge state, fault flags, thermistor state |
| 0x01    | CHG_CTRL  | R/W    | 0x0003      | Charge enable, termination enable, safety timer |
| 0x02    | ICHG      | R/W    | 0x0064      | Charge current, 20 mA per LSB, default 2000 mA |
| 0x03    | NTC_CFG   | R/W    | 0x0A3C      | Thermistor cold and hot limits |
| 0x0F    | DEVICE_ID | R      | 0x0021      | Device identifier |

## 4.2 CHG_CTRL register (0x01) fields

| Bits | Field | Reset | Description |
|------|-------|-------|-------------|
| 15:4 | -     | 0     | Reserved, write 0 |
| 3:2  | TMR   | 00    | Safety timer: 00 = 5 h, 01 = 8 h, 10 = 12 h, 11 = disabled |
| 1    | TERM  | 1     | Charge termination: 1 = enabled |
| 0    | EN    | 1     | Charge enable: 1 = charging allowed |

## 4.3 Electrical characteristics (extract)

| Parameter | Min | Typ | Max | Unit |
|-----------|-----|-----|-----|------|
| Thermistor input valid range | -20 | | 100 | °C |
| Charge current setting | 100 | | 3000 | mA |
| VBUS input voltage | 4.75 | 5.0 | 6.5 | V |
| SMBus clock frequency | | | 100 | kHz |
