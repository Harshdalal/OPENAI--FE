# Module 3 exercise prompts: VoltEdge (copy and paste)

Use the chat playground (or Copilot Chat in Ask mode). Start a new chat before every prompt
version. Temperature 0 or the lowest setting you have.

The code under review is src/ve_charge_ctrl.c. Paste the whole file where a prompt says
<code>. Paste src/ve_hal.h below it from P1 on.

## P0: the vague prompt (baseline)

    Explain this code.

    <code>

## P1: role, task, constraints, format (no extra context)

    You are a senior embedded C reviewer for a battery charger team.
    Task: explain what TIM3_IRQHandler() does in three sentences, then list every timing,
    memory-safety and concurrency concern in the whole file.
    Constraints: use only the code below. Cite the line number for every concern. If you
    are not sure something is a defect, say "unsure" and why.
    Format: a table with the columns: line, category (timing, memory, concurrency,
    correctness), concern, why it matters, suggested fix. Most severe first.

    <code>
    <ve_hal.h>

## P2: P1 plus context (the datasheet and the requirement)

Paste these two below the code, each under its own heading:

    === docs/VC21_registers.md ===
    <paste>
    === docs/REQ-207_charge_fault.md ===
    <paste>

and add one line to the constraints:

    Check register values and units against the datasheet, and fault handling against
    REQ-207.

## P3: P2 plus one example (few-shot)

Add this example under the format line, so the model copies its level of detail. It is an
illustration from another file, not a defect in this one:

    Example row:
    | 12 | timing | Delay loop counts to 8000 for "about 0.5 ms" | The delay depends on the
    clock and the compiler | Use a hardware timer |

## P4: P3 plus a step-by-step checklist

Add this before the format line:

    Work through the file in this order before you write the table:
    1. Everything that runs inside the interrupt handler, and how long it can take.
    2. Every variable shared between the interrupt handler and the main loop.
    3. Every array index, buffer size and string function.
    4. Every division and what the divisor can be.
    5. Every return value that is ignored.
    6. Every register value and unit, against the datasheet.
    7. Every count, limit and deadline, against REQ-207.

## Exercise 7: ask for JSON instead of a table

Replace the format line of your best prompt with:

    Format: JSON only, an array of objects with the keys: line (number), category
    (timing, memory, concurrency or correctness), concern, needs (code, datasheet or
    requirement), fix.

## Exercise 8: refine in the same chat (after P4)

Follow-up 1:

    For every row, quote the exact line of code it refers to. Remove any row whose quote
    does not support the concern.

Follow-up 2:

    Which acceptance criteria of REQ-207 does this file break? One line each, with the
    code line numbers.
