"""Module 3 practice (optional): send prompt versions P0 to P4 and score each answer.

The script builds the five prompt versions from prompts.md around src/ve_charge_ctrl.c,
sends each one to your deployment, saves every answer, and gives each answer a rough score:
how many of the ten planted defects (solutions/answer_key.md) it mentions.

    python review_prompts.py --mock                 practice run, no Azure needed
    python review_prompts.py                        real run, reads .env (same as Module 2)
    python review_prompts.py --versions P0 P4       only some versions
    python review_prompts.py --runs 2               run each version twice

The score is a keyword match, not a judgement. Read the answers: a mention is not a correct
explanation, and the model may also report things that are not defects.
"""
import argparse
import os
import re
import sys
from datetime import datetime
from pathlib import Path

HERE = Path(__file__).resolve().parent
KIT = HERE.parent
MOCK = "--mock" in sys.argv


def load_env():
    path = HERE / ".env"
    if path.exists():
        for line in path.read_text(encoding="utf-8").splitlines():
            line = line.strip()
            if line and not line.startswith("#") and "=" in line:
                key, value = line.split("=", 1)
                os.environ.setdefault(key.strip(), value.strip().strip('"').strip("'"))


def read(rel):
    return (KIT / rel).read_text(encoding="utf-8")


def numbered(code):
    return "\n".join(f"{i:>3}  {line}" for i, line in enumerate(code.splitlines(), 1))


# ---------------------------------------------------------------- prompt versions
ROLE = "You are a senior embedded C reviewer for a battery charger team."
TASK = ("Task: explain what TIM3_IRQHandler() does in three sentences, then list every timing, "
        "memory-safety and concurrency concern in the whole file.")
CONSTRAINTS = ("Constraints: use only the material below. Cite the line number for every concern. "
               "If you are not sure something is a defect, say \"unsure\" and why.")
CONTEXT_RULE = "Check register values and units against the datasheet, and fault handling against REQ-207."
FORMAT = ("Format: a table with the columns: line, category (timing, memory, concurrency, correctness), "
          "concern, why it matters, suggested fix. Most severe first.")
EXAMPLE = ("Example row (an illustration from another file, not a defect in this one):\n| 12 | timing | Delay loop counts to "
           "8000 for \"about 0.5 ms\" | The delay depends on the clock and the compiler | Use a hardware timer |")
CHECKLIST = ("Work through the file in this order before you write the table:\n"
             "1. Everything that runs inside the interrupt handler, and how long it can take.\n"
             "2. Every variable shared between the interrupt handler and the main loop.\n"
             "3. Every array index, buffer size and string function.\n"
             "4. Every division and what the divisor can be.\n"
             "5. Every return value that is ignored.\n"
             "6. Every register value and unit, against the datasheet.\n"
             "7. Every count, limit and deadline, against REQ-207.")


def build(version):
    code = numbered(read("src/ve_charge_ctrl.c"))
    hal = read("src/ve_hal.h")
    block_code = f"=== src/ve_charge_ctrl.c (line numbers added) ===\n{code}"
    if version != "P0":
        block_code += f"\n\n=== src/ve_hal.h ===\n{hal}"
    context = (f"\n\n=== docs/VC21_registers.md ===\n{read('docs/VC21_registers.md')}"
               f"\n\n=== docs/REQ-207_charge_fault.md ===\n{read('docs/REQ-207_charge_fault.md')}")
    if version == "P0":
        return "Explain this code.\n\n" + block_code
    parts = [ROLE, TASK]
    if version == "P4":
        parts.append(CHECKLIST)
    cons = CONSTRAINTS + (" " + CONTEXT_RULE if version in ("P2", "P3", "P4") else "")
    parts += [cons, FORMAT]
    if version in ("P3", "P4"):
        parts.append(EXAMPLE)
    text = "\n\n".join(parts) + "\n\n" + block_code
    if version in ("P2", "P3", "P4"):
        text += context
    return text


# ---------------------------------------------------------------- scoring (rough)
DEFECTS = {
    "F1 sample index wraps at 9, writes samples[8] (line 44)": [r"nsamples\s*\+\s*1", r"samples\[8\]", r"out of bounds", r"past the end", r"off.by.one"],
    "F2 sprintf overflows msg[20] (line 60)": [r"sprintf", r"msg\[20\]", r"snprintf"],
    "F3 ICHG is 20 mA per LSB, code divides by 10 (line 32)": [r"20 ?ma", r"/ ?20", r"doubl\w*.{0,60}current", r"4000"],
    "F4 CHG_CTRL 0x000D disables termination and the safety timer (line 26)": [r"0x000d", r"termination", r"safety timer", r"\btmr\b"],
    "F5 smb_write_word return value ignored (lines 26, 33)": [r"return value", r"ignor\w*.{0,40}(smb|write|nak|error)", r"\bnak\b"],
    "F6 blocking SMBus and UART inside the ISR (lines 61, 65)": [r"(isr|interrupt).{0,160}(smb|uart|block|25 ?ms)", r"(smb_write_word|uart_log).{0,160}(isr|interrupt|block)"],
    "F7 shared state without volatile or critical section": [r"volatile", r"\brace\b", r"critical section", r"atomic"],
    "F8 division by zero when raw is 0xFFF (line 40)": [r"divi\w* by zero", r"4095u? ?- ?raw", r"zero divisor"],
    "F9 fault after 5 invalid readings, REQ-207 says 4 (line 58)": [r"> ?4", r"five", r"5 invalid", r"fifth"],
    "F10 fault stop applied in the 500 ms main loop, REQ-207 says 200 ms (lines 69 to 75)": [r"200 ?ms", r"500 ?ms.{0,80}(late|deadline|ac3)", r"\bac3\b"],
}


def score(text):
    t = text.lower()
    return [name for name, pats in DEFECTS.items() if any(re.search(p, t, flags=re.S) for p in pats)]


# ---------------------------------------------------------------- model
MOCK_ROWS = {
    "F1": "| 44 | memory | sample_idx wraps at NSAMPLES + 1, so samples[8] is written: one past the end | Corrupts sample_idx or the next variable | Wrap with % NSAMPLES |",
    "F2": "| 60 | memory | sprintf writes up to 28 characters plus the terminator into msg[20] | Buffer overflow | snprintf with sizeof(msg), larger buffer |",
    "F3": "| 32 | correctness | ICHG is 20 mA per LSB, but the code divides by 10 | Every current is doubled: 2000 mA becomes 4000 mA, above the 3000 mA maximum | Divide by 20 |",
    "F4": "| 26 | correctness | CHG_CTRL written as 0x000D: TERM = 0 disables termination, TMR = 11 disables the safety timer | Charging never terminates | Write 0x0003 or the value the team needs |",
    "F5": "| 26, 33 | correctness | smb_write_word return value ignored | On a NAK the current is not changed and nobody knows | Check the result, retry, report |",
    "F6": "| 61, 65 | timing | The 250 ms interrupt does a blocking SMBus write (up to 25 ms) and uart_log (about 3 ms) | Long interrupt latency | Set a flag; do the bus and UART work in the main loop |",
    "F7": "| 18, 19, 72 to 75 | concurrency | invalid_count and fault_stop are shared with the ISR without volatile or a critical section | Lost updates; the compiler may cache the flag | volatile plus a critical section |",
    "F8": "| 40 | correctness | Divides by (4095 - raw) before the open-circuit check: raw 0xFFF is a division by zero | HardFault or garbage | Check raw before converting |",
    "F9": "| 58 | correctness | invalid_count > 4 needs five invalid readings in a row | REQ-207 AC2 says four | Use >= 4 |",
    "F10": "| 69 to 75 | timing | The fault stop is applied in the main loop, every 500 ms | REQ-207 AC3 needs 0 mA and red within 200 ms | Apply the stop at once |",
}
MOCK_SETS = {"P0": ["F2"], "P1": ["F1", "F2", "F5", "F6", "F7", "F8"], "P2": ["F1", "F2", "F3", "F4", "F5", "F6", "F7", "F8", "F9"],
             "P3": ["F1", "F2", "F3", "F4", "F5", "F6", "F7", "F8", "F9"], "P4": ["F1", "F2", "F3", "F4", "F5", "F6", "F7", "F8", "F9", "F10"]}


def mock_answer(version):
    if version == "P0":
        return ("This code reads a battery thermistor every 250 ms, converts it to a temperature, sets the charge "
                "current through the charger IC and logs a message with sprintf when the reading is invalid. "
                "It looks reasonable; you may want to add comments.")
    rows = "\n".join(MOCK_ROWS[d] for d in MOCK_SETS[version])
    return ("[MOCK] TIM3_IRQHandler() reads the battery temperature every 250 ms, counts invalid readings and requests "
            "a fault stop after too many; on a valid reading it sets the charge current from the temperature.\n\n"
            "| line | category | concern | why it matters | suggested fix |\n|---|---|---|---|---|\n" + rows)


def make_client():
    load_env()
    try:
        from openai import OpenAI
    except ImportError:
        sys.exit("The openai package is missing. Run: python -m pip install -r requirements.txt")
    base = os.getenv("OPENAI_BASE_URL")
    if not base:
        sys.exit("Missing OPENAI_BASE_URL in scripts/.env (copy .env.example), or add --mock.")
    if os.getenv("AUTH", "key").lower() == "entra":
        from azure.identity import DefaultAzureCredential, get_bearer_token_provider
        return OpenAI(base_url=base, api_key=get_bearer_token_provider(DefaultAzureCredential(), "https://ai.azure.com/.default"))
    key = os.getenv("OPENAI_API_KEY")
    if not key:
        sys.exit("Missing OPENAI_API_KEY in scripts/.env, or set AUTH=entra, or add --mock.")
    return OpenAI(base_url=base, api_key=key)


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--versions", nargs="+", default=["P0", "P1", "P2", "P3", "P4"], choices=["P0", "P1", "P2", "P3", "P4"])
    ap.add_argument("--runs", type=int, default=1)
    ap.add_argument("--mock", action="store_true")
    args = ap.parse_args()

    client = None if MOCK else make_client()
    model = os.getenv("MODEL_DEPLOYMENT", "") if not MOCK else "mock"
    if not MOCK and not model:
        sys.exit("Missing MODEL_DEPLOYMENT in scripts/.env.")
    if MOCK:
        print("MOCK MODE: answers are invented by the script, not by a model.\n")

    out = KIT / "output"
    out.mkdir(exist_ok=True)
    stamp = f"{datetime.now():%Y%m%d_%H%M%S}"
    report = out / f"review_{stamp}.md"
    lines = [f"# Prompt versions compared ({model})\n"]
    print(f"{'version':<9}{'run':<5}{'found':<8}{'tokens in':<11}defects mentioned")
    for v in args.versions:
        prompt = build(v)
        for run in range(1, args.runs + 1):
            if MOCK:
                text, tin = mock_answer(v), len(prompt) // 4
            else:
                r = client.responses.create(model=model, input=prompt, temperature=0, max_output_tokens=1800)
                text, tin = (r.output_text or "").strip(), r.usage.input_tokens
            found = score(text)
            ids = " ".join(f.split()[0] for f in found)
            print(f"{v:<9}{run:<5}{len(found):>2}/10   {tin:<11}{ids}")
            lines += [f"## {v}, run {run}: {len(found)} of 10 mentioned\n", f"Mentioned: {ids or 'none'}\n", text, "\n"]
    report.write_text("\n".join(lines), encoding="utf-8")
    print(f"\nAnswers saved to {report}")
    print("Rough keyword score. Read the answers: check each claim against the code and the datasheet.")


if __name__ == "__main__":
    main()
