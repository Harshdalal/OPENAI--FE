/*
 * ve_charge_ctrl.c - VoltEdge charge controller (legacy, v0.8)
 * Thermistor on ADC1 channel 4; charger IC VoltChip VC-21 on SMBus, address 0x6B.
 *
 * Training file for the Module 3 practice exercises: it contains deliberate defects.
 * VoltEdge and the VC-21 are fictional. Do not use this code in a product.
 */
#include <stdint.h>
#include <stdio.h>
#include "ve_hal.h"

#define VC21_ADDR        0x6Bu
#define VC21_CHG_CTRL    0x01u
#define VC21_ICHG        0x02u
#define NSAMPLES         8u

static int16_t  samples[NSAMPLES];
static uint8_t  sample_idx;
static uint8_t  invalid_count;
static uint8_t  fault_stop;
static char     msg[20];

/* Called once at boot. */
void ve_charge_init(void)
{
    smb_write_word(VC21_ADDR, VC21_CHG_CTRL, 0x000Du);
}

/* Set the charge current in mA. */
static void ve_set_current_ma(uint16_t current_ma)
{
    uint16_t code = current_ma / 10u;
    smb_write_word(VC21_ADDR, VC21_ICHG, code);
}

/* Read the thermistor and return the battery temperature in tenths of a degree C. */
int16_t ve_battery_temp_c10(uint8_t *valid)
{
    uint16_t raw = adc1_read(4u);
    uint32_t r_ohm = (uint32_t)raw * 10000u / (4095u - raw);
    int16_t t_c10 = ntc_r_to_c10(r_ohm);

    samples[sample_idx] = t_c10;
    sample_idx = (sample_idx + 1u) % (NSAMPLES + 1u);

    *valid = (raw != 0xFFFu) && (t_c10 >= -200) && (t_c10 <= 1000);
    return t_c10;
}

/* ADC timer interrupt, every 250 ms. */
void TIM3_IRQHandler(void)
{
    uint8_t valid;
    int16_t t_c10 = ve_battery_temp_c10(&valid);

    if (!valid) {
        invalid_count++;
        if (invalid_count > 4u) {
            fault_stop = 1u;
            sprintf(msg, "chg: fault code=C-118 t=%d", t_c10);
            uart_log(msg);
        }
    } else {
        invalid_count = 0;
        ve_set_current_ma(charge_current_for_c10(t_c10));
    }
}

/* Main loop, called every 500 ms: apply the fault stop. */
void ve_charge_poll(void)
{
    if (fault_stop) {
        ve_set_current_ma(0u);
        led_set(LED_RED);
        fault_stop = 0u;
    }
}
