# Answer key: Module 1 practice exercises (VoltEdge)

Try each exercise first. Model answers vary from run to run; use this key to judge your
results, not to match wording.

## Exercise 1: name the workload

| # | Task | Workload | Generative or agentic? |
|---|------|----------|------------------------|
| 1 | Group 400 reviews by theme | Text analysis (keyword and topic extraction) | Generative |
| 2 | Draft unit tests from the spec | Generative AI (code) | Generative |
| 3 | Read the LED colour sequence from a camera | Computer vision | Generative (it answers; a person or script acts) |
| 4 | Register table from a datasheet into JSON | Information extraction | Generative |
| 5 | Voice memo into written test steps | Speech (speech to text), then generative AI to write the steps | Generative |
| 6 | Read the log, rebuild the target, draft a bug | Agentic AI | **Agentic**: it plans, uses tools (log reader, build) and checks results |
| 7 | Serial numbers and error codes in 300 emails | Text analysis (entity detection); information extraction is also right | Generative |
| 8 | Varied photos of pack labels for OCR tests | Generative AI (image generation). Label them as synthetic | Generative |
| 9 | Spoken commands for a voice kiosk | Speech (speech synthesis, text to speech) | Generative |
| 10 | 60 pages to five lines | Text analysis (summarization) | Generative |

Only task 6 is agentic. The others give an answer that a person, or a script, then acts on.

## Exercise 2: choose the model and the deployment

| Task | Model capability | Deployment type or setting | Why |
|------|------------------|----------------------------|-----|
| a | Reasoning model, higher reasoning effort | Global Standard is fine to start | Multi-step thinking over a register dump; quality matters more than speed |
| b | Small, fast model (a mini model) | Global Batch | High volume at low cost; results next morning fit the 24-hour batch target at about half the price |
| c | Multimodal model (accepts images) | Any standard type | The input is an image |
| d | Model with structured outputs | Temperature 0; fixed JSON schema | Code reads the answer, so the format must be exact and repeatable |
| e | Any model that meets the task | Data Zone Standard (EU), or Standard in one EU region | Data rules decide first: processing must stay in the EU |
| f | A model sized for the task | Provisioned throughput (PTUs) | Reserved capacity gives predictable latency at steady high load |

"Data rules decide first, then volume" (Module 1, deployment options).

## Exercise 3: tokens and the context window

Counts with the o200k_base tokenizer (the OpenAI tokenizer page or `count_tokens.py` with
tiktoken). Your numbers may differ slightly by tokenizer and by line endings.

| Text | Characters | Tokens | Characters per token |
|------|------------|--------|----------------------|
| charge_spec.md | 1,751 | about 515 | about 3.4 |
| data/charger_log.txt | 338 | about 183 | about 1.8 |

- System message (role line plus spec): about 531 tokens. On 40 calls: about **21,000 input
  tokens**, before any question is asked. The whole spec is sent, and fills part of the context
  window, on every call.
- One plain sentence of 56 characters is 11 tokens; one log line fragment of 47 characters is
  27 tokens.
- Why: timestamps, hex values such as `0x0B` and `0x0FFF`, IDs such as `VE-30112` and symbols
  split into many small tokens. Ordinary English words are often one token each.

## Exercise 4: same question, different settings

- Temperature 0: **1890** in every run, or nearly every run. "1890 mA" is also correct.
- Wrong answers to watch for: **1885** (the formula without rule C6), **1880** (rounded down,
  or "round half to even"). Both ignore half-up rounding.
- At 1.0, Prompt A usually stays right; Prompt B lists change between runs. At 1.5, Prompt A may
  add explanations or get the rounding wrong, and Prompt B becomes varied, some ideas useful,
  some off-topic or repeated.

Lesson: temperature 0 gives focused, mostly repeatable answers. It is not a correctness
setting. Compare with example 3, and in tests compute expected values in code.

## Exercise 5: max output tokens

At 400, Prompt B returns five full ideas. At 20, the answer stops after one or two ideas, often
mid-sentence. Some playgrounds show the finish reason as "length". With a reasoning model,
a very low limit can return nothing at all, because its thinking uses the budget first.

Lesson: max output tokens caps length and cost; too low cuts the answer short.

## Exercise 6: the trap and grounding

- C1 and C2: many models answer with something plausible, such as a fault bit in SMBus
  `BatteryStatus` or a `ChargingCurrent (0x14)` register. Note: these names exist in a public
  smart-battery standard, so the answer sounds even more convincing. But charge_spec.md
  defines no fault code, no SMBus message and no register. VoltEdge may not follow that
  standard at all. Borrowing facts from training data is still a hallucination for this product.
- D1 and D2: **Not in the spec** at both temperatures.
- Prompt A with grounding: still **1890**.
- If a model still invents with grounding: record it. Grounding reduces invention; it does not
  remove it.

## Exercise 7: extract from an image

```json
{
  "model": "VE-200-2S",
  "serial": "VE-30112",
  "nominal_voltage_v": 7.2,
  "capacity_mah": 3400,
  "energy_wh": 24.5,
  "charge_temp_min_c": 0,
  "charge_temp_max_c": 60,
  "mfg_date": "2026-08-14",
  "firmware": "v1.7.1",
  "max_charge_current_ma": null
}
```

- `max_charge_current_ma` is **not on the label**: the right answer is null. A model that fills
  in 2000 has used the spec from an earlier system message or its own guess. That is why you
  cleared the Instructions box first.
- The label is rotated slightly: check that the serial is not read as `VE-3O112` (letter O)
  and the date is not reordered.
- Sanity check in code, not by the model: 7.2 V x 3.4 Ah = 24.48 Wh, so 24.5 Wh is consistent.

## Exercise 8: text analysis

- Keywords: charging, charge current, firmware update, error, temperature (similar sets are fine).
- Entities: firmware **v1.7.0, v1.7.1**; serial numbers **VE-30112, VE-30187, VE-30245,
  VE-29960, VE-30301**; error codes **C-301, C-118**; dates **5 Nov, 2 Nov**; temperatures
  **5 °C, 25 °C, 47.3 °C, -22 °C, 61 °C**; currents **2000 mA, 1800 mA, 1880 mA, 1890 mA**.
- Sentiment: positive 1 and 9; neutral 7; negative 2, 3, 6, 10 and 12; mixed 4, 5, 8 and 11
  (1 and 8 can reasonably be argued either way).
- Summary: error C-301 and charging stops after v1.7.1; current below spec at 25 °C; current
  hunting at 47.3 °C; charging does not restart after a hot stop.
- Report 6 sits on the Prompt A boundary: 47.3 °C, where 1885 mA rounds to 1890 mA. A tiny
  change in the reading flips the current between 1880 and 1890.
- Gaps in the specification: report 12 (C5 stops charging at 60 °C but says nothing about when
  to restart), report 8 (-22 °C is a sensor fault under C7, but the spec does not define how it is
  reported, so do not assume C-118 means a sensor fault).
- Watch for invented entities, such as a serial number or version that is not in the file.

## Exercise 9: decide

| VoltEdge task | Temperature | Why |
|---------------|-------------|-----|
| Expected value for an automated assertion | 0, and better, compute it from the spec in code | One right answer; it must not change between runs |
| Brainstorm fault-injection ideas for the temperature sensor | About 0.9 to 1.2 | Variety helps; a person filters the list |
| Extract label fields of 500 photos into JSON | 0, with a fixed JSON format | Code reads it; check a sample against the labels |
| Draft customer release notes for v1.7.2 | About 0.3 to 0.7 | Readable, but close to the facts |
| Classify 20,000 log lines | 0 | Consistent labels across the whole set |

The sentence: lower temperature made answers more consistent; it did not make them correct,
and it did not stop the model inventing an SMBus code or register.

## Self-check quiz

1. **b.** About 4 characters of English text per token.
2. **c.** Timestamps, hex values and IDs split into many small tokens.
3. **b.** Temperature 0 makes answers focused and mostly repeatable; it does not make them correct.
4. **d.** The spec does not define it: ask where it comes from, ground the prompt, and allow "Not in the spec".
5. **c.** Computer vision.
6. **a.** Reading the log, rebuilding the target and drafting a bug: it plans and uses tools.
7. **b.** The answer is cut short.
8. **c.** Data Zone Standard (EU) or a regional deployment in the EU.
