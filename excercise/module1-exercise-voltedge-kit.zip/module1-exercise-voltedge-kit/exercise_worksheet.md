# Module 1 exercise worksheet: VoltEdge

Name: ____________________   Deployment (model) used: ____________________

Try every exercise before you open solutions/answer_key.md.

## Exercise 1: name the workload

| # | Workload | Generative or agentic? |
|---|----------|------------------------|
| 1 | | |
| 2 | | |
| 3 | | |
| 4 | | |
| 5 | | |
| 6 | | |
| 7 | | |
| 8 | | |
| 9 | | |
| 10 | | |

## Exercise 2: choose the model and the deployment

| Task | Model capability | Deployment type or setting | Why |
|------|------------------|----------------------------|-----|
| a. Root cause of a charger HardFault from a register dump | | | |
| b. Classify 20,000 charger log lines every night; results needed next morning | | | |
| c. Read the charge-profile graph in a datasheet image | | | |
| d. Return the charger IC register map as JSON for a script | | | |
| e. The client contract says data may be processed only in the EU | | | |
| f. A live assistant for 200 engineers on the production line, predictable response time all shift | | | |

## Exercise 3: tokens and the context window

| Text | Characters | Tokens | Characters per token |
|------|------------|--------|----------------------|
| charge_spec.md | | | |
| data/charger_log.txt | | | |

Input tokens for the system message if it is sent on 40 calls: ____________

Why does the log use more tokens per character? ____________________________________

## Exercise 4: same question, different settings

Prompt A has one right answer: 1890 (example 3 in charge_spec.md).

| Temperature | Run | Prompt A answer | Correct? (Y/N) | Prompt B: how different from the previous run? (same / some / very) |
|-------------|-----|-----------------|----------------|---------------------------------------------------------------------|
| 0           | 1   |                 |                |                                                                     |
| 0           | 2   |                 |                |                                                                     |
| 0           | 3   |                 |                |                                                                     |
| 1.0         | 1   |                 |                |                                                                     |
| 1.0         | 2   |                 |                |                                                                     |
| 1.0         | 3   |                 |                |                                                                     |
| 1.5         | 1   |                 |                |                                                                     |
| 1.5         | 2   |                 |                |                                                                     |
| 1.5         | 3   |                 |                |                                                                     |

## Exercise 5: max output tokens

| Max output tokens | What happened to Prompt B? |
|-------------------|----------------------------|
| 400 | |
| 20  | |

## Exercise 6: the trap and grounding

| Run | System message | Temperature | Did it invent a fault code or register? (Y/N) | What it said, in a few words |
|-----|----------------|-------------|-----------------------------------------------|------------------------------|
| C1  | 1              | 0           |                                               |                              |
| C2  | 1              | 1.0         |                                               |                              |
| D1  | 2 (grounded)   | 0           |                                               |                              |
| D2  | 2 (grounded)   | 1.0         |                                               |                              |
| A   | 2 (grounded)   | 0           | Prompt A answer:                              |                              |

## Exercise 7: extract from an image

| Field | Model's value | On the label? Correct? |
|-------|---------------|------------------------|
| model | | |
| serial | | |
| nominal_voltage_v | | |
| capacity_mah | | |
| energy_wh | | |
| charge_temp_min_c / max_c | | |
| mfg_date | | |
| firmware | | |
| max_charge_current_ma | | |

## Exercise 8: text analysis

Two entities you checked against the file: ____________________   Invented or missed? ______

The report that matches the Prompt A boundary: ______   A gap in the specification you found: ____________

## Exercise 9: decide

| VoltEdge task | Temperature | Why |
|---------------|-------------|-----|
| Expected value for an automated assertion | | |
| Brainstorm fault-injection ideas for the battery temperature sensor | | |
| Extract the label fields of 500 pack photos into JSON | | |
| Draft customer release notes for firmware v1.7.2 | | |
| Classify 20,000 log lines as info, warning or fault | | |

One sentence: what did lower temperature change, and what did it not change?

______________________________________________________________________________

## Self-check quiz

| Question | Your answer |
|----------|-------------|
| 1 | |
| 2 | |
| 3 | |
| 4 | |
| 5 | |
| 6 | |
| 7 | |
| 8 | |
