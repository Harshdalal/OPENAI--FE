# Exercise 1: VoltEdge tasks to classify

For each task, name the AI workload (generative AI, agentic AI, text analysis, speech,
computer vision, information extraction) and say whether the AI only answers (generative)
or also acts with tools (agentic).

| # | VoltEdge task |
|---|---------------|
| 1 | Group 400 customer reviews of the charger by theme |
| 2 | Draft unit tests for charge_current_for_temp() from charge_spec.md |
| 3 | Read the charger LED colour sequence from a test-rig camera |
| 4 | Pull the register table of the charger IC from its datasheet into JSON |
| 5 | Turn a recorded bench-test voice memo into written test steps |
| 6 | When the nightly build fails: read the log, rebuild the failing target, draft a bug for approval |
| 7 | Find every serial number and error code in 300 return emails |
| 8 | Create varied photos of pack labels to test an OCR feature |
| 9 | Create spoken commands to test a voice-controlled charging kiosk |
| 10 | Shorten a 60-page safety validation report to five lines for the release meeting |
