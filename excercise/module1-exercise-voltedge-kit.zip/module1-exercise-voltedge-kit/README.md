# Module 1 practice exercises: VoltEdge charger

A second case study for practice after the course. In class you worked on NovaBoard; here you
practise the same Module 1 skills on a new fictional product, the VoltEdge VE-200 battery
charger, on your own and at your own pace (about 60 to 75 minutes).

Only Module 1 content is used: AI workloads, generative and agentic AI, choosing a model and
a deployment type, tokens and the context window, temperature and other settings,
hallucination and inconsistent answers, grounding, information extraction and text analysis.

- CASE_STUDY.md              the VoltEdge product and how it relates to NovaBoard
- charge_spec.md             the charging rules and agreed answers (source of truth)
- prompts.md                 system messages and prompts A to F
- exercise_worksheet.md      record every answer here
- data/workload_tasks.md     ten tasks for Exercise 1
- data/charger_log.txt       five charger log lines for Exercise 3
- data/pack_label.png        a synthetic pack label for Exercise 7
- data/field_reports.txt     twelve field reports for Exercise 8
- scripts/                   optional: count_tokens.py and compare_settings.py
- solutions/                 answer_key.md and a Word solution document: open them only after
                             you have tried each exercise

Exercises 1 to 3 need no model. Exercises 4 to 9 use the chat playground in Microsoft
Foundry with a chat deployment; Exercise 7 needs one that accepts images.

Optional scripts (Python 3.10 or later):

    cd scripts
    python -m pip install -r requirements.txt
    python count_tokens.py
    python compare_settings.py --mock          # practice run, no Azure needed
    copy .env.example .env                     # macOS or Linux: cp .env.example .env
    python compare_settings.py                 # real run once .env is filled in

Never commit .env. It holds your API key.

VoltEdge, its serial numbers, error codes and the pack label are invented for training.
