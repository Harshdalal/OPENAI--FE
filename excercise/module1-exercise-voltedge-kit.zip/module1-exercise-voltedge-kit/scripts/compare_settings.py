"""Run the Module 1 exercise prompts (VoltEdge) several times at several temperatures and compare the answers.

Usage:
    python compare_settings.py --mock                 practice run, no Azure needed
    python compare_settings.py                        real run, reads .env
    python compare_settings.py --temps 0 0.7 1.5 --runs 5 --prompts A B C D
    python compare_settings.py --reasoning-none       for GPT-5.x models that accept
                                                      temperature only with reasoning off

Writes results/run_<time>.csv and prints a summary table.
"""
import argparse
import csv
import difflib
import os
import random
import re
import sys
import time
from datetime import datetime
from pathlib import Path

HERE = Path(__file__).resolve().parent
KIT = HERE.parent

GROUNDING = "Answer only from the specification. If the specification does not say, reply exactly: Not in the spec."
PROMPTS = {
    "A": "What charge current does the charger use at a battery temperature of 47.3 °C? Reply with the number of mA only.",
    "B": "Suggest five test ideas for this specification, one line each.",
    "C": ("Which fault code does the charger report over SMBus when the battery reads 105.0 °C, "
          "and which register sets the charge current?"),
}
EXPECTED_A = 1890


def load_env(path):
    """Read KEY=VALUE lines from .env into os.environ (no extra package needed)."""
    if not path.exists():
        return
    for line in path.read_text(encoding="utf-8").splitlines():
        line = line.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        key, value = line.split("=", 1)
        os.environ.setdefault(key.strip(), value.strip().strip('"').strip("'"))


def system_message(grounded):
    spec = (KIT / "charge_spec.md").read_text(encoding="utf-8")
    text = "You are a firmware test assistant for the VoltEdge team. Use this specification:\n\n" + spec
    if grounded:
        text += "\n\n" + GROUNDING
    return text


def plan(prompt_ids):
    """Prompt D is Prompt C with the grounding line added to the system message."""
    jobs = []
    for pid in prompt_ids:
        if pid == "D":
            jobs.append(("D", PROMPTS["C"], True))
        else:
            jobs.append((pid, PROMPTS[pid], False))
    return jobs


# ---------------------------------------------------------------- model calls
class RealModel:
    def __init__(self, reasoning_none):
        try:
            from openai import OpenAI
        except ImportError:
            sys.exit("The openai package is missing. Run: python -m pip install -r requirements.txt")
        missing = [k for k in ("OPENAI_BASE_URL", "OPENAI_API_KEY", "MODEL_DEPLOYMENT") if not os.getenv(k)]
        if missing:
            sys.exit(f"Missing in .env: {', '.join(missing)}. Copy .env.example to .env and fill it in, "
                     "or run with --mock.")
        self.client = OpenAI()  # reads OPENAI_BASE_URL and OPENAI_API_KEY
        self.model = os.environ["MODEL_DEPLOYMENT"]
        self.reasoning_none = reasoning_none
        self.label = self.model

    def ask(self, system, prompt, temperature, max_tokens):
        args = dict(model=self.model, instructions=system, input=prompt,
                    temperature=temperature, max_output_tokens=max_tokens)
        if self.reasoning_none:
            args["reasoning"] = {"effort": "none"}
        resp = self.client.responses.create(**args)
        usage = getattr(resp, "usage", None)
        return (resp.output_text or "").strip(), getattr(usage, "input_tokens", ""), getattr(usage, "output_tokens", "")


class MockModel:
    """Offline stand-in that imitates typical behaviour. Its answers are invented on purpose."""
    label = "MOCK (not a real model)"

    def __init__(self, seed=7):
        self.rng = random.Random(seed)

    def ask(self, system, prompt, temperature, max_tokens):
        r = self.rng.random()
        grounded = GROUNDING in system
        if prompt == PROMPTS["A"]:
            if temperature >= 1.4 and r < 0.4:
                text = self.rng.choice(["1885", "1890 mA (1885 rounded half up)", "1880"])
            else:
                text = "1890"
        elif prompt == PROMPTS["B"]:
            pool = ["-0.1 °C gives 0 mA", "0.0 °C gives 500 mA", "47.3 °C rounds 1885 up to 1890 mA",
                    "44.9 °C gives 2000 mA", "59.9 °C rounds 1255 up to 1260 mA", "60.0 °C and above gives 0 mA",
                    "-20.1 °C is a sensor fault", "100.1 °C is a sensor fault", "Rounding half up at 5 mA",
                    "Current never exceeds 2000 mA", "Current is stable at a constant temperature", "Charge LED blinks on fault"]
            k = 5 if temperature < 0.3 else (8 if temperature < 1.2 else 12)
            text = "\n".join(pool[:5] if k == 5 else self.rng.sample(pool[:k], 5))
        else:
            if grounded:
                text = "Not in the spec"
            else:
                code = self.rng.choice(["0x2A in SMBus BatteryStatus", "C-301 on SMBus 0x16"]) if temperature > 0.5 else "0x2A in SMBus BatteryStatus"
                reg = self.rng.choice(["ChargingCurrent (0x14)", "ICHG_CTRL (0x02)", "CHG_CUR.SET"]) \
                    if temperature > 0.5 else "ChargingCurrent (0x14)"
                text = f"The charger reports fault code {code}. The charge current is set in {reg}."
        return text, len(system + prompt) // 4, len(text) // 4


# ---------------------------------------------------------------- analysis
def similarity(texts):
    """Average pairwise similarity, 0 to 1. 1.0 means every run gave identical text."""
    if len(texts) < 2:
        return 1.0
    scores = [difflib.SequenceMatcher(None, a, b).ratio() for i, a in enumerate(texts) for b in texts[i + 1:]]
    return sum(scores) / len(scores)


def check(pid, text):
    if pid == "A":
        nums = [float(n) for n in re.findall(r"\d+(?:\.\d+)?", text.replace(",", "")) if float(n) != 47.3]
        return "correct" if nums and nums[0] == EXPECTED_A else "wrong"
    if pid in ("C", "D"):
        return "said not in spec" if "not in the spec" in text.lower() else "gave an answer"
    return ""


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--temps", nargs="+", type=float, default=[0.0, 1.0, 1.5])
    ap.add_argument("--runs", type=int, default=3)
    ap.add_argument("--prompts", nargs="+", default=["A", "B", "C", "D"], choices=["A", "B", "C", "D"])
    ap.add_argument("--max-tokens", type=int, default=400)
    ap.add_argument("--reasoning-none", action="store_true", help="send reasoning effort 'none' (GPT-5.x models)")
    ap.add_argument("--mock", action="store_true", help="offline practice run with invented answers")
    args = ap.parse_args()

    load_env(HERE / ".env")
    model = MockModel() if args.mock else RealModel(args.reasoning_none)
    print(f"Model: {model.label}   temperatures: {args.temps}   runs: {args.runs}\n")

    out_dir = HERE / "results"
    out_dir.mkdir(exist_ok=True)
    out_file = out_dir / f"run_{datetime.now():%Y%m%d_%H%M%S}.csv"
    rows = []
    skipped = set()
    for pid, prompt, grounded in plan(args.prompts):
        system = system_message(grounded)
        for t in args.temps:
            if t in skipped:
                continue
            for run in range(1, args.runs + 1):
                try:
                    text, tin, tout = model.ask(system, prompt, t, args.max_tokens)
                    err = ""
                except Exception as e:  # report and carry on: one bad setting should not stop the lab
                    text, tin, tout, err = "", "", "", f"{type(e).__name__}: {str(e)[:160]}"
                    if "temperature" in str(e).lower():
                        print(f"  Temperature {t} is not supported by this deployment. "
                              "Try --reasoning-none, or a chat model.")
                        skipped.add(t)
                rows.append(dict(model=model.label, prompt=pid, grounded=grounded, temperature=t, run=run,
                                 answer=text, check=check(pid, text) if text else "", input_tokens=tin,
                                 output_tokens=tout, error=err))
                print(f"  {pid}  temp {t:<4} run {run}: {(text or err).splitlines()[0][:70] if (text or err) else ''}")
                if not args.mock:
                    time.sleep(0.5)  # stay well under rate limits
                if err:
                    break

    with out_file.open("w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=list(rows[0].keys()))
        w.writeheader()
        w.writerows(rows)

    print("\nSummary (similarity 1.00 = identical text in every run)")
    print(f"{'prompt':<7}{'temp':<7}{'runs':<6}{'distinct':<10}{'similarity':<12}check")
    for pid, _, _ in plan(args.prompts):
        for t in args.temps:
            texts = [r["answer"] for r in rows if r["prompt"] == pid and r["temperature"] == t and r["answer"]]
            if not texts:
                continue
            checks = [r["check"] for r in rows if r["prompt"] == pid and r["temperature"] == t and r["check"]]
            summary = ", ".join(f"{c}: {checks.count(c)}" for c in sorted(set(checks)))
            print(f"{pid:<7}{t:<7}{len(texts):<6}{len(set(texts)):<10}{similarity(texts):<12.2f}{summary}")
    print(f"\nSaved {len(rows)} rows to {out_file}")
    if args.mock:
        print("This was a MOCK run: the answers were invented by the script, not by a model.")


if __name__ == "__main__":
    main()
