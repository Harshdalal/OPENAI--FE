# VoltEdge VE-200 charger: the source of truth

The product owner and the battery lead agreed this specification and its examples. An AI
answer is correct only if it matches them. Paste this whole file into the system message
(Instructions) box.

VoltEdge is a fictional product used for training. It is not a real product.

## Story

As a VoltEdge owner, I want the charger to reduce the charge current when the battery is
cold or hot, so the battery charges safely and lasts longer.

## Rules

- C1. Battery temperature below 0.0 °C: no charging, current 0 mA.
- C2. Battery temperature from 0.0 °C to 9.9 °C: current 500 mA.
- C3. Battery temperature from 10.0 °C to 44.9 °C: current 2000 mA.
- C4. Battery temperature from 45.0 °C to 59.9 °C: current = 2000 - (temperature - 45.0) x 50 mA.
- C5. Battery temperature of 60.0 °C or more: no charging, current 0 mA.
- C6. Round the current to the nearest 10 mA, half up.
- C7. A reading below -20.0 °C or above 100.0 °C is a sensor fault. The specification does not
  yet say how the fault is reported.

## Agreed examples

| ID | Battery temperature (°C) | Current (mA) | Rule |
|----|--------------------------|--------------|------|
| 1  | -0.1                     | 0            | C1   |
| 2  | 0.0                      | 500          | C2   |
| 3  | 47.3                     | 1890         | C4, C6 (1885 rounds up) |
| 4  | 25.0                     | 2000         | C3   |
| 5  | 59.9                     | 1260         | C4, C6 (1255 rounds up) |
| 6  | 60.0                     | 0            | C5   |

## Not in this specification

Fault codes, SMBus and CAN message formats, register names and addresses, charge voltage,
LED patterns and how a sensor fault is reported are not defined yet.
