# Practice case study: VoltEdge VE-200 charger

A fictional smart battery charger, used for the Module 1 practice exercises. It is a different
product from NovaBoard, the course case study, so you practise the same skills on material
you have not seen before.

## The product

- Microcontroller that charges a two-cell lithium-ion battery pack
- NTC thermistor on the pack to measure battery temperature
- Charge current set from the battery temperature (rules in charge_spec.md)
- SMBus link to the pack, UART debug console
- Firmware updates over Bluetooth or USB

## How it maps to the Module 1 activity

| In class: NovaBoard | In practice: VoltEdge |
|---------------------|-----------------------|
| fan_spec.md: fan duty from board temperature | charge_spec.md: charge current from battery temperature |
| Prompt A: 41.8 °C gives 55% (54.5 rounds up) | Prompt A: 47.3 °C gives 1890 mA (1885 rounds up) |
| Trap: CAN fault code and PWM register | Trap: SMBus fault code and charge current register |
| Field reports for text analysis | Field reports for text analysis, plus a pack label image to extract |

VoltEdge, its serial numbers, error codes and label are invented for training.
