# Module 1 exercise prompts: VoltEdge (copy and paste)

Work in the chat playground with the deployment your trainer shares. Start a new chat before
every run, so earlier answers do not influence the next one.

## System message 1 (paste into the Instructions or System message box)

You are a firmware test assistant for the VoltEdge team. Use this specification:

<paste the whole of charge_spec.md here>

## Prompt A: one right answer (Exercises 4 and 6)

What charge current does the charger use at a battery temperature of 47.3 °C? Reply with the number of mA only.

## Prompt B: many good answers (Exercises 4 and 5)

Suggest five test ideas for this specification, one line each.

## Prompt C: the trap (the specification does not contain this) (Exercise 6)

Which fault code does the charger report over SMBus when the battery reads 105.0 °C, and which register sets the charge current?

## System message 2 (Exercise 6: add this line at the end of System message 1)

Answer only from the specification. If the specification does not say, reply exactly: Not in the spec.

## Prompt D: the trap, grounded (Exercise 6)

Send Prompt C again, unchanged, with System message 2 in place. Then send Prompt A once more.

## Prompt E: extract from an image (Exercise 7, needs a deployment that accepts images)

Clear the Instructions box first, so the label is the only source. Attach data/pack_label.png, then send:

Extract these fields from the label as JSON: model, serial, nominal_voltage_v, capacity_mah,
energy_wh, charge_temp_min_c, charge_temp_max_c, mfg_date, firmware, max_charge_current_ma.
Use numbers for numeric fields. Use null for any field that is not printed on the label.
Reply with JSON only.

## Prompt F: text analysis (Exercise 8, use data/field_reports.txt)

Paste the field reports below this prompt:

For these field reports, give me: (1) the five main keywords, (2) every entity you find
(firmware versions, serial numbers, error codes, dates, temperatures, currents), (3) the
sentiment of each report as positive, negative, neutral or mixed, and (4) a three-line
summary. Use a table for (3).
