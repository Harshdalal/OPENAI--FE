# Module 2 practice exercises: VoltEdge charger

A second case study for practice after the Module 2 lab. In class you worked on NovaBoard;
here you practise the same Microsoft Foundry skills on the VoltEdge VE-200 charger, on your
own and at your own pace (about 75 to 90 minutes).

Only Module 2 content is used: ChatGPT, the OpenAI API and Azure OpenAI in Foundry, the model
catalog and deployments, the playground, a chat client with the OpenAI SDK and the Foundry
SDK, a prompt agent, multimodal input, Content Understanding, structured outputs, tool
calling, embeddings, privacy and access.

- CASE_STUDY.md                         how VoltEdge maps to the NovaBoard lab
- requirements/REQ-207_charge_fault.md  the requirement (source of truth)
- data/boot_log_VE-30187.txt            the boot log for Exercise 2
- data/bug_reports.txt                  12 bug reports for Exercise 9
- data/ve_status_screen.png             a status screen with planted defects (Exercise 10)
- data/VC21_datasheet_p4.pdf            a fictional charger IC datasheet page (Exercise 11)
- agent/agent_instructions.md           instructions for the ve-test-assistant agent
- prompts.md                            all prompts, in exercise order
- exercise_worksheet.md                 record your answers here
- scripts/                              Python: 01 chat, 02 Foundry SDK, 03 scenarios,
                                        04 tool calling, 05 embeddings, 06 image input
- solutions/                            answer key and a Word solution document: open them
                                        only after you have tried each exercise

Setup (Python 3.10 or later):

    cd scripts
    python -m pip install -r requirements.txt
    python 03_generate_scenarios.py --mock      practice run, no Azure needed
    copy .env.example .env                      macOS or Linux: cp .env.example .env
    python 03_generate_scenarios.py             real run once .env is filled in

Every script except 02 accepts --mock. Mock answers are invented by the script.
Never commit .env. VoltEdge, VoltChip, serial numbers, registers and codes are fictional.
