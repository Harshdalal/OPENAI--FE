# Practice case study: VoltEdge VE-200 charger (Module 2)

The same fictional charger as the Module 1 practice exercises. In the Module 2 lab you worked
on NovaBoard; here you practise the same Microsoft Foundry skills on VoltEdge material you
have not seen before.

| In class: NovaBoard | In practice: VoltEdge |
|---------------------|-----------------------|
| REQ-118: handle a temperature sensor fault | REQ-207: stop charging on a thermistor fault |
| Boot log of NB-20431 | Boot log of VE-30187 |
| Agent nb-test-assistant | Agent ve-test-assistant |
| 12 NovaBoard bug reports | 12 VoltEdge bug reports |
| NovaBoard status screen, 5 planted defects | VoltEdge charger status screen, 5 planted defects |
| NT-48 sensor datasheet page | VC-21 charger IC datasheet page |

VoltEdge, VoltChip, their serial numbers, registers and codes are invented for training.
