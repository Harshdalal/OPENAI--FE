"""Exercise 9: embeddings. Find bug reports that probably describe the same defect.

Needs an embedding deployment (for example text-embedding-3-small) named in EMBEDDING_DEPLOYMENT.
    python 05_embeddings_duplicates.py
    python 05_embeddings_duplicates.py --threshold 0.6
    python 05_embeddings_duplicates.py --mock
"""
import argparse
import math
import os

from common import MOCK, get_client, read


def cosine(a, b):
    dot = sum(x * y for x, y in zip(a, b))
    return dot / ((math.sqrt(sum(x * x for x in a)) * math.sqrt(sum(y * y for y in b))) or 1.0)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--threshold", type=float, default=None, help="similarity needed to flag a pair")
    ap.add_argument("--mock", action="store_true")
    args = ap.parse_args()
    threshold = args.threshold if args.threshold is not None else (0.4 if MOCK else 0.6)

    lines = [l for l in read("data/bug_reports.txt").splitlines() if "|" in l]
    ids = [l.split("|")[0].strip() for l in lines]
    texts = [l.split("|", 1)[1].strip() for l in lines]

    client = get_client()
    model = os.getenv("EMBEDDING_DEPLOYMENT") or ("mock" if MOCK else "")
    if not model:
        raise SystemExit("Set EMBEDDING_DEPLOYMENT in scripts/.env, or add --mock.")
    result = client.embeddings.create(model=model, input=texts)
    vectors = [d.embedding for d in result.data]
    print(f"{len(vectors)} reports turned into vectors of {len(vectors[0])} numbers each.\n")

    pairs = []
    for i in range(len(texts)):
        for j in range(i + 1, len(texts)):
            pairs.append((cosine(vectors[i], vectors[j]), i, j))
    pairs.sort(reverse=True)

    print(f"Likely duplicates (similarity {threshold:.2f} or more):")
    found = False
    for score, i, j in pairs:
        if score < threshold:
            break
        found = True
        print(f"  {score:.2f}  {ids[i]} <-> {ids[j]}\n        {texts[i]}\n        {texts[j]}")
    if not found:
        print("  none. Try a lower --threshold.")
    print("\nTop 5 pairs overall, for comparison:")
    for score, i, j in pairs[:5]:
        print(f"  {score:.2f}  {ids[i]} <-> {ids[j]}")
    print("\nA person decides whether each pair is really a duplicate.")


if __name__ == "__main__":
    main()
