"""Exercise 7: generate test scenarios from a requirement as structured output, then check coverage.

    python 03_generate_scenarios.py                         uses requirements/REQ-207_charge_fault.md
    python 03_generate_scenarios.py --req requirements/REQ-207_charge_fault.md
    python 03_generate_scenarios.py --mock                  practice run

Writes output/REQ-207_scenarios.json and output/REQ-207_scenarios.csv.
The JSON schema forces the model to answer in a shape code can check.
"""
import argparse
import csv
import json
import re

from common import KIT, get_client, model_name, read

SCHEMA = {
    "type": "object",
    "additionalProperties": False,
    "required": ["requirement_id", "scenarios", "questions_for_firmware_lead"],
    "properties": {
        "requirement_id": {"type": "string"},
        "scenarios": {
            "type": "array",
            "items": {
                "type": "object",
                "additionalProperties": False,
                "required": ["id", "title", "type", "covers", "preconditions", "steps", "expected_result"],
                "properties": {
                    "id": {"type": "string", "description": "TS-01, TS-02 and so on"},
                    "title": {"type": "string"},
                    "type": {"type": "string", "enum": ["positive", "negative", "boundary", "fault-injection"]},
                    "covers": {"type": "array", "items": {"type": "string"}, "description": "Acceptance criteria IDs such as AC1"},
                    "preconditions": {"type": "string"},
                    "steps": {"type": "array", "items": {"type": "string"}},
                    "expected_result": {"type": "string"},
                },
            },
        },
        "questions_for_firmware_lead": {"type": "array", "items": {"type": "string"}},
    },
}

INSTRUCTIONS = (
    "You are a firmware test assistant. Write test scenarios for the requirement the user gives you. "
    "Cover every acceptance criterion at least once and add a boundary scenario for every number. "
    "Use only the requirement; put anything it does not say into questions_for_firmware_lead. "
    "Do not invent register names, addresses or log lines. Use obviously fake test data."
)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--req", default="requirements/REQ-207_charge_fault.md")
    ap.add_argument("--mock", action="store_true")
    args = ap.parse_args()

    requirement = read(args.req)
    client = get_client()
    response = client.responses.create(
        model=model_name() or "mock",
        instructions=INSTRUCTIONS,
        input=requirement,
        text={"format": {"type": "json_schema", "name": "test_scenarios", "schema": SCHEMA, "strict": True}},
    )
    data = json.loads(response.output_text)  # strict schema: this parses, or the call failed
    scenarios = data["scenarios"]

    # Coverage check: done by code, not by asking the model
    wanted = sorted(set(re.findall(r"^- (AC\d+)\.", requirement, flags=re.M)), key=lambda a: int(a[2:]))
    covered = {ac for s in scenarios for ac in s["covers"]}
    missing = [ac for ac in wanted if ac not in covered]
    types = SCHEMA["properties"]["scenarios"]["items"]["properties"]["type"]["enum"]
    by_type = {t: sum(1 for s in scenarios if s["type"] == t) for t in types}

    out = KIT / "output"
    out.mkdir(exist_ok=True)
    req_id = data["requirement_id"] or "REQ"
    (out / f"{req_id}_scenarios.json").write_text(json.dumps(data, indent=2), encoding="utf-8")
    with (out / f"{req_id}_scenarios.csv").open("w", newline="", encoding="utf-8") as f:
        w = csv.writer(f)
        w.writerow(["id", "title", "type", "covers", "preconditions", "steps", "expected_result"])
        for s in scenarios:
            w.writerow([s["id"], s["title"], s["type"], " ".join(s["covers"]), s["preconditions"],
                        " | ".join(s["steps"]), s["expected_result"]])

    print(f"{len(scenarios)} scenarios for {req_id}: " + ", ".join(f"{k} {v}" for k, v in by_type.items()))
    for s in scenarios:
        print(f"  {s['id']:<6} {s['type']:<16} {' '.join(s['covers']):<9} {s['title']}")
    print(f"\nAcceptance criteria in the requirement: {', '.join(wanted)}")
    print("Coverage check: " + ("every criterion is covered." if not missing else f"NOT covered: {', '.join(missing)}"))
    if data["questions_for_firmware_lead"]:
        print("\nQuestions for the firmware lead:")
        for q in data["questions_for_firmware_lead"]:
            print(f"  - {q}")
    print(f"\nSaved output/{req_id}_scenarios.json and .csv   [tokens in {response.usage.input_tokens}, out {response.usage.output_tokens}]")
    print("Review every scenario before it goes into your test plan or bench script.")


if __name__ == "__main__":
    main()
