"""Shared helpers for the Module 2 practice scripts (VoltEdge): settings, the client, and an offline mock."""
import base64
import hashlib
import json
import math
import os
import re
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
KIT = HERE.parent
MOCK = "--mock" in sys.argv


def load_env():
    """Read KEY=VALUE lines from scripts/.env (no extra package needed)."""
    path = HERE / ".env"
    if not path.exists():
        return
    for line in path.read_text(encoding="utf-8").splitlines():
        line = line.strip()
        if line and not line.startswith("#") and "=" in line:
            key, value = line.split("=", 1)
            os.environ.setdefault(key.strip(), value.strip().strip('"').strip("'"))


def setting(name):
    value = os.getenv(name, "")
    if not value and not MOCK:
        sys.exit(f"Missing {name} in scripts/.env. Copy .env.example to .env and fill it in, or add --mock.")
    return value


def get_client():
    """An OpenAI client pointed at your Foundry resource, or the offline mock."""
    load_env()
    if MOCK:
        print("MOCK MODE: answers are invented by the script, not by a model.\n")
        return MockClient()
    try:
        from openai import OpenAI
    except ImportError:
        sys.exit("The openai package is missing. Run: python -m pip install -r requirements.txt")
    base_url = setting("OPENAI_BASE_URL")
    if os.getenv("AUTH", "key").lower() == "entra":
        # Keyless: uses your az login identity. Needs the Foundry User role on the resource.
        from azure.identity import DefaultAzureCredential, get_bearer_token_provider
        token = get_bearer_token_provider(DefaultAzureCredential(), "https://ai.azure.com/.default")
        return OpenAI(base_url=base_url, api_key=token)
    return OpenAI(base_url=base_url, api_key=setting("OPENAI_API_KEY"))


def model_name():
    return os.getenv("MODEL_DEPLOYMENT") or setting("MODEL_DEPLOYMENT")


def read(rel):
    return (KIT / rel).read_text(encoding="utf-8")


def image_data_url(rel):
    data = (KIT / rel).read_bytes()
    return "data:image/png;base64," + base64.b64encode(data).decode()


# ---------------------------------------------------------------- offline mock
class _Obj:
    def __init__(self, **kw):
        self.__dict__.update(kw)


def _resp(text="", output=None, tin=0, tout=0):
    rid = "resp_mock_" + hashlib.md5((text + str(output)).encode()).hexdigest()[:8]
    return _Obj(id=rid, output_text=text, output=output or [], usage=_Obj(input_tokens=tin, output_tokens=tout))


def _words(text):
    return re.findall(r"[a-z0-9]+", text.lower())


class _MockResponses:
    def create(self, model=None, input=None, instructions=None, text=None, tools=None, previous_response_id=None, **kw):
        flat = json.dumps(input) + (instructions or "")
        tin = len(flat) // 4
        if text and text.get("format", {}).get("type") == "json_schema":
            return _resp(json.dumps(_mock_scenarios(flat)), tin=tin, tout=600)
        if isinstance(input, list) and any(isinstance(i, dict) and i.get("type") == "function_call_output" for i in input):
            out = next(i["output"] for i in input if isinstance(i, dict) and i.get("type") == "function_call_output")
            n = len(re.findall(r"- AC\d", out))
            if n == 0:
                return _resp("I could not find that requirement: the tool returned no text for it. Please check the ID.", tin=tin, tout=25)
            return _resp(f"REQ-207 has {n} acceptance criteria. The riskiest to test on the bench are AC2 (4 invalid readings "
                         "in a row, 250 ms apart) and AC6 (locking after more than 3 fault stops in 10 minutes), because both "
                         "depend on exact counts and timing that need fault injection.", tin=tin, tout=60)
        if tools:
            m = re.search(r"REQ-\d+", flat)
            call = _Obj(type="function_call", name="get_requirement", call_id="call_mock_1",
                        arguments=json.dumps({"req_id": m.group(0) if m else "REQ-207"}))
            return _resp("", output=[call], tin=tin, tout=20)
        if "input_image" in flat:
            return _resp("1. Label says \"Batery\" instead of \"Battery\".\n"
                         "2. 105.0 C is shown with status OK: breaks AC1, a reading above 100.0 C is invalid.\n"
                         "3. Charge current shows 500 mA during a fault stop: breaks AC3, it must be 0 mA.\n"
                         "4. Fault code shows C-181, not C-118: breaks AC4.\n"
                         "5. The charge current bar runs past the edge of its panel.", tin=tin, tout=80)
        return _resp("Mock reply: in a real run the model answers here. Try --mock with the other scripts too.", tin=tin, tout=20)


def _mock_scenarios(text):
    acs = sorted(set(re.findall(r"AC(\d)", text)))
    rows, n = [], 1
    kinds = {"1": "boundary", "2": "fault-injection", "3": "positive", "4": "positive", "5": "boundary", "6": "fault-injection"}
    titles = {"1": "Readings of -20.1 and 100.1 C are invalid; -20.0 and 100.0 C are valid; ADC 0x000 and 0xFFF are invalid",
              "2": "Three open-circuit readings then a valid one do not stop charging; four in a row do",
              "3": "Current reaches 0 mA and the LED is solid red within 200 ms of the fault stop",
              "4": "Exactly one C-118 line is logged per fault stop",
              "5": "Nineteen valid readings keep the fault stop; the twentieth resumes charging",
              "6": "A fourth fault stop within 10 minutes locks the charger and logs C-119"}
    for ac in acs:
        if ac == "3":
            continue  # the mock 'forgets' AC3 on purpose, so the coverage check has something to find
        rows.append({"id": f"TS-{n:02d}", "title": titles.get(ac, f"Scenario for AC{ac}"), "type": kinds.get(ac, "positive"),
                     "covers": [f"AC{ac}"], "preconditions": "Bench rig with thermistor emulator, firmware v1.7.1", "steps": ["Set the emulated thermistor value", "Observe charge current, LED and log"],
                     "expected_result": "Behaviour matches the acceptance criterion."})
        n += 1
    return {"requirement_id": "REQ-207", "scenarios": rows, "questions_for_firmware_lead": ["Is the 10-minute window rolling or fixed?",
            "Does a reading of exactly -20.0 or 100.0 C count as valid?", "How is a locked fault reported over SMBus?"]}


_CONCEPTS = {w: "latch" for w in ("never", "restarts", "pull", "pack", "back", "stays", "off", "reinserted", "glitch", "until")}
_CONCEPTS.update({w: "single" for w in ("single", "one", "bad", "sample", "immediately", "straight", "away", "triggers", "stops")})
_CONCEPTS.update({w: "duplicate" for w in ("twice", "duplicate", "logged", "lines", "118")})
_CONCEPTS.update({w: "range" for w in ("105", "range", "valid", "accepted", "degrees", "flagged", "out", "treated", "continues")})


class _MockEmbeddings:
    def create(self, model=None, input=None, **kw):
        texts = input if isinstance(input, list) else [input]
        data = []
        for t in texts:
            vec = [0.0] * 256
            for w in _words(t):
                if len(w) > 2:
                    w = _CONCEPTS.get(w, w)  # crude stand-in for meaning: real embeddings do this far better
                    vec[int(hashlib.md5(w.encode()).hexdigest(), 16) % 256] += 1.0
            norm = math.sqrt(sum(v * v for v in vec)) or 1.0
            data.append(_Obj(embedding=[v / norm for v in vec]))
        return _Obj(data=data, usage=_Obj(prompt_tokens=sum(len(t) // 4 for t in texts)))


class MockClient:
    def __init__(self):
        self.responses = _MockResponses()
        self.embeddings = _MockEmbeddings()
