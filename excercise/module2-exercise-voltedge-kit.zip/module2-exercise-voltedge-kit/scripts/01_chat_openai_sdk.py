"""Exercise 5: a simple chat client with the OpenAI SDK, pointed at your Foundry deployment.

Type a question, press Enter. Type 'exit' to stop.
    python 01_chat_openai_sdk.py            real run (reads .env)
    python 01_chat_openai_sdk.py --mock     practice run, no Azure needed
"""
from common import get_client, model_name

SYSTEM = "You are a helpful firmware assistant for the VoltEdge charger team. Keep answers short."


def main():
    client = get_client()
    model = model_name() or "mock"
    previous = None  # the service keeps the conversation; we pass the last response id
    print(f"Chatting with deployment '{model}'. Type 'exit' to stop.\n")
    while True:
        try:
            question = input("You: ").strip()
        except EOFError:
            break
        if question.lower() in ("exit", "quit", ""):
            break
        extra = {"previous_response_id": previous} if previous else {}
        response = client.responses.create(model=model, instructions=SYSTEM, input=question, **extra)
        previous = response.id
        usage = response.usage
        print(f"\nAI: {response.output_text}\n   [tokens in {usage.input_tokens}, out {usage.output_tokens}]\n")


if __name__ == "__main__":
    main()
