"""Exercise 8: tool calling. The model asks your code to fetch a requirement, then answers.

    python 04_tool_calling.py
    python 04_tool_calling.py --mock
    python 04_tool_calling.py --question "How many acceptance criteria does REQ-999 have?"

The model never reads your files itself. It returns a request to call get_requirement;
this script runs the function and sends the result back.
"""
import argparse
import json

from common import KIT, get_client, model_name

TOOLS = [{
    "type": "function",
    "name": "get_requirement",
    "description": "Return the full text of a VoltEdge requirement by its ID, for example REQ-207.",
    "parameters": {
        "type": "object",
        "properties": {"req_id": {"type": "string", "description": "Requirement ID such as REQ-207"}},
        "required": ["req_id"],
        "additionalProperties": False,
    },
    "strict": True,
}]


def get_requirement(req_id):
    """Your code, your rules: only files in requirements/ can be returned."""
    matches = list((KIT / "requirements").glob(f"{req_id}_*.md"))
    return matches[0].read_text(encoding="utf-8") if matches else f"No requirement found with ID {req_id}."


def main():
    client = get_client()
    model = model_name() or "mock"
    ap = argparse.ArgumentParser()
    ap.add_argument("--question", default="How many acceptance criteria does REQ-207 have, and which two are riskiest "
                                          "to test on the bench? Explain briefly.")
    ap.add_argument("--mock", action="store_true")
    question = ap.parse_args().question
    print(f"You: {question}\n")

    first = client.responses.create(model=model, input=question, tools=TOOLS)
    calls = [item for item in first.output if getattr(item, "type", "") == "function_call"]
    if not calls:
        print("The model answered without calling the tool:\n" + first.output_text)
        return

    results = []
    for call in calls:
        args = json.loads(call.arguments)
        print(f"Model asked to call: {call.name}({args})")
        text = get_requirement(**args)
        print(f"Your code returned {len(text)} characters.\n")
        results.append({"type": "function_call_output", "call_id": call.call_id, "output": text})

    final = client.responses.create(model=model, previous_response_id=first.id, input=results, tools=TOOLS)
    print("AI: " + final.output_text)


if __name__ == "__main__":
    main()
