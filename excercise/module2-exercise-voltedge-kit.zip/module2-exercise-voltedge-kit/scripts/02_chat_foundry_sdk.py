"""Exercise 6 (optional): the same chat through the Foundry SDK, signed in with your Azure identity.

No API key: run 'az login' first. Needs FOUNDRY_PROJECT_ENDPOINT and MODEL_DEPLOYMENT in .env,
and the Foundry User role on the project.
    python 02_chat_foundry_sdk.py                 chat with the model deployment
    python 02_chat_foundry_sdk.py --agent         chat with the portal agent named in AGENT_NAME
"""
import os
import sys

from common import load_env

load_env()


def main():
    try:
        from azure.ai.projects import AIProjectClient
        from azure.identity import DefaultAzureCredential
    except ImportError:
        sys.exit("Run: python -m pip install -r requirements.txt")
    endpoint = os.getenv("FOUNDRY_PROJECT_ENDPOINT")
    model = os.getenv("MODEL_DEPLOYMENT")
    agent = os.getenv("AGENT_NAME", "ve-test-assistant")
    use_agent = "--agent" in sys.argv
    if not endpoint or not model:
        sys.exit("Set FOUNDRY_PROJECT_ENDPOINT and MODEL_DEPLOYMENT in scripts/.env (project home page shows the endpoint).")

    with DefaultAzureCredential() as credential, \
            AIProjectClient(endpoint=endpoint, credential=credential) as project, \
            project.get_openai_client() as client:
        target = f"agent '{agent}'" if use_agent else f"deployment '{model}'"
        print(f"Connected to {endpoint}\nChatting with {target}. Type 'exit' to stop.\n")
        conversation = client.conversations.create()  # the service stores the turns
        while True:
            try:
                question = input("You: ").strip()
            except EOFError:
                break
            if question.lower() in ("exit", "quit", ""):
                break
            if use_agent:
                response = client.responses.create(
                    conversation=conversation.id,
                    input=question,
                    extra_body={"agent_reference": {"name": agent, "type": "agent_reference"}},
                )
            else:
                response = client.responses.create(
                    model=model,
                    conversation=conversation.id,
                    instructions="You are a helpful firmware assistant for the VoltEdge charger team. Keep answers short.",
                    input=question,
                )
            print(f"\nAI: {response.output_text}\n")


if __name__ == "__main__":
    main()
