"""Exercise 10: multimodal input. Send a VoltEdge charger status screen and ask for visible defects.

The deployment must accept image input (check the model card in the Foundry catalog).
    python 06_image_input.py
    python 06_image_input.py --mock
"""
from common import get_client, image_data_url, model_name

PROMPT = ("You are reviewing a VoltEdge charger status screen against REQ-207. List every visible defect: spelling, "
          "layout, wrong values and anything that breaks an acceptance criterion. One line each.\n\n"
          "REQ-207 facts: a battery temperature above 100.0 C is invalid; in fault stop the charge current is 0 mA and "
          "the status LED is solid red; the fault is logged as code C-118.")


def main():
    client = get_client()
    response = client.responses.create(
        model=model_name() or "mock",
        input=[{
            "role": "user",
            "content": [
                {"type": "input_text", "text": PROMPT},
                {"type": "input_image", "image_url": image_data_url("data/ve_status_screen.png")},
            ],
        }],
    )
    print(response.output_text)
    print("\nCompare with the solutions document. Did it miss or invent anything?")


if __name__ == "__main__":
    main()
