# Module 2 exercise worksheet: VoltEdge

Name: ____________________   Chat deployment: ____________   Embedding deployment: ____________

Try every exercise before you open the solutions.

## Exercise 1: the way in, and your deployment

| VoltEdge situation | ChatGPT, OpenAI API, or Azure OpenAI in Foundry? | Why |
|--------------------|--------------------------------------------------|-----|
| a. Rewrite your own release-note draft, no client material | | |
| b. A script that classifies charger logs from the client's source tree | | |
| c. A personal side project that calls a model from Python | | |
| d. An assistant that needs Entra ID sign-in and EU data residency | | |

| Deployment detail | Your value |
|-------------------|------------|
| Deployment name | |
| Model and version | |
| Deployment type | |
| Rate limit (tokens per minute) | |
| Endpoint (resource name only) | |
| Context window (from the model card) | |
| Accepts image input? Structured outputs? Tool calling? | |

## Exercise 2: boot log summary

Most severe finding and its timestamp: ______________________________________

Two other findings: __________________________________________________________

Anything the model invented (part names, root causes, registers)? ____________

## Exercise 3: scenarios in the playground

| Check | Your answer |
|-------|-------------|
| Number of scenarios | |
| Acceptance criteria with no scenario | |
| Boundary values the model used | |
| One good question it asked | |
| Anything invented (registers, SMBus messages, log lines) | |
| What View code showed | |

## Exercise 4: agent

| Version | Change | What changed in the answer |
|---------|--------|----------------------------|
| 1 | Instructions from agent_instructions.md | |
| 2 | Added: bench equipment column | |

## Exercise 5: chat client

| Turn | Input tokens | Output tokens | Did it refer to the previous answer? |
|------|--------------|---------------|--------------------------------------|
| 1 | | | |
| 2 | | | |

## Exercise 7: structured output

| Run | Scenarios | Coverage check result |
|-----|-----------|-----------------------|
| Mock | | |
| Real 1 | | |
| Real 2 | | |
| With AC7 added | | |

## Exercise 8: tool calling

| Question | Did the model call the tool? With which argument? | Final answer, in a few words |
|----------|---------------------------------------------------|------------------------------|
| Default (REQ-207) | | |
| REQ-999 | | |

## Exercise 9: duplicates

| Pair | Score | Really a duplicate? |
|------|-------|---------------------|
| | | |
| | | |
| | | |
| | | |

## Exercise 10: status screen

Defects found by the model: ______   Real defects you can confirm: ______   Invented: ______

## Exercise 11: Content Understanding

| Register | Address | Access | Reset value | Confidence |
|----------|---------|--------|-------------|------------|
| | | | | |
| | | | | |
| | | | | |
| | | | | |
| | | | | |

## Exercise 12: privacy and access

| Situation | Your decision |
|-----------|---------------|
| a. A new test engineer needs to build and run agents in the VoltEdge project | |
| b. The team lead needs to add people to the project | |
| c. A teammate wants to put the API key in the script so it "just works" | |
| d. The client asks whether their source code will train OpenAI's models | |

## Self-check quiz

| Question | 1 | 2 | 3 | 4 | 5 | 6 | 7 | 8 |
|----------|---|---|---|---|---|---|---|---|
| Your answer | | | | | | | | |
