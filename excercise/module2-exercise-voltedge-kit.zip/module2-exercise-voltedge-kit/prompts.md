# Module 2 exercise prompts: VoltEdge (copy and paste)

## Exercise 2: summarise the boot log (playground system message)

You are a firmware support engineer for the VoltEdge charger team. Summarise logs for a busy
engineer. Quote the timestamp for every finding. Use only what is in the log; if the log
does not explain a cause, say "cause not in the log".

User message: paste the whole of data/boot_log_VE-30187.txt, then add this line:

Summarise this boot log as a table with the columns: timestamp, subsystem, severity
(error, warning or info), finding. Most severe first. Then give the three most likely
next checks, one line each.

## Exercise 3: test scenarios (same playground, new chat)

System message:

You are a firmware test assistant. Write test scenarios from the requirement the user
gives you. Use only that requirement. If something is missing, list it under "Questions
for the firmware lead".

User message: paste the whole of requirements/REQ-207_charge_fault.md, then add:

Write test scenarios for this requirement as a table with the columns: ID, title, type
(positive, negative, boundary or fault-injection), acceptance criterion covered,
expected result. Include boundary scenarios for every number in the requirement.

## Exercise 4: agent

Instructions: agent/agent_instructions.md
Test message: paste the whole of requirements/REQ-207_charge_fault.md
Follow-up: Which acceptance criterion has the weakest coverage, and what would you add?
Rule to add for version 2: Add a column: bench equipment needed.

## Exercise 5: chat client (scripts/01_chat_openai_sdk.py)

Give me three fault-injection test ideas for a charger that must stop after four invalid thermistor readings in a row.
Make the second one more specific, with exact timings.

## Exercise 7: AC7 to add, then remove (requirements/REQ-207_charge_fault.md)

- AC7. On leaving fault stop the firmware logs exactly one line: "chg: fault cleared".

## Exercise 10: image input (playground, or scripts/06_image_input.py)

Attach data/ve_status_screen.png and send:

You are reviewing a VoltEdge charger status screen against REQ-207. List every visible
defect: spelling, layout, wrong values and anything that breaks an acceptance criterion.
One line each.

## Exercise 11: Content Understanding fields (Foundry portal)

Custom analyzer fields for data/VC21_datasheet_p4.pdf: register name, address, access,
reset value, description.
