# Answer key: Module 2 practice exercises (VoltEdge)

Try each exercise first. Model answers vary from run to run; use this key to judge your
results, not to match wording.

## Exercise 1: the way in, and your deployment

| Situation | Way in | Why |
|-----------|--------|-----|
| a. Rewrite your own release-note draft | ChatGPT (a company business plan) | Ad hoc drafting with no client material |
| b. Classify logs from the client's source tree | Azure OpenAI in Foundry | Client material: your subscription and tenant, Entra ID, data residency |
| c. Personal side project from Python | OpenAI API | Developer access run by OpenAI, with an OpenAI account and key |
| d. Entra ID sign-in and EU data residency | Azure OpenAI in Foundry | Only the Azure route gives Entra ID, networking and residency controls |

Same model families, different home. For client and source-code work, the client contract
decides first which tool is approved.

Deployment details: your trainer's values. Check that you found them on the deployment page
and the context window and capabilities on the model card, not from memory.

## Exercise 2: boot log summary

| Timestamp | Subsystem | Severity | Finding |
|-----------|-----------|----------|---------|
| [00000.002], [00000.003] | reset | error | Reset cause brownout (BOR); 2 resets in the last 10 minutes |
| [00003.400] to [00003.402] | vbus, brownout | error | VBUS falls to 4.31 V, below the 4.40 V detector level; brownout triggers and the charger resets |
| [00000.120] to [00000.871] | ntc, chg | error | Four open-circuit readings (adc=0xFFF), 250 ms apart, then fault code C-118 |
| [00000.875], [00000.880] | chg, led | info | Charge current 0 mA and LED solid red, 9 ms after the fault (AC3 allows 200 ms) |
| [00002.105] | chg | warning | A second C-118 with no new invalid readings shown |
| [00001.200], [00001.240] | logger | warning | Log buffer full, 14 lines lost: may explain the missing readings before the second C-118 |
| [00000.015] | vbus | warning | 4.62 V at boot, below the 4.75 V minimum |
| [00000.034] | flash | warning | Calibration table missing, defaults used (ntc_beta=3950) |
| [00000.910] | smb | warning | SMBus read at 0x0B, command 0x16: NAK |

Three likely next checks: measure VBUS from the adapter and cable under load; check the
thermistor connection in the pack (open circuit); enlarge the log buffer and check whether the
second C-118 had four new invalid readings (compare VE-BUG-804 and VE-BUG-810).

Watch for invention: a named thermistor part, "the pack is damaged" stated as fact, a link
between the brownouts and the thermistor stated as the cause, or a name for SMBus command
0x16. None of these is in the log. A good answer says "cause not in the log".

## Exercise 3: scenarios in the playground

Roughly 10 to 20 scenarios. Good boundary cases:

- -20.0 °C valid, -20.1 °C invalid; 100.0 °C valid, 100.1 °C invalid (AC1 says below and above).
- ADC 0x000 and 0xFFF invalid (AC1).
- Three invalid readings then a valid one: no fault stop; four in a row: fault stop (AC2).
- Readings 250 ms apart (AC2); current 0 mA and LED solid red at 200 ms (AC3).
- Exactly one C-118 line (AC4).
- 19 valid readings: still stopped; the 20th: charging resumes at the charge_spec current (AC5).
- Third fault stop within 10 minutes: no lock; fourth: locked, C-119 logged (AC6); reinserting the
  pack clears the lock.

Good questions for the firmware lead: is the 10-minute window rolling or fixed? How far apart
are the 20 valid readings? Does a reinsert reset the count of fault stops? What does the LED
show after the fault stop ends? How is a locked fault reported over SMBus (out of scope)?

Watch for invention: register names, SMBus messages or log lines that are not in REQ-207. The
only log lines it defines are in AC4 and AC6. View code shows a short script with your endpoint
and deployment name: the same call as script 01.

## Exercise 4: agent

Version 1: a table in the format the instructions ask for, at least one scenario per criterion and
a "Questions for the firmware lead" list, without repeating the rules in the prompt. Weakest
coverage: often AC5 or AC6 (counts, timing and the 10-minute window). Version 2: a new version
number and the bench equipment column (thermistor emulator or decade resistor box, current
meter, log capture, pack removal).

## Exercise 5: chat client

The second answer refers to the first, because the script passes previous_response_id. Input
tokens on turn 2 are higher than on turn 1: the previous turn is sent again. A long log pasted
early is paid for on every later turn.

## Exercise 6 (optional): Foundry SDK

The same chat with no key, signed in with az login. With --agent, answers follow the
ve-test-assistant instructions. Errors: DefaultAzureCredential failed (run az login in the same
terminal), 403 (Foundry User role needed), agent not found (set AGENT_NAME exactly).

## Exercise 7: structured output

- Mock run: 5 scenarios and "Coverage check: NOT covered: AC3". The mock leaves AC3 out on
  purpose.
- Real runs: usually every criterion covered; the scenario count differs between runs.
- With AC7 added, the check expects AC7 and the model usually adds a scenario for it.

The schema guarantees the shape, not the truth: code checks coverage and format, a person
checks meaning and thresholds. Remove AC7 when you are done.

## Exercise 8: tool calling

- Default question: the model asks to call get_requirement({'req_id': 'REQ-207'}); your code
  returns about 1,460 characters; the answer says REQ-207 has six criteria and picks two risky
  ones, often AC2 (four readings, 250 ms apart) and AC6 (the lock).
- REQ-999: the model calls the tool with REQ-999; your code returns "No requirement found
  with ID REQ-999."; a good answer says the requirement does not exist. Watch for a model that
  invents criteria anyway.

The model chose to call the tool; your code decided what it may read (only requirements/).

## Exercise 9: duplicates

| Pair | Shared defect | Criterion it breaks |
|------|---------------|---------------------|
| VE-BUG-801 and VE-BUG-805 | Charging never resumes until the pack is reinserted | AC5 (after one fault, 20 valid readings must resume charging) |
| VE-BUG-802 and VE-BUG-807 | One bad reading stops charging | AC2 (four in a row are needed) |
| VE-BUG-804 and VE-BUG-810 | C-118 logged twice | AC4 (exactly one line) |
| VE-BUG-806 and VE-BUG-812 | 105 °C accepted as valid | AC1 (above 100.0 °C is invalid) |

Unrelated reports stay low: 803 (Bluetooth update), 808 (UART), 811 (mobile app). 809 (amber
LED) breaks AC3 but has no duplicate. Scores depend on the model; if a pair is missing, try
--threshold 0.5. A person decides.

## Exercise 10: status screen (five planted defects)

1. The label says "Batery temperature".
2. 105.0 °C is shown with status OK (AC1: above 100.0 °C is invalid).
3. Charge current shows 500 mA during a fault stop (AC3: it must be 0 mA).
4. The fault code shows C-181, not C-118 (AC4).
5. The charge current bar runs past the edge of its panel.

Not defects: the solid red LED (AC3) and "4 invalid readings" (AC2). A model that reports either
as a defect has invented one.

## Exercise 11: Content Understanding

| Register | Address | Access | Reset value |
|----------|---------|--------|-------------|
| STATUS | 0x00 | R | 0x0000 |
| CHG_CTRL | 0x01 | R/W | 0x0003 |
| ICHG | 0x02 | R/W | 0x0064 |
| NTC_CFG | 0x03 | R/W | 0x0A3C |
| DEVICE_ID | 0x0F | R | 0x0021 |

CHG_CTRL fields: EN (bit 0, reset 1), TERM (bit 1, reset 1), TMR (bits 3:2, reset 00), reserved
15:4. Cross-checks: ICHG 0x0064 is 100 x 20 mA = 2000 mA, the charge_spec C3 current;
CHG_CTRL 0x0003 is EN and TERM set; the thermistor valid range -20 to 100 °C matches AC1 of
REQ-207; the VBUS minimum of 4.75 V matches the boot log warning. The page does not say how
NTC_CFG 0x0A3C is decoded: an answer that turns it into 10 °C and 60 °C has invented that.

## Exercise 12: privacy and access

| Situation | Decision |
|-----------|----------|
| a. New test engineer builds and runs agents | Foundry User role on the project (add Reader on the resource if they cannot see it) |
| b. Team lead adds people | Foundry Project Manager |
| c. API key in the script | No. Prefer Entra ID (az login, AUTH=entra). If a key is unavoidable: in .env, never in code, never committed, rotated regularly |
| d. Will client code train OpenAI's models? | Microsoft states prompts, completions and embeddings are not available to OpenAI or other customers and are not used to train foundation models without permission. But the client contract decides first whether the code may go in at all |

## Self-check quiz

1. c   2. b   3. b   4. c   5. a   6. d   7. b   8. c
