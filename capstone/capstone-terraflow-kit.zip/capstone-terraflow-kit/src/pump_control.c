/*
 * pump_control.c - TerraFlow motor duty from line pressure.
 * Capstone training file: it contains deliberate defects. Fictional product.
 */
#include "pump_control.h"

uint8_t duty_for_p(uint16_t p_centibar)
{
    if (p_centibar > 300u) {
        return 0u;                                   /* D1 */
    }
    if (p_centibar < 100u) {
        return 100u;                                 /* D3 */
    }
    /* D2: 30 + (3.00 - p) x 35, in hundredths; D4: whole percent */
    uint32_t hundredths = 3000u + (300u - p_centibar) * 35u;
    return (uint8_t)(hundredths / 100u);
}

void pump_control_step(void)
{
    tf_motor_set_duty(duty_for_p(tf_read_pressure_centibar()));
}
