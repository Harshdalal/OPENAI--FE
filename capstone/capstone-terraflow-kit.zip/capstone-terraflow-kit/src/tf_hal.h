/* tf_hal.h - TerraFlow hardware abstraction (training stub, fictional product). */
#ifndef TF_HAL_H
#define TF_HAL_H

#include <stdint.h>

/* Blocking I2C register access. Return 0 on success, negative on NACK or timeout.
 * Takes about 0.1 ms; up to 10 ms on a NACK with retries. */
int  i2c1_read_reg(uint8_t addr, uint8_t reg, uint8_t *buf, uint8_t len);

/* Motor PWM duty in percent, 0 to 100. */
void    motor_set_duty(uint8_t percent);
uint8_t motor_get_duty(void);

/* Duty for a pressure in hundredths of a bar (pump_spec.md rules D1 to D4). */
uint8_t duty_for_p(uint16_t p_centibar);

/* Blocking UART log line. Takes about 3 ms for a 30-character line at 115200 baud. */
void uart_log(const char *line);

#endif
