/* pump_control.h - TerraFlow motor duty from line pressure (rules D1 to D5 in pump_spec.md). */
#ifndef PUMP_CONTROL_H
#define PUMP_CONTROL_H

#include <stdint.h>

/* Pressure in hundredths of a bar (210 means 2.10 bar). Returns the motor duty in percent. */
uint8_t duty_for_p(uint16_t p_centibar);

/* One control step: read the pressure, set the motor duty. */
void pump_control_step(void);

/* Hardware boundary (implemented by the board support package, faked in tests). */
uint16_t tf_read_pressure_centibar(void);
void     tf_motor_set_duty(uint8_t percent);

#endif
