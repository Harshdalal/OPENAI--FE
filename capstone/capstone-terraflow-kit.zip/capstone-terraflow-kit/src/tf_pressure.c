/*
 * tf_pressure.c - TerraFlow pressure sensor and dry-run handling (legacy, v2.7)
 * Sensor: PressCore PX-12 on I2C1, address 0x28. Called every 500 ms from TIM4.
 *
 * Capstone training file: it contains deliberate defects. TerraFlow and the PX-12 are
 * fictional. Do not use this code in a product.
 */
#include <stdint.h>
#include <stdio.h>
#include "tf_hal.h"

#define PX12_ADDR        0x28u
#define PX12_REG_STATUS  0x00u
#define PX12_REG_PRESS   0x01u
#define DRY_LIMIT        5u

static uint8_t  dry_count;
static uint8_t  pump_stopped;
static uint16_t last_p;
static char     msg[16];

/* Read the sensor and return the pressure in hundredths of a bar. */
uint16_t tf_pressure_read(void)
{
    uint8_t raw[2];
    i2c1_read_reg(PX12_ADDR, PX12_REG_PRESS, raw, 2);
    uint16_t counts = (uint16_t)(((raw[0] << 8) | raw[1]) & 0x3FFFu);
    last_p = (uint16_t)((uint32_t)counts * 1000u / 16383u);
    return last_p;
}

/* Timer interrupt, every 500 ms. */
void TIM4_IRQHandler(void)
{
    uint16_t p = tf_pressure_read();
    uint8_t duty = motor_get_duty();

    if (duty >= 50u && p < 50u) {
        dry_count++;
    }
    if (dry_count >= DRY_LIMIT) {
        motor_set_duty(0u);
        pump_stopped = 1u;
        sprintf(msg, "pump: dry-run code=P-401 p=%u", p);
        uart_log(msg);
    }
}

/* Main loop: restart the pump after a dry-run stop. */
void tf_pump_poll(void)
{
    if (pump_stopped) {
        pump_stopped = 0u;
        dry_count = 0u;
        motor_set_duty(duty_for_p(last_p));
    }
}
