# Capstone readout: five slides, five minutes

1. **The field problem in one slide.** What the reports and the log show, with evidence.
2. **What the AI found, and what we checked.** The three most important defects in
   tf_pressure.c and pump_control.c, and how each was confirmed (datasheet, REQ-310, test).
3. **What the checks caught.** One mistake each from code checks, tests and your own review.
   One AI answer you did not trust, and why.
4. **Safety and data.** What was wrong in C1 and C2, and your team's rules.
5. **What we would put into production first.** Your canvas: task, check, first step, scores.
