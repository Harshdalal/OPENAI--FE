# Capstone team report: TerraFlow T-300

Team name: ____________________   Members and roles: ____________________________________

Copy this file, fill it in, and save your other outputs in this folder. Before you submit,
run `python verify/run_checks.py scan`: the scan must be clean for this folder.

## Task 1: model, settings and token budget (Modules 1 and 2)

- Deployment and model used, and why: 
- Deployment type you would use for the client (and why): 
- Temperature for each task below, with one reason each:
- Prompt A results at 0 and 1.0; Prompt T with and without grounding:
- Token budget: spec + requirement + log per call, and for 200 calls:

## Task 2: field report triage (Modules 2 and 3)

- Prompt or template used:
- Code check result (output of t2_triage_reports.py), and what you fixed by hand:
- Your three most important patterns across the reports, each with report IDs:

## Task 3: legacy driver review (Modules 3 and 4)

- Your final prompt (paste it, or save it as deliverables/review_prompt.md):
- Defect table (line, category, needs, concern, fix), checked line by line:
- Which defects needed the datasheet, and which REQ-310:

## Task 4: datasheet to header (Module 4)

- Check results, and every value you corrected by hand:
- Your final px12_regs.h is in deliverables/:

## Task 5: unit tests (Module 4)

- Expected values you wrote from pump_spec.md before asking the AI:
- Test results (output of `python verify/run_checks.py tests`):
- The defects the failing tests point to, and the fix you propose:

## Task 6: knowledge assistant (Module 4)

- Answers to the five questions, each with its source, or "Not in the docs":
- One answer you corrected, and why:

## Task 7: review AI output and set the rules (Module 5)

- C1: every mistake, and which check (compiler, host test, reading) found it:
- C2: every mistake, and what must change before anything is sent to customers:
- Your team's AI rules for TerraFlow (before, during, after):

## Task 8: use-case canvas and readout

- Canvas for one TerraFlow task you would put into production first, with scores:
- Readout: five slides, five minutes (see readout_outline.md)
