# Capstone resource kit: TerraFlow T-300 pump controller

OpenAI Overview and AI Awareness for Firmware Teams: capstone. Read the problem statement
document first: it has the scenario, the eight tasks, the timing, the deliverables and the
scoring rubric.

- docs/            the sources of truth: pump_spec.md, REQ-310_dry_run.md, the PX-12 datasheet
                   page (PDF and text), release notes and FAQ
- data/            the field evidence: boot log of TF-41077 and ten field reports
- src/             legacy driver tf_pressure.c and pump_control.c (deliberate defects), headers
- tests/           test_pump_control.c: plain C unit tests, no framework needed
- ai_outputs/      C1 and C2: AI output to review in Task 7 (deliberate mistakes)
- templates/       the course prompt templates and the AI Use-Case Canvas
- scripts/         t1 to t6: one script per task, every one runs offline with --mock
- verify/          run_checks.py: unit tests, compiler, sanitizers, REQ-310 host test, scanner
- deliverables/    your team report template and readout outline; save your outputs here

Setup (Python 3.10 or later; gcc or clang for the C checks):

    cd scripts
    python -m pip install -r requirements.txt
    python t1_settings.py --mock                practice run, no Azure needed
    copy .env.example .env                      macOS or Linux: cp .env.example .env
    cd ..
    python verify/run_checks.py

Fill in .env with your Foundry endpoint (ending in /openai/v1/), the key or AUTH=entra, and
your chat and embedding deployment names. Never commit .env.

TerraFlow, PressCore, every unit, customer, code and key in this kit are fictional; the key in
ai_outputs/C2 is a placeholder.
