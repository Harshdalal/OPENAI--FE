/*
 * C1: AI-generated patch (capstone training file: it contains deliberate mistakes).
 *
 * Task given to the AI (Copilot Chat, Ask mode):
 *   "Rewrite the dry-run handling in tf_pressure.c so it meets REQ-310. Keep the 500 ms
 *    timer interrupt."
 *
 * AI's note with the answer:
 *   "REQ-310 compliant: 10 readings in a row, one log line, invalid readings ignored, and a
 *    60-second restart."
 *
 * TerraFlow is fictional. Do not use this code in a product.
 */
#include <stdint.h>
#include <stdio.h>
#include "tf_hal.h"

#define DRY_LIMIT      10u
#define RESTART_TICKS  60u      /* restart delay */

static uint8_t  dry_count;
static uint8_t  stopped;
static uint16_t restart_wait;
static char     line[24];

/* p_centibar: pressure in hundredths of a bar; status: PX-12 status bits 15:14. */
void tf_dry_run_tick(uint16_t p_centibar, uint8_t status)
{
    if (stopped) {
        if (++restart_wait >= RESTART_TICKS) {
            stopped = 0u;
            restart_wait = 0u;
            motor_set_duty(duty_for_p(p_centibar));
        }
        return;
    }
    if (status == 3u || p_centibar > 1000u) {
        return;                                   /* invalid reading: ignore it */
    }
    uint8_t duty = motor_get_duty();
    if (duty >= 50u && p_centibar < 50u) {
        dry_count++;
    } else if (duty < 50u) {
        dry_count = 0u;
    }
    if (dry_count >= DRY_LIMIT) {
        motor_set_duty(0u);
        stopped = 1u;
        dry_count = 0u;
        snprintf(line, sizeof line, "pump: dry-run code=P-401 p=%u", p_centibar);
        uart_log(line);
    }
}

/* Called from TIM4_IRQHandler every 500 ms. */
void TIM4_IRQHandler(void);
