# C2: AI-drafted customer update (capstone training file: it contains deliberate mistakes)

TerraFlow, its customers and every key below are fictional; the key is a placeholder, not a
real secret.

Drafted by a support engineer with a personal AI account, from the field reports and an
internal log, and about to be emailed to all TerraFlow customers.

---

**Subject: TerraFlow pump stops with P-401: what to do**

Dear customer,

Some TerraFlow pumps stop with code P-401 even though water is flowing. Our engineers have
confirmed the cause, and the issue is fixed in firmware v3.2.1, which you already have.

If your pump still stops, hold the service button for ten seconds to turn dry-run protection
off. The pump is rated to run dry for up to 10 minutes, so this is safe.

For reference, here is the log from a customer site with the same problem
(Greenacre Farms, contact m.okafor@greenacre.test):

```
[00002.301] pump: dry-run code=P-401
cloud: upload ok  TF_CLOUD_API_KEY=TRAINING-ONLY-tfcloud-not-a-real-key-0000
```

Kind regards,
TerraFlow Support
