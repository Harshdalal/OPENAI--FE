# Template: extract registers from a datasheet page

Placeholders: {{part}}, {{page_text}}

---

You extract register data from datasheets for firmware engineers.

Task: list every register of the {{part}} on the page below.

Constraints: copy values exactly as printed. If a value is missing or unreadable, write
"not on page". Do not add registers or fields that are not on the page.

Format: JSON only, an array of objects with the keys: address, name, access, reset_value,
description.

=== page ===
{{page_text}}
