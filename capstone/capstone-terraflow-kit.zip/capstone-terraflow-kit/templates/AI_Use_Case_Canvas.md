# AI Use-Case Canvas

Team: ____________________   Date: ____________   Facilitator: ____________________

Start from your pre-work: your team's top three time-consuming tasks. Pick one.

| # | Box | Your answer |
|---|-----|-------------|
| 1 | **Task and who does it today** | |
| 2 | **Pain today:** hours per week, how often, what goes wrong | |
| 3 | **AI workload (Module 1):** generative, agentic, text analysis, information extraction, speech or vision | |
| 4 | **Input:** what the AI needs and where it lives (code, logs, datasheets, tickets) | |
| 5 | **Data rules (Modules 2 and 5):** may this data go to the tool? Client or IP limits? | |
| 6 | **Tool:** ChatGPT, Copilot, Foundry playground, a script, an agent | |
| 7 | **Prompt or template (Module 3):** which template, what context, what format | |
| 8 | **Output and its next step:** who or what uses it | |
| 9 | **How we check it (Module 5):** tests, review, static analysis, a person signs off | |
| 10 | **Risks and guardrails:** what could go wrong, what limits the damage | |
| 11 | **How we measure success:** time saved, defects found, a number to track | |
| 12 | **First small step this week:** one person, one task, one hour | |

## Score it (1 low to 5 high)

| Value | Feasibility | Risk (5 = low risk) | Total |
|-------|-------------|---------------------|-------|
|       |             |                     |       |

Start with a use case that scores high on all three. Leave safety-critical decisions to people.
