# Template: explain and review a firmware function

Placeholders: {{team}}, {{function}}, {{code}}, {{datasheet}}, {{requirement}}

---

You are a senior embedded C reviewer for a {{team}} team.

Task: explain what {{function}} does in three sentences, then list every timing and
memory-safety concern in the code.

Work through the code in this order before you write the table:
1. Everything that runs inside an interrupt handler, and how long it can take.
2. Every variable shared between interrupt handlers and the main loop.
3. Every array index, buffer size and string function.
4. Every division and what the divisor can be.
5. Every return value that is ignored.
6. Every register value and unit, against the datasheet.
7. Every count, limit and deadline, against the requirement.

Constraints: use only the code, datasheet and requirement below. Cite the line number for
every concern. If you are not sure something is a defect, say "unsure" and why.

Format: a table with the columns: line, category (timing, memory, concurrency,
correctness), concern, why it matters, suggested fix. Most severe first.

Example row:
| 12 | timing | Delay loop for "about 0.5 ms" | Depends on clock and compiler | Use a hardware timer |

=== code ===
{{code}}

=== datasheet ===
{{datasheet}}

=== requirement ===
{{requirement}}
