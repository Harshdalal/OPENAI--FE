# Template: test ideas from a requirement

Placeholders: {{requirement}}

---

You are a firmware test engineer. Write test scenarios for the requirement below.

Constraints: use only the requirement. Add a boundary scenario for every number. Put
anything the requirement does not say under "Questions for the firmware lead". Do not
invent register names, bus messages or log lines.

Format: a table with the columns: ID, title, type (positive, negative, boundary,
fault-injection), acceptance criterion covered, expected result (one checkable sentence).

=== requirement ===
{{requirement}}
