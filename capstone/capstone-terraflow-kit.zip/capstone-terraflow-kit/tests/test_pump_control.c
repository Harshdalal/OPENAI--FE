/*
 * test_pump_control.c - plain C unit tests for pump_control.c, no framework needed.
 * Build and run from the kit folder:
 *   gcc -Wall -Isrc src/pump_control.c tests/test_pump_control.c -o test_pump && ./test_pump
 * (Windows without gcc: cl /Isrc src\pump_control.c tests\test_pump_control.c)
 *
 * Task 5: add tests here. Take every expected value from docs/pump_spec.md.
 */
#include <stdio.h>
#include <stdint.h>
#include "pump_control.h"

/* ---- Fakes for the hardware boundary (link seam: the tests provide these functions) ---- */
static uint16_t fake_p = 0;
static int      fake_set_calls = 0;
static uint8_t  fake_last_duty = 255;
uint16_t tf_read_pressure_centibar(void) { return fake_p; }
void tf_motor_set_duty(uint8_t percent) { fake_set_calls++; fake_last_duty = percent; }

static int failures = 0, checks = 0;
#define CHECK_EQ(actual, expected, name) do { int a_ = (int)(actual), e_ = (int)(expected); checks++; \
    if (a_ != e_) { failures++; printf("FAIL  %-40s got %d, expected %d\n", name, a_, e_); } \
    else { printf("ok    %s\n", name); } } while (0)

int main(void)
{
    /* One example test, written by a person. Add the rest from pump_spec.md. */
    CHECK_EQ(duty_for_p(80), 100, "0.80 bar is below 1.00: full duty (D3)");

    printf("\n%d of %d checks failed\n", failures, checks);
    return failures ? 1 : 0;
}
