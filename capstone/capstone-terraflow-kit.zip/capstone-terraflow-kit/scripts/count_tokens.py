"""count_tokens.py - count the tokens in the exercise files, and what repeated calls cost.

Usage (from the scripts folder):
    python count_tokens.py                      # the spec, the requirement, the log and the reports
    python count_tokens.py ../data/boot_log_TF-41077.txt --calls 200

Uses the o200k_base tokenizer (recent OpenAI models) when the tiktoken package is installed
and can download its tokenizer file once. Otherwise it falls back to a rough estimate
(within about 10% on these files) that splits words, digit groups and symbols the way the
tokenizer does, and says so.
"""
import argparse
import math
import re
from pathlib import Path

KIT = Path(__file__).resolve().parent.parent
DEFAULT = [KIT / "docs" / "pump_spec.md", KIT / "docs" / "REQ-310_dry_run.md", KIT / "data" / "boot_log_TF-41077.txt", KIT / "data" / "field_reports.txt"]


def counter():
    try:
        import tiktoken
        enc = tiktoken.get_encoding("o200k_base")
        return (lambda t: len(enc.encode(t))), "o200k_base (exact)"
    except Exception:
        return estimate, "estimate (install tiktoken and allow its one-time download for exact counts)"


def estimate(text):
    """Rough token count: words in pieces of up to 8 letters, digits in groups of up to 3,
    and each symbol on its own. Close to o200k_base on short English and firmware logs."""
    n = 0
    for piece in re.findall(r" ?[A-Za-z]+|\d{1,3}|[^\sA-Za-z\d]|\n", text):
        word = piece.strip()
        n += math.ceil(len(word) / 8) if word.isalpha() else 1
    return max(1, n)


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("files", nargs="*", type=Path, default=DEFAULT)
    ap.add_argument("--calls", type=int, default=40, help="how many calls send the file each time (default 40)")
    args = ap.parse_args()
    count, how = counter()
    print(f"Tokenizer: {how}\n")
    print(f"{'file':<26}{'chars':>7}{'tokens':>8}{'chars/token':>13}{'tokens x ' + str(args.calls) + ' calls':>20}")
    for f in args.files:
        text = f.read_text(encoding="utf-8")
        n = count(text)
        print(f"{f.name:<26}{len(text):>7}{n:>8}{len(text) / n:>13.2f}{n * args.calls:>20,}")
    print("\nThe system message is sent again on every call: its tokens count on every call, and they")
    print("take part of the context window every time. Fewer characters per token means more tokens")
    print("for the same text: hex values, timestamps and IDs split into small pieces.")


if __name__ == "__main__":
    main()
