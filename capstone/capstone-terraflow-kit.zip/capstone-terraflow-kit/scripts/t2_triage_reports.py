"""Task 2: triage the field reports as structured output, then check them in code (Modules 2 and 3).

    python t2_triage_reports.py --mock
    python t2_triage_reports.py

The schema forces one object per report with a category from a fixed list, the REQ-310
criterion it relates to, and an evidence quote. Code then checks what code can check: every
report is present exactly once, and every evidence quote appears word for word in its report.
Writes output/triage.json and output/triage.csv.
"""
import csv
import json

from common import KIT, MOCK, chat, get_client, read

CATEGORIES = ["false dry-run stop", "real dry run", "sensor fault", "stale or wrong pressure reading",
              "pump locked", "connectivity", "positive", "other"]
SCHEMA = {
    "type": "object", "additionalProperties": False, "required": ["reports"],
    "properties": {"reports": {"type": "array", "items": {
        "type": "object", "additionalProperties": False,
        "required": ["id", "unit", "category", "related_criterion", "evidence"],
        "properties": {
            "id": {"type": "string"}, "unit": {"type": "string"},
            "category": {"type": "string", "enum": CATEGORIES},
            "related_criterion": {"type": "string", "description": "AC1 to AC6 of REQ-310, or none"},
            "evidence": {"type": "string", "description": "A short quote copied word for word from the report"}}}}},
}
INSTRUCTIONS = ("You triage field reports for the TerraFlow pump firmware team. Use only the reports and REQ-310 "
                "given. For each report choose one category, the REQ-310 acceptance criterion it relates to (or none), "
                "and copy a short evidence quote word for word from that report.")

MOCK_DATA = {"reports": [
    {"id": "R01", "unit": "TF-41077", "category": "false dry-run stop", "related_criterion": "AC2", "evidence": "The tank is full."},
    {"id": "R02", "unit": "TF-41102", "category": "positive", "related_criterion": "none", "evidence": "the field is evenly watered"},
    {"id": "R03", "unit": "TF-41077", "category": "false dry-run stop", "related_criterion": "AC4", "evidence": "Restarts by itself after a few seconds"},
    {"id": "R04", "unit": "TF-40988", "category": "connectivity", "related_criterion": "none", "evidence": "LoRa never joins"},
    {"id": "R05", "unit": "TF-41130", "category": "false dry-run stop", "related_criterion": "AC2", "evidence": "the pressure dips for a few seconds"},
    {"id": "R06", "unit": "TF-41102", "category": "sensor fault", "related_criterion": "AC3", "evidence": "display says P-402"},
    {"id": "R07", "unit": "TF-41155", "category": "stale or wrong pressure reading", "related_criterion": "AC1", "evidence": "pressure stuck at 1.12 bar"},
    {"id": "R08", "unit": "TF-41077", "category": "pump locked", "related_criterion": "AC5", "evidence": "Pump locked with P-403 after the third stop"},
    {"id": "R09", "unit": "TF-40871", "category": "positive", "related_criterion": "none", "evidence": "Quiet and efficient."},
]}


def main():
    reports = {}
    for line in read("data/field_reports.txt").splitlines():
        if line.count("|") >= 3:
            rid, unit, date, text = [x.strip() for x in line.split("|", 3)]
            reports[rid] = text
    client = get_client()
    if MOCK:
        data = MOCK_DATA
    else:
        text, _ = chat(client, INSTRUCTIONS, "REQ-310:\n" + read("docs/REQ-310_dry_run.md") + "\n\nReports:\n" + read("data/field_reports.txt"),
                       temperature=0, schema=SCHEMA, name="triage")
        data = json.loads(text)

    rows = data["reports"]
    print(f"{len(rows)} reports triaged:")
    for r in rows:
        print(f"  {r['id']:<4} {r['unit']:<9} {r['category']:<32} {r['related_criterion']:<5} \"{r['evidence']}\"")
    problems = []
    seen = [r["id"] for r in rows]
    for rid in reports:
        if seen.count(rid) != 1:
            problems.append(f"{rid} appears {seen.count(rid)} times (expected once)")
    for r in rows:
        if r["id"] in reports and r["evidence"] not in reports[r["id"]]:
            problems.append(f"{r['id']}: evidence \"{r['evidence']}\" is not word for word in the report")
    print("\nCode checks: " + ("all passed." if not problems else "PROBLEMS FOUND"))
    for p in problems:
        print("  - " + p)
    out = KIT / "output"
    out.mkdir(exist_ok=True)
    (out / "triage.json").write_text(json.dumps(data, indent=2), encoding="utf-8")
    with (out / "triage.csv").open("w", newline="", encoding="utf-8") as f:
        w = csv.writer(f)
        w.writerow(["id", "unit", "category", "related_criterion", "evidence"])
        for r in rows:
            w.writerow([r["id"], r["unit"], r["category"], r["related_criterion"], r["evidence"]])
    print("\nSaved output/triage.json and output/triage.csv. Code checks shape and quotes; a person checks the categories.")


if __name__ == "__main__":
    main()
