"""Task 6: a tiny knowledge assistant (RAG) over the TerraFlow docs.

    python t6_rag_ask.py --mock                         practice run, keyword search, no Azure needed
    python t6_rag_ask.py                             real run: embeddings + chat, reads .env
    python t6_rag_ask.py --question "How do I clear a locked pump?"

1. Split every Markdown file in docs/ into sections (one per heading).
2. Find the sections closest to the question (embeddings, or keywords in mock mode).
3. Send only those sections to the model, with the rule: answer only from them, cite them,
   or say "Not in the docs".
"""
import argparse
import math
import os
import re

from common import KIT, MOCK, get_client

QUESTIONS = [
    "What motor duty does the pump get at 2.10 bar?",
    "What is the reset value of the PX-12 CONFIG register?",
    "Is P-401 while water is flowing a known issue, and when is it fixed?",
    "Which LoRa message reports a locked pump?",
    "What is the maximum flow rate of the pump in litres per minute?",
]
INSTRUCTIONS = ("You answer questions about TerraFlow pump firmware for engineers. Use only the numbered sources given. "
                "Cite the source number for every fact, like [2]. If the sources do not contain the answer, reply exactly: "
                "Not in the docs.")


def sections():
    out = []
    for path in sorted((KIT / "docs").glob("*.md")):
        title, buf = path.stem, []
        for line in path.read_text(encoding="utf-8").splitlines():
            if line.startswith("## ") and buf:
                out.append((f"{path.name} > {title}", "\n".join(buf).strip()))
                buf = []
            if line.startswith("#"):
                title = line.lstrip("# ").strip()
            buf.append(line)
        if buf:
            out.append((f"{path.name} > {title}", "\n".join(buf).strip()))
    return out


def words(t):
    stop = {"the", "a", "an", "of", "is", "and", "to", "in", "what", "which", "does", "do", "how", "for", "it", "at", "get", "when", "i"}
    return [w for w in re.findall(r"[a-z0-9]+(?:-[0-9]+)?", t.lower()) if w not in stop]


def keyword_scores(question, chunks):
    """Mock retrieval: share of question words in the section, plus a small bonus for each
    number in the question that the section also contains."""
    q = set(words(question))
    nums = set(re.findall(r"\d+(?:\.\d+)?", question))
    return [len(q & set(words(text))) / (len(q) or 1) + 0.05 * sum(n in text for n in nums) for _, text in chunks]


def cosine(a, b):
    return sum(x * y for x, y in zip(a, b)) / ((math.sqrt(sum(x * x for x in a)) * math.sqrt(sum(y * y for y in b))) or 1.0)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--question", action="append")
    ap.add_argument("--top", type=int, default=3)
    ap.add_argument("--mock", action="store_true")
    args = ap.parse_args()
    questions = args.question or QUESTIONS

    chunks = sections()
    client = get_client()
    print(f"{len(chunks)} sections from {len(set(c[0].split(' > ')[0] for c in chunks))} documents.\n")
    vectors = None
    if not MOCK:
        model = os.environ.get("EMBEDDING_DEPLOYMENT") or exit("Set EMBEDDING_DEPLOYMENT in scripts/.env.")
        vectors = [d.embedding for d in client.embeddings.create(model=model, input=[t for _, t in chunks]).data]

    for q in questions:
        if MOCK:
            scores = keyword_scores(q, chunks)
        else:
            qv = client.embeddings.create(model=os.environ["EMBEDDING_DEPLOYMENT"], input=[q]).data[0].embedding
            scores = [cosine(qv, v) for v in vectors]
        ranked = sorted(range(len(chunks)), key=lambda i: scores[i], reverse=True)[: args.top]
        sources = "\n\n".join(f"[{n}] {chunks[i][0]}\n{chunks[i][1]}" for n, i in enumerate(ranked, 1))
        print(f"Q: {q}")
        for n, i in enumerate(ranked, 1):
            print(f"   [{n}] {chunks[i][0]}  (score {scores[i]:.2f})")
        if MOCK:
            best = ranked[0]
            if scores[best] < 0.6:
                answer = "Not in the docs."
            else:
                body = [l.strip(" -|") for l in chunks[best][1].splitlines() if l.strip() and not l.startswith("#")]
                qw = set(words(q))
                body = [l for l in body if not ("|" in l and not re.search(r"\d", l))] or body  # skip table headers
                line = max(body, key=lambda l: len(qw & set(words(l))))
                answer = "[MOCK] " + line[:240] + " [1]"
        else:
            r = client.responses.create(model=os.environ["MODEL_DEPLOYMENT"], instructions=INSTRUCTIONS,
                                        input=f"Sources:\n{sources}\n\nQuestion: {q}")
            answer = r.output_text.strip()
        print(f"A: {answer}\n")
    print("Check each cited source. Retrieval can pick the wrong section, and the model can still misread the right one.")


if __name__ == "__main__":
    main()
