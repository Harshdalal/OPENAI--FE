"""Task 4: extract the PX-12 register map as structured output, check it in code, write a C header.

    python extract_registers.py --mock      practice run, no Azure needed
    python extract_registers.py             real run, reads .env (same as Module 2)

Reads docs/PX12_registers.md (the text of the datasheet page), asks the model for JSON that
matches a strict schema, runs checks a script can do, and writes output/px12_regs.h.
The checks catch some errors, not all: a person still compares every value with the PDF.
"""
import json
import os
import re

from common import KIT, MOCK, get_client, read

SCHEMA = {
    "type": "object", "additionalProperties": False, "required": ["part", "registers", "config_fields", "counts_0_bar", "counts_10_bar"],
    "properties": {
        "part": {"type": "string"},
        "registers": {"type": "array", "items": {
            "type": "object", "additionalProperties": False,
            "required": ["address", "name", "access", "reset_value", "description"],
            "properties": {"address": {"type": "string"}, "name": {"type": "string"}, "access": {"type": "string", "enum": ["R", "W", "R/W"]},
                           "reset_value": {"type": "string"}, "description": {"type": "string"}}}},
        "counts_0_bar": {"type": "integer"}, "counts_10_bar": {"type": "integer"},
        "config_fields": {"type": "array", "items": {
            "type": "object", "additionalProperties": False, "required": ["bits", "field", "reset"],
            "properties": {"bits": {"type": "string"}, "field": {"type": "string"}, "reset": {"type": "string"}}}},
    },
}
INSTRUCTIONS = ("You extract register data from datasheets for firmware engineers. Copy values exactly as printed. "
                "Use hex strings such as 0x0041 for addresses and reset values, and binary strings such as 01 for field resets. "
                "config_fields are the fields of the CONFIG register; counts_0_bar and counts_10_bar come from the transfer function. "
                "Do not add registers or fields that are not on the page.")

MOCK_DATA = {"part": "PX-12", "counts_0_bar": 0, "counts_10_bar": 16383, "registers": [
    {"address": "0x00", "name": "STATUS", "access": "R", "reset_value": "0x0000", "description": "Status bits 15:14"},
    {"address": "0x01", "name": "PRESSURE", "access": "R", "reset_value": "0x0000", "description": "14-bit pressure output"},
    {"address": "0x02", "name": "CONFIG", "access": "R/W", "reset_value": "0x0040", "description": "Output data rate, filter, enable"},
    {"address": "0x0F", "name": "DEVICE_ID", "access": "R", "reset_value": "0x00A7", "description": "Device identifier"}],
    "config_fields": [{"bits": "15:8", "field": "-", "reset": "0"}, {"bits": "7:6", "field": "ODR", "reset": "01"},
                      {"bits": "5:4", "field": "FILT", "reset": "00"}, {"bits": "3:1", "field": "-", "reset": "0"},
                      {"bits": "0", "field": "EN", "reset": "1"}]}


def checks(data):
    """Checks code can do. Each returns a message; an empty list means all passed."""
    problems = []
    regs = data["registers"]
    addrs = [r["address"].lower() for r in regs]
    if len(set(addrs)) != len(addrs):
        problems.append("Two registers share an address.")
    for r in regs:
        for key in ("address", "reset_value"):
            if not re.fullmatch(r"0x[0-9a-fA-F]{1,4}", r[key]):
                problems.append(f"{r['name']}: {key} '{r[key]}' is not a hex value.")
    # Compose CONFIG's reset value from its field resets and compare
    cfg = next((r for r in regs if r["name"].upper() == "CONFIG"), None)
    if cfg:
        value = 0
        for f in data["config_fields"]:
            hi, _, lo = f["bits"].partition(":")
            lo = lo or hi
            width = int(hi) - int(lo) + 1
            bits = f["reset"] if set(f["reset"]) <= {"0", "1"} else "0"
            value |= (int(bits, 2) & ((1 << width) - 1)) << int(lo)
        if int(cfg["reset_value"], 16) != value:
            problems.append(f"CONFIG reset value {cfg['reset_value']} does not match its field resets (0x{value:04X}).")
    # Transfer function: both end points inside the 14-bit range, and the stated 10% to 90% band
    lo, hi = data["counts_0_bar"], data["counts_10_bar"]
    if not (0 <= lo < hi <= 16383):
        problems.append(f"Transfer function counts {lo} to {hi} are not an increasing range inside 14 bits.")
    elif abs(lo - 0.10 * 16383) > 2 or abs(hi - 0.90 * 16383) > 2:
        problems.append(f"Transfer function counts {lo} to {hi} are not the 10% to 90% band the page describes (about 1638 to 14745).")
    return problems


def header(data):
    lines = [f"/* {data['part'].lower().replace('-', '')}_regs.h - generated from the datasheet page by extract_registers.py.",
             " * Review every value against the PDF before use. */", "#ifndef PX12_REGS_H", "#define PX12_REGS_H", ""]
    for r in data["registers"]:
        n = re.sub(r"[^A-Z0-9_]", "_", r["name"].upper())
        lines.append(f"#define PX12_REG_{n:<10} {r['address']}u   /* {r['access']}, reset {r['reset_value']} */")
    lines += ["", f"#define PX12_COUNTS_0_BAR    {data['counts_0_bar']}u", f"#define PX12_COUNTS_10_BAR   {data['counts_10_bar']}u", "", "#endif", ""]
    return "\n".join(lines)


def main():
    page = read("docs/PX12_registers.md")
    client = get_client()
    if MOCK:
        data = MOCK_DATA
    else:
        r = client.responses.create(model=os.environ["MODEL_DEPLOYMENT"], instructions=INSTRUCTIONS, input=page,
                                    text={"format": {"type": "json_schema", "name": "register_map", "schema": SCHEMA, "strict": True}})
        data = json.loads(r.output_text)
    print(f"{len(data['registers'])} registers extracted for {data['part']}:")
    for r in data["registers"]:
        print(f"  {r['address']:<6} {r['name']:<10} {r['access']:<4} reset {r['reset_value']}")
    problems = checks(data)
    print("\nCode checks: " + ("all passed." if not problems else "PROBLEMS FOUND"))
    for p in problems:
        print("  - " + p)
    out = KIT / "output"
    out.mkdir(exist_ok=True)
    (out / "px12_regs.json").write_text(json.dumps(data, indent=2), encoding="utf-8")
    (out / "px12_regs.h").write_text(header(data), encoding="utf-8")
    print("\nSaved output/px12_regs.json and output/px12_regs.h")
    print("Code checks catch some errors, not all. Compare every value with docs/PX12_datasheet_p5.pdf.")


if __name__ == "__main__":
    main()
