"""Task 3: review the legacy driver with a strong prompt and JSON output, then check every finding (Modules 3 and 4).

    python t3_review_driver.py --mock
    python t3_review_driver.py
    python t3_review_driver.py --prompt my_prompt.md      use your team's own prompt text

The answer must be JSON with one object per finding, including the line number and a quote of
that line. Code checks that the line exists and that the quote really appears on it, so a
finding with an invented or shifted line is caught. Code cannot check whether a finding is a
real defect: your team does that against the datasheet and REQ-310.
Writes output/review.json.
"""
import argparse
import json

from common import KIT, MOCK, chat, get_client, read

SCHEMA = {
    "type": "object", "additionalProperties": False, "required": ["summary", "findings"],
    "properties": {
        "summary": {"type": "string"},
        "findings": {"type": "array", "items": {
            "type": "object", "additionalProperties": False,
            "required": ["line", "quote", "category", "needs", "concern", "fix"],
            "properties": {
                "line": {"type": "integer"}, "quote": {"type": "string"},
                "category": {"type": "string", "enum": ["timing", "memory", "concurrency", "correctness"]},
                "needs": {"type": "string", "enum": ["code", "datasheet", "requirement"]},
                "concern": {"type": "string"}, "fix": {"type": "string"}}}}},
}
DEFAULT_PROMPT = """You are a senior embedded C reviewer for an irrigation pump controller team.
Task: summarise what TIM4_IRQHandler() does in two sentences, then list every timing, memory,
concurrency and correctness concern in the file.
Work through the file in this order: what runs in the interrupt and how long it takes; shared
variables; buffers and string functions; ignored return values; register values, status bits and
the transfer function against the datasheet; every count, limit and deadline against REQ-310.
Constraints: use only the material below. For every finding give the line number and quote that
line exactly. If you are not sure something is a defect, leave it out."""

MOCK_DATA = {"summary": "[MOCK] Every 500 ms the interrupt reads the pressure, counts low readings while the motor runs, and stops the pump with P-401.",
             "findings": [
    {"line": 28, "quote": "last_p = (uint16_t)((uint32_t)counts * 1000u / 16383u);", "category": "correctness", "needs": "datasheet",
     "concern": "Transfer function ignores the 1638-count offset and 13107-count span", "fix": "(counts - 1638) * 1000 / 13107, after a range check"},
    {"line": 26, "quote": "i2c1_read_reg(PX12_ADDR, PX12_REG_PRESS, raw, 2);", "category": "correctness", "needs": "requirement",
     "concern": "Return value ignored and status bits never read: NACK and stale data are used as valid (AC1)", "fix": "Check the return value and STATUS bits 15:14"},
    {"line": 15, "quote": "#define DRY_LIMIT        5u", "category": "correctness", "needs": "requirement",
     "concern": "Stops after 5 readings (2.5 s); AC2 says 10 readings in a row", "fix": "10, and reset the count on a normal reading"},
    {"line": 44, "quote": "sprintf(msg, \"pump: dry-run code=P-401 p=%u\", p);", "category": "memory", "needs": "code",
     "concern": "Writes about 29 bytes into msg[16]", "fix": "snprintf into a large enough buffer, or a fixed string"},
    {"line": 40, "quote": "uart_log(msg);", "category": "timing", "needs": "code",
     "concern": "Blocking UART write inside the interrupt", "fix": "Set a flag; log from the main loop"},
]}


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--prompt", help="file with your own prompt text")
    ap.add_argument("--mock", action="store_true")
    args = ap.parse_args()
    code = read("src/tf_pressure.c")
    lines = code.splitlines()
    numbered = "\n".join(f"{i:>3}  {l}" for i, l in enumerate(lines, 1))
    prompt = (KIT / args.prompt).read_text(encoding="utf-8") if args.prompt else DEFAULT_PROMPT
    material = (f"=== src/tf_pressure.c (line numbers added) ===\n{numbered}\n\n=== src/tf_hal.h ===\n{read('src/tf_hal.h')}"
                f"\n\n=== docs/PX12_registers.md ===\n{read('docs/PX12_registers.md')}\n\n=== docs/REQ-310_dry_run.md ===\n{read('docs/REQ-310_dry_run.md')}")
    client = get_client()
    if MOCK:
        data, tin = MOCK_DATA, len(prompt + material) // 4
    else:
        text, tin = chat(client, prompt, material, temperature=0, schema=SCHEMA, name="review")
        data = json.loads(text)

    print(data["summary"], "\n")
    ok, bad = 0, []
    for f in data["findings"]:
        n = f["line"]
        real = 1 <= n <= len(lines) and " ".join(f["quote"].split()) in " ".join(lines[n - 1].split())
        mark = "line ok " if real else "CHECK   "
        ok += real
        if not real:
            bad.append(f)
        print(f"  {mark} {n:>3}  {f['category']:<12} {f['needs']:<12} {f['concern']}")
    by_needs = {k: sum(1 for f in data['findings'] if f['needs'] == k) for k in ("code", "datasheet", "requirement")}
    print(f"\n{len(data['findings'])} findings; {ok} quote their line correctly. Needs: " + ", ".join(f"{k} {v}" for k, v in by_needs.items()))
    for f in bad:
        actual = lines[f["line"] - 1].strip() if 1 <= f["line"] <= len(lines) else "(no such line)"
        print(f"  Line {f['line']} actually reads: {actual}")
    out = KIT / "output"
    out.mkdir(exist_ok=True)
    (out / "review.json").write_text(json.dumps(data, indent=2), encoding="utf-8")
    print(f"\nSaved output/review.json   [input tokens {tin}]. Code checks line and quote; your team checks each finding.")


if __name__ == "__main__":
    main()
