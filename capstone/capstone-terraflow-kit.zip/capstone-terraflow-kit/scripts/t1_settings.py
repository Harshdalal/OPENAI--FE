"""Task 1: same questions, different settings, with and without grounding (Module 1).

    python t1_settings.py --mock          practice run, no Azure needed
    python t1_settings.py                 real run, reads .env
    python t1_settings.py --runs 5

Prompt A has one right answer (62, pump_spec.md example 3). Prompt T asks for something the
spec does not contain. Each prompt runs at temperature 0 and 1.0, then T runs again grounded.
"""
import argparse
import random
import re

from common import KIT, MOCK, chat, get_client, read

ROLE = "You are a firmware test assistant for the TerraFlow pump team. Use this specification:\n\n"
GROUND = "\n\nAnswer only from the specification. If the specification does not say, reply exactly: Not in the spec."
PROMPTS = {
    "A": "What motor duty does the pump get at 2.10 bar? Reply with the percentage only.",
    "T": "Which LoRa message reports a dry-run stop, and which register sets the motor duty?",
}


def mock_answer(pid, temp, grounded, rng):
    if pid == "A":
        return rng.choice(["61", "61.5%", "62"]) if temp >= 1.0 and rng.random() < 0.4 else "62"
    if grounded:
        return "Not in the spec."
    return rng.choice(["LoRa uplink 0x31 on port 7; duty is set in TIM2->CCR1.",
                       "The PUMP_STATUS LoRa frame; register MOTOR_DUTY (0x40001004)."]) if temp >= 1.0 else \
        "LoRa uplink 0x31 on port 7; duty is set in TIM2->CCR1."


def check(pid, text):
    if pid == "A":
        nums = [float(n) for n in re.findall(r"\d+(?:\.\d+)?", text) if n not in ("2.10",)]
        return "correct" if nums and nums[0] == 62 else "WRONG"
    return "not in spec" if "not in the spec" in text.lower() else "INVENTED"


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--runs", type=int, default=3)
    ap.add_argument("--mock", action="store_true")
    args = ap.parse_args()
    client = get_client()
    spec = read("docs/pump_spec.md")
    rng = random.Random(3)
    print(f"{'prompt':<8}{'temp':<6}{'grounded':<10}{'run':<5}{'result':<13}answer")
    for pid, grounded_list in (("A", [False]), ("T", [False, True])):
        for grounded in grounded_list:
            for temp in (0.0, 1.0):
                for run in range(1, args.runs + 1):
                    if MOCK:
                        text = mock_answer(pid, temp, grounded, rng)
                    else:
                        text, _ = chat(client, ROLE + spec + (GROUND if grounded else ""), PROMPTS[pid], temperature=temp)
                    print(f"{pid:<8}{temp:<6}{str(grounded):<10}{run:<5}{check(pid, text):<13}{text.strip()[:70]}")
    print("\nRecord which settings you will use for Tasks 2 to 6, and why, in your team report.")


if __name__ == "__main__":
    main()
