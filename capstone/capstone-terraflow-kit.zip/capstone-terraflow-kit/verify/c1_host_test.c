/*
 * c1_host_test.c - runs the C1 dry-run patch on a PC with fake hardware, against REQ-310.
 *   gcc -g -fsanitize=address,undefined -Isrc ai_outputs/C1_dry_run_patch.c verify/c1_host_test.c -o c1_test
 * (verify/run_checks.py does this for you.)
 */
#include <stdio.h>
#include <string.h>
#include "tf_hal.h"

void tf_dry_run_tick(uint16_t p_centibar, uint8_t status);

static uint8_t fake_duty = 100u;
static int     p401_lines, uart_calls, set_calls, uart_total;
static char    last_line[64];

void    motor_set_duty(uint8_t percent) { fake_duty = percent; set_calls++; }
uint8_t motor_get_duty(void) { return fake_duty; }
uint8_t duty_for_p(uint16_t p) { (void)p; return 62u; }
void    uart_log(const char *line) { uart_calls++; uart_total++; strncpy(last_line, line, sizeof last_line - 1); if (strstr(line, "P-40")) p401_lines++; }
int     i2c1_read_reg(uint8_t a, uint8_t r, uint8_t *b, uint8_t l) { (void)a; (void)r; (void)b; (void)l; return 0; }

static void ticks(uint16_t p, uint8_t status, int n) { for (int i = 0; i < n; i++) tf_dry_run_tick(p, status); }

/* Start each test from a clean state: wait out any stop, then one low-duty normal reading. */
static void reset_state(void)
{
    for (int i = 0; i < 500 && fake_duty == 0u; i++) tf_dry_run_tick(150, 0);
    fake_duty = 30u; tf_dry_run_tick(150, 0);
    fake_duty = 100u;
}

int main(void)
{
    int fails = 0;
    setvbuf(stdout, NULL, _IONBF, 0);

    printf("Test 1: REQ-310 AC2, 9 low readings, 1 normal, 9 low: no stop (not 10 in a row)\n");
    reset_state(); ticks(20, 0, 9); ticks(150, 0, 1); ticks(20, 0, 9);
    if (fake_duty == 0u) { printf("  FAILED: stopped although the low readings were not 10 in a row\n"); fails++; } else printf("  passed\n");

    printf("Test 2: REQ-310 AC1, 10 low readings with status 10 (stale data) do not count\n");
    reset_state(); ticks(20, 2, 10);
    if (fake_duty == 0u) { printf("  FAILED: stale readings counted towards a dry-run stop\n"); fails++; } else printf("  passed\n");

    printf("Test 3: REQ-310 AC2, a real dry run logs exactly \"pump: dry-run code=P-401\"\n");
    reset_state(); p401_lines = 0; uart_calls = 0; last_line[0] = '\0';
    ticks(20, 0, 10);
    if (fake_duty != 0u) { printf("  FAILED: no stop after 10 low readings in a row\n"); fails++; }
    else if (p401_lines > 1 || (p401_lines == 1 && strcmp(last_line, "pump: dry-run code=P-401") != 0)) {
        printf("  FAILED: log line was \"%s\" (%d line(s))\n", last_line, p401_lines); fails++;
    } else printf("  passed (a correct design may log from the main loop instead)\n");

    printf("Test 4: REQ-310 AC4, restart after 60 s = 120 ticks of 500 ms\n");
    int n = 0;
    while (fake_duty == 0u && n < 500) { tf_dry_run_tick(150, 0); n++; }
    if (n != 120) { printf("  FAILED: restarted after %d ticks (%.1f s)\n", n, n * 0.5); fails++; } else printf("  passed\n");

    printf("Blocking UART lines written from the timer interrupt: %d (should be 0: log from the main loop)\n", uart_total);
    if (uart_total) fails++;
    printf("%d check(s) failed\n", fails);
    return fails ? 1 : 0;
}
