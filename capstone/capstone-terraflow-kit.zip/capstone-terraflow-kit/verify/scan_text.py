"""scan_text.py - scan text before it goes into a prompt, or before an AI answer is shared.

Usage (from the kit folder):
    python verify/scan_text.py ai_outputs/A6_chat_export.md docs/NT48_appnote_AN-07.md
    python verify/scan_text.py --all            # every file in ai_outputs/ and docs/

Looks for three kinds of risk:
  SECRET     keys, tokens, passwords, private keys, .env lines
  DATA       customer or client markers: confidential notices, customer tables
  INJECTION  text that tries to instruct an AI: hidden comments, "ignore previous", etc.

A pattern scanner is a guardrail, not a guarantee: it finds the obvious cases quickly, and a
clean result does not prove the text is safe. Exit code 1 when anything is found, so it can
run as a pre-commit hook or before an agent reads a file.
"""
import glob
import re
import sys

RULES = [
    ("SECRET", r"\b(sk-[A-Za-z0-9-]{16,})", "API key"),
    ("SECRET", r"^\s*[A-Z0-9_]*(API_KEY|SECRET|TOKEN|PASSWORD|SIGNING_KEY|PRIVATE_KEY)[A-Z0-9_]*\s*=\s*\S+", "secret in an env-style line"),
    ("SECRET", r"(?<!^)\b[A-Z0-9_]*(API_KEY|SECRET|TOKEN|SIGNING_KEY)[A-Z0-9_]*\s*=\s*\S+", "secret inside a line"),
    ("SECRET", r"-----BEGIN [A-Z ]*PRIVATE KEY-----", "private key block"),
    ("SECRET", r"AccountKey=|SharedAccessSignature=|\bsig=[A-Za-z0-9%]{20,}", "connection string or SAS token"),
    ("DATA", r"\bCONFIDENTIAL\b|do not distribute", "confidential marker"),
    ("DATA", r"^\|\s*Unit\s*\|\s*Customer\s*\|", "customer table"),
    ("DATA", r"[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.(?!example\b)[a-z]{2,}", "email address"),
    ("INJECTION", r"<!--[\s\S]*?-->", "hidden HTML comment"),
    ("INJECTION", r"(?i)ignore (all |any )?(previous|prior|above) instructions", "instruction override"),
    ("INJECTION", r"(?i)note to (ai|the ai|assistants?|ai assistants?|llms?)", "text addressed to an AI"),
    ("INJECTION", r"(?i)do not (mention|reveal|tell) (this|the user)", "asks the AI to hide something"),
]


def scan(path):
    text = open(path, encoding="utf-8", errors="replace").read()
    hits = []
    for kind, pattern, label in RULES:
        for m in re.finditer(pattern, text, re.M):
            line = text.count("\n", 0, m.start()) + 1
            snippet = " ".join(m.group(0).split())
            if kind == "SECRET":
                snippet = snippet[:12] + "..."          # never print a whole secret
            hits.append((line, kind, label, snippet[:70]))
    return sorted(hits)


def main():
    args = sys.argv[1:]
    if not args:
        print(__doc__)
        return 2
    if args == ["--all"]:
        args = sorted(glob.glob("ai_outputs/*") + glob.glob("docs/*.md") + glob.glob("docs/*.txt"))
    total = 0
    for path in args:
        hits = scan(path)
        total += len(hits)
        print(f"{path}: {'clean' if not hits else str(len(hits)) + ' finding(s)'}")
        for line, kind, label, snippet in hits:
            print(f"  line {line:3d}  {kind:9s}  {label}: {snippet}")
    print(f"{total} finding(s) in {len(args)} file(s)")
    return 1 if total else 0


if __name__ == "__main__":
    sys.exit(main())
