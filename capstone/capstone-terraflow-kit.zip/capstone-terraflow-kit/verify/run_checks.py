"""run_checks.py - the capstone's independent checks, in one go (Modules 4 and 5).

Usage (from the kit folder):
    python verify/run_checks.py              # everything
    python verify/run_checks.py tests        # Task 5: your unit tests against pump_control.c
    python verify/run_checks.py c1           # Task 7: the C1 patch (compiler, sanitizers, REQ-310 host test)
    python verify/run_checks.py scan         # Task 7: scan ai_outputs/ and deliverables/ for secrets and injection

Needs Python 3.10 or later, and gcc or clang for the C checks (Linux, macOS, WSL or MSYS2).
Nothing here calls a model.
"""
import os
import re
import shutil
import subprocess
import sys
import tempfile

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
CC = shutil.which("gcc") or shutil.which("clang")
TMP = tempfile.mkdtemp(prefix="cap_")
NOISE = re.compile(r"^\s*(#\d|0x|=>|\^|Shadow|Addressable|Partially|Heap|Freed|Stack|Global|Poisoned|Container|"
                   r"Array|Intra|ASan|Left|Right)|is located|^\s*$|^=+$|^ [0-9a-f]{2} ")


def banner(title, cmd=None):
    print("\n" + "=" * 78 + f"\n{title}" + (f"\n$ {' '.join(cmd)}" if cmd else "") + "\n" + "-" * 78, flush=True)


def run(cmd, env=None, warnings_only=False):
    r = subprocess.run(cmd, cwd=ROOT, env={**os.environ, **(env or {})}, text=True, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
    out = r.stdout
    if warnings_only:
        out = "\n".join(l for l in out.splitlines() if "warning:" in l or "error:" in l) or "(no warnings)"
    if "Sanitizer" in out or "runtime error" in out:
        out = "\n".join(l for l in out.splitlines() if not NOISE.search(l))
    print(out.rstrip())
    return r.returncode


def build_and_run(title, sources, exe, flags, env=None):
    if not CC:
        print(f"\n{title}: skipped (no gcc or clang found)")
        return
    out = os.path.join(TMP, exe)
    r = subprocess.run([CC, *flags, *sources, "-o", out], cwd=ROOT, text=True, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
    banner(title, [os.path.basename(CC), *flags, *sources])
    if r.returncode != 0:
        print("Build failed:\n" + r.stdout)
        return
    run([out], env)


def main():
    only = sys.argv[1].lower() if len(sys.argv) > 1 else None
    want = lambda k: only in (None, k)
    print(f"Capstone checks. Compiler: {CC or 'none'}")
    san = ["-g", "-fsanitize=address,undefined", "-fsanitize-recover=address"] if CC and sys.platform != "win32" else ["-g"]
    env = {"ASAN_OPTIONS": "halt_on_error=0:detect_leaks=0:print_legend=0"}
    if want("tests"):
        build_and_run("Task 5: your unit tests against src/pump_control.c", ["src/pump_control.c", "tests/test_pump_control.c"],
                      "test_pump", ["-Wall", "-Wextra", "-Isrc"])
    if want("c1"):
        if CC:
            banner("Task 7, C1: compiler warnings", [os.path.basename(CC), "-Wall", "-Wextra", "-O2", "-c", "ai_outputs/C1_dry_run_patch.c"])
            run([CC, "-Wall", "-Wextra", "-O2", "-Isrc", "-c", "ai_outputs/C1_dry_run_patch.c", "-o", os.path.join(TMP, "c1.o")], warnings_only=True)
        build_and_run("Task 7, C1: host test against REQ-310, with sanitizers", ["ai_outputs/C1_dry_run_patch.c", "verify/c1_host_test.c"],
                      "c1_test", san + ["-Isrc"], env)
    if want("scan"):
        banner("Task 7: scan AI outputs and your deliverables for secrets, customer data and prompt injection")
        files = sorted(os.path.join(d, f) for d in ("ai_outputs", "deliverables", "docs") for f in os.listdir(os.path.join(ROOT, d))
                       if f.endswith((".md", ".txt", ".c", ".h", ".csv", ".json")))
        run([sys.executable, "verify/scan_text.py", *files])
    print("\nDone. Tools find some mistakes; your team's review finds the rest.")


if __name__ == "__main__":
    main()
