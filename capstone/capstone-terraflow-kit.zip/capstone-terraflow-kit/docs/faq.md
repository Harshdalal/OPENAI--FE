# TerraFlow support FAQ

Fictional product, for training.

## How do I read the firmware version?

Type "version" on the service console at 115200 baud, 8N1. The reply is a line such as
"app: firmware v3.2.1".

## Why is the amber light blinking?

The controller cannot trust the pressure reading and has stopped the pump (REQ-310, AC3).
Check the sensor cable, then power cycle the controller.

## How do I clear a locked pump (P-403)?

Check the water supply, then press the service button for two seconds (REQ-310, AC5).

## Which pressure sensor does TerraFlow use?

The PressCore PX-12 on I2C1 at address 0x28. See PX12_registers.md.
