# REQ-310: Dry-run and pressure sensor protection

Product: TerraFlow T-300 pump controller firmware
Owner: Pump firmware team
Status: Ready for test

TerraFlow is a fictional product used for training. It is not a real product.

## Story

As a TerraFlow owner, I want the pump to stop when it runs dry or when it cannot trust the
pressure reading, so that the pump and its seals are never damaged.

## Acceptance criteria

- AC1. A pressure reading is invalid if it is below 0.00 bar or above 10.00 bar, if the I2C
  read fails (NACK or timeout), or if the sensor's status bits are 11 (diagnostic) or 10
  (stale data).
- AC2. Dry run: if the motor duty is 50% or more and the pressure stays below 0.50 bar for
  10 valid readings in a row, taken 500 ms apart, the controller stops the motor (duty 0%)
  and logs exactly one line: "pump: dry-run code=P-401".
- AC3. Sensor fault: after 3 invalid readings in a row the controller stops the motor, the
  status LED blinks amber at 1 Hz, and it logs exactly one line: "pump: sensor fault code=P-402".
- AC4. After a dry-run stop the controller waits 60 seconds, then restarts at the duty from
  pump_spec.md.
- AC5. If the controller makes more than 3 dry-run stops within 30 minutes, it stays stopped
  until the service button is pressed, and logs "pump: locked code=P-403".
- AC6. Every stop in AC2, AC3 and AC5 sets the motor duty to 0% within 200 ms.

## Out of scope

LoRa message formats, register names and addresses, firmware updates and the mobile app.
