# PressCore PX-12 pressure sensor: register map (datasheet rev A, page 5)

Text copy of docs/PX12_datasheet_p5.pdf. PressCore and the PX-12 are fictional; not a real
product.

## 5.1 Register map

| Address | Register  | Access | Reset value | Description |
|---------|-----------|--------|-------------|-------------|
| 0x00    | STATUS    | R      | 0x0000      | Status bits 15:14 (00 normal, 01 command mode, 10 stale data, 11 diagnostic) |
| 0x01    | PRESSURE  | R      | 0x0000      | 14-bit pressure output, bits 13:0 |
| 0x02    | CONFIG    | R/W    | 0x0041      | Output data rate, filter, enable |
| 0x0F    | DEVICE_ID | R      | 0x00A7      | Device identifier |

## 5.2 CONFIG register (0x02) fields

| Bits | Field | Reset | Description |
|------|-------|-------|-------------|
| 15:8 | -     | 0     | Reserved, write 0 |
| 7:6  | ODR   | 01    | Output data rate: 00 = 1 Hz, 01 = 10 Hz, 10 = 50 Hz, 11 = 100 Hz |
| 5:4  | FILT  | 00    | Filter: 00 = off, 01 = 2 samples, 10 = 4 samples, 11 = 8 samples |
| 3:1  | -     | 0     | Reserved, write 0 |
| 0    | EN    | 1     | Enable: 1 = measuring |

## 5.3 Transfer function

Pressure output counts: 1638 at 0 bar and 14745 at 10 bar (10% to 90% of the 14-bit range).

    pressure_bar = (counts - 1638) x 10 / (14745 - 1638)

## 5.4 Electrical characteristics (extract)

| Parameter | Min | Typ | Max | Unit |
|-----------|-----|-----|-----|------|
| Pressure range | 0 | | 10 | bar |
| Output counts | 1638 | | 14745 | counts |
| Response time | | 2 | 5 | ms |
| I2C clock frequency | | | 400 | kHz |
| Supply voltage | 3.0 | 3.3 | 3.6 | V |
