# TerraFlow T-300 pump controller: motor duty specification

The product owner and the hydraulics lead agreed this specification and its examples. An AI
answer is correct only if it matches them.

TerraFlow is a fictional product used for training. It is not a real product.

## Story

As a TerraFlow owner, I want the pump to work harder when the line pressure is low and stop
when the target pressure is reached, so the field is watered evenly without wasting power.

## Rules

Pressure is measured in bar. Firmware uses hundredths of a bar (210 means 2.10 bar).

- D1. Pressure of 3.00 bar or more: target reached, motor duty 0%.
- D2. Pressure from 1.00 bar to 2.99 bar: duty = 30 + (3.00 - pressure) x 35 percent.
- D3. Pressure below 1.00 bar: duty 100%.
- D4. Round the duty to a whole percent, half up.
- D5. A reading below 0.00 bar or above 10.00 bar is a sensor fault. REQ-310 says how the
  controller handles it.

## Agreed examples

| ID | Pressure (bar) | Duty (%) | Rule |
|----|----------------|----------|------|
| 1  | 3.00           | 0        | D1   |
| 2  | 2.99           | 30       | D2, D4 (30.35 rounds down) |
| 3  | 2.10           | 62       | D2, D4 (61.5 rounds up) |
| 4  | 1.50           | 83       | D2, D4 (82.5 rounds up) |
| 5  | 1.00           | 100      | D2   |
| 6  | 0.80           | 100      | D3   |

## Not in this specification

LoRa message formats, register names and addresses, flow rate, LED patterns other than
those in REQ-310, and motor current limits are not defined here.
