# TerraFlow pump controller firmware release notes

Fictional product, for training.

## v3.2.1 (1 Nov 2026)

- Dry-run protection follows REQ-310.
- Known issue: the pump can stop with P-401 when a valve opens and the pressure dips for a
  few seconds, even though water is flowing (TF-BUG-912). Fix planned for v3.2.2.
- Known issue: LoRa join can fail on some gateways (TF-BUG-915). The pump keeps working;
  remote status is unavailable until the next join.

## v3.2.0 (18 Oct 2026)

- New motor duty curve from line pressure (pump_spec.md, rules D1 to D4).
- PX-12 pressure sensor support.
